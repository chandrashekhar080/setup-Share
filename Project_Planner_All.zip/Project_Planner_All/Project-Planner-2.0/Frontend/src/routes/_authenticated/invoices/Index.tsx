import Invoices from '@/features/invoices/Invoices'
import { createFileRoute } from '@tanstack/react-router'

export const Route = createFileRoute('/_authenticated/invoices/Index')({
  component: Invoices,
})


