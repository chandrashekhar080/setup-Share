import { createFileRoute } from '@tanstack/react-router'
import Timesheets from '@/features/timesheets'

export const Route = createFileRoute('/_authenticated/timesheets/')({
  component: () => <Timesheets />,
})