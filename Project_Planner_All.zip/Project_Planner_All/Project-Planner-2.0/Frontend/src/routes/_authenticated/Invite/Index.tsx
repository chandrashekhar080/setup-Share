import { createFileRoute } from '@tanstack/react-router'
import Invite from '../../../features/Invite';

export const Route = createFileRoute('/_authenticated/Invite/Index')({
  component: Invite,
})

