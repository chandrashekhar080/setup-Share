import DocumentManager from '@/features/documentManage/DocumentManager'
import { createFileRoute } from '@tanstack/react-router'

export const Route = createFileRoute('/_authenticated/document/Index')({
  component: DocumentManager,
})

