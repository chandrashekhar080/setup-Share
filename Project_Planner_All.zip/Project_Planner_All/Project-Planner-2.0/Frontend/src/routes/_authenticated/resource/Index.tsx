import ResourceClient from '@/features/resource/components/ResourceClient'
import { createFileRoute } from '@tanstack/react-router'

export const Route = createFileRoute('/_authenticated/resource/Index')({
  component: ResourceClient,
})


