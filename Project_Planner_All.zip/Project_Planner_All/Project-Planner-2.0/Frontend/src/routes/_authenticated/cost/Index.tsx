import CostsClient from '@/features/cost/components/CostsClient'
import { createFileRoute } from '@tanstack/react-router'

export const Route = createFileRoute('/_authenticated/cost/Index')({
  component: CostsClient,
})


