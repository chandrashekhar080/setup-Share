import { createFileRoute } from '@tanstack/react-router'
import Notification from '@/features/Notification/notifications'

export const Route = createFileRoute('/_authenticated/notification/Index')({
  component: Notification,
})
