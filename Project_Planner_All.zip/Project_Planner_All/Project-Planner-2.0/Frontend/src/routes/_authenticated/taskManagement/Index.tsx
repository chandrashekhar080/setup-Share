import { createFileRoute } from '@tanstack/react-router'
import TasksPage from '@/features/taskManagement/TaskManagement'

export const Route = createFileRoute('/_authenticated/taskManagement/Index')({
  component:TasksPage ,
})

