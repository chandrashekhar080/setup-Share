import GanttChart from '@/features/ganttChart/GanttChart'
import { createFileRoute } from '@tanstack/react-router'

export const Route = createFileRoute('/_authenticated/ganttchart/Index')({
  component: GanttChart,
})

