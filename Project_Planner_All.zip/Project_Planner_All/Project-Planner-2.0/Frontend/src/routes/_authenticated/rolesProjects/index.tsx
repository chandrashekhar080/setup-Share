import { createFileRoute } from '@tanstack/react-router'
import rolesProject from '../../../features/RolesProject';

export const Route = createFileRoute('/_authenticated/rolesProjects/')({
  component: rolesProject,
})

