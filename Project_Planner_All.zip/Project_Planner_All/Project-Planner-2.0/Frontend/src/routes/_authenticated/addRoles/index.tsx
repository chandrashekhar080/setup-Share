import { createFileRoute } from '@tanstack/react-router'
import ProjectForm from "../../../features/RolesProject/components/project-form";

export const Route = createFileRoute('/_authenticated/addRoles/')({
  component: () => (
    <ProjectForm mode="create" />
  ),
})

// function RouteComponent() {
//   return <div>Hello "/_authenticated/addRoles/"!</div>
// }
