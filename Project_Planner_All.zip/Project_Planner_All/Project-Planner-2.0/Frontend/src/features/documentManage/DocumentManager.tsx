import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { 
  Folder, FileText, Image as ImageIcon, FileArchive,
  MoreVertical, Eye, Download, Trash2, Plus, Upload as UploadIcon,
  Search, Grid, List, ChevronRight, Pencil
} from "lucide-react";

// ---------------- Types ----------------

type DocFile = {
  id: string;
  name: string;
  size: number;
  type: string;
  uploadedAt: number; // epoch
  url: string; // Object URL for preview/download
};

type FolderNode = {
  id: string;
  name: string;
  children: FolderNode[];
  files: DocFile[];
};

// ---------------- Utils ----------------

const uid = () => Math.random().toString(36).slice(2, 10);

const formatBytes = (bytes: number) => {
  if (bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB", "TB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
};

const formatDate = (ts: number) => new Date(ts).toLocaleString();

const isPreviewableImage = (mime: string) => mime.startsWith("image/");
const isPreviewablePdf = (mime: string) => mime === "application/pdf";

// ---------------- Storage (optional localStorage persistence) ----------------
const STORAGE_KEY = "doc_manager_state_v1";

function saveState(root: FolderNode) {
  // Don't persist blob URLs (ephemeral). Persist metadata only
  const clone = (node: FolderNode): any => ({
    id: node.id,
    name: node.name,
    children: node.children.map(clone),
    files: node.files.map(f => ({ id: f.id, name: f.name, size: f.size, type: f.type, uploadedAt: f.uploadedAt }))
  });
  localStorage.setItem(STORAGE_KEY, JSON.stringify(clone(root)));
}

function loadState(): FolderNode | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const meta = JSON.parse(raw);
    const restore = (node: any): FolderNode => ({
      id: node.id,
      name: node.name,
      children: (node.children || []).map(restore),
      files: (node.files || []).map((f: any) => ({...f, url: ""}))
    });
    return restore(meta);
  } catch {
    return null;
  }
}

// ---------------- Components ----------------

export default function DocumentManager() {
  const initialRoot: FolderNode = useMemo(() => loadState() || ({ id: "root", name: "Documents", children: [], files: [] }), []);
  const [root, setRoot] = useState<FolderNode>(initialRoot);
  const [currentPath, setCurrentPath] = useState<string[]>(["root"]);
  const [expanded, setExpanded] = useState<Record<string, boolean>>({ root: true });
  const [searchTerm, setSearchTerm] = useState("");
  const [viewFile, setViewFile] = useState<DocFile | null>(null);
  const [showNewFolder, setShowNewFolder] = useState(false);
  const [newFolderName, setNewFolderName] = useState("");
  const [renameTarget, setRenameTarget] = useState<{type: "folder"|"file"; id: string; name: string} | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    saveState(root);
  }, [root]);

  const currentFolder = useMemo(() => {
    const byId = new Map<string, FolderNode>();
    const walk = (node: FolderNode) => { byId.set(node.id, node); node.children.forEach(walk); };
    walk(root);
    const id = currentPath[currentPath.length - 1];
    return byId.get(id) || root;
  }, [root, currentPath]);

  // Map of file id to live object URL
  const [fileUrls, setFileUrls] = useState<Record<string, string>>({});

  useEffect(() => () => { // cleanup all blob urls on unmount
    Object.values(fileUrls).forEach(u => URL.revokeObjectURL(u));
  }, [fileUrls]);

  const buildIndex = useCallback(() => {
    const folders: Record<string, FolderNode> = {};
    const walk = (node: FolderNode) => { folders[node.id] = node; node.children.forEach(walk); };
    walk(root);
    return folders;
  }, [root]);

  const setFolder = (id: string, updater: (f: FolderNode) => void) => {
    const cloneDeep = (node: FolderNode): FolderNode => ({
      id: node.id,
      name: node.name,
      children: node.children.map(cloneDeep),
      files: node.files.map(f => ({...f}))
    });
    const draft = cloneDeep(root);
    const index: Record<string, FolderNode> = {};
    const walk = (n: FolderNode) => { index[n.id] = n; n.children.forEach(walk); };
    walk(draft);
    updater(index[id]);
    setRoot(draft);
  };

  const createFolder = () => {
    const name = newFolderName.trim() || "New Folder";
    setFolder(currentFolder.id, (f) => {
      f.children.push({ id: uid(), name, children: [], files: [] });
    });
    setShowNewFolder(false);
    setNewFolderName("");
  };

  const renameItem = (name: string) => {
    if (!renameTarget) return;
    if (renameTarget.type === "folder") {
      setFolder(renameTarget.id, (f) => { f.name = name; });
    } else {
      // find file inside its parent folders
      const draft = structuredClone(root) as FolderNode;
      const changed = (function walk(node: FolderNode): boolean {
        for (const file of node.files) {
          if (file.id === renameTarget.id) { file.name = name; return true; }
        }
        return node.children.some(walk);
      })(draft);
      if (changed) setRoot(draft);
    }
    setRenameTarget(null);
  };

  const deleteFile = (fileId: string) => {
    const draft = structuredClone(root) as FolderNode;
    (function walk(node: FolderNode) {
      const idx = node.files.findIndex(f => f.id === fileId);
      if (idx !== -1) {
        const f = node.files[idx];
        if (fileUrls[f.id]) URL.revokeObjectURL(fileUrls[f.id]);
        node.files.splice(idx, 1);
        return;
      }
      node.children.forEach(walk);
    })(draft);
    setRoot(draft);
  };

  const deleteFolder = (folderId: string) => {
    const draft = structuredClone(root) as FolderNode;
    (function walk(node: FolderNode) {
      const idx = node.children.findIndex(c => c.id === folderId);
      if (idx !== -1) {
        node.children.splice(idx, 1);
        return;
      }
      node.children.forEach(walk);
    })(draft);
    setRoot(draft);
    setCurrentPath((p) => p.filter(id => id !== folderId));
  };

  const onUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    const toAdd: DocFile[] = files.map((file) => {
      const id = uid();
      const url = URL.createObjectURL(file);
      setFileUrls((m) => ({ ...m, [id]: url }));
      return {
        id,
        name: file.name,
        size: file.size,
        type: file.type || "application/octet-stream",
        uploadedAt: Date.now(),
        url,
      };
    });
    setFolder(currentFolder.id, (f) => { f.files.push(...toAdd); });
    // reset input so same file can be selected again
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const openFolder = (id: string) => {
    setExpanded((ex) => ({ ...ex, [id]: true }));
    setCurrentPath((p) => [...p.filter((_, i) => i < p.length), id === "root" ? "root" : id]);
    // Ensure path ends with the folder id exactly once
    setCurrentPath((prev) => {
      const base = prev.slice(0, prev.indexOf(id) + 1);
      if (base.length) return base; // already in path
      return [...prev, id];
    });
  };

  const goTo = (id: string) => {
    setCurrentPath((p) => p.slice(0, p.indexOf(id) + 1));
  };

  // const toggleExpand = (id: string) => setExpanded((ex) => ({ ...ex, [id]: !ex[id] }));

  // const allFilesFlat = useMemo(() => {
  //   const acc: DocFile[] = [];
  //   (function walk(node: FolderNode) {
  //     acc.push(...node.files);
  //     node.children.forEach(walk);
  //   })(root);
  //   return acc;
  // }, [root]);

  const visibleFiles = useMemo(() => {
    const term = searchTerm.trim().toLowerCase();
    const list = currentFolder.files.slice().sort((a, b) => b.uploadedAt - a.uploadedAt);
    if (!term) return list;
    return list.filter(f => f.name.toLowerCase().includes(term));
  }, [currentFolder, searchTerm]);

  const breadcrumbs = useMemo(() => {
    const index = buildIndex();
    return currentPath.map((id) => index[id]).filter(Boolean);
  }, [currentPath, buildIndex]);

  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");

  return (
    <div className="w-full h-full p-4 md:p-6 lg:p-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center gap-4 mb-4">
        <div className="flex items-center gap-2 text-xl md:text-2xl font-semibold">
          <Folder className="h-6 w-6" />
          <span>Document Manager</span>
        </div>
        <div className="flex-1" />
        <div className="flex items-center gap-2">
          <div className="relative w-64">
            <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4" />
            <Input value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} placeholder="Search in this folder…" className="pl-8" />
          </div>
          <Button variant={viewMode === "grid" ? "default" : "outline"} size="icon" onClick={() => setViewMode("grid")}>
            <Grid className="h-4 w-4" />
          </Button>
          <Button variant={viewMode === "list" ? "default" : "outline"} size="icon" onClick={() => setViewMode("list")}>
            <List className="h-4 w-4" />
          </Button>
          <input ref={fileInputRef} type="file" className="hidden" multiple onChange={onUpload} />
          <Button onClick={() => fileInputRef.current?.click()}>
            <UploadIcon className="h-4 w-4 mr-2" /> Upload
          </Button>
          <Button variant="secondary" onClick={() => setShowNewFolder(true)}>
            <Plus className="h-4 w-4 mr-2" /> New Folder
          </Button>
        </div>
      </div>

      {/* Body */}
      <div className="grid grid-cols md:grid-cols ">
      
        {/* Main content */}
        <div className="md:col-span-9 lg:col-span-9">
          {/* Breadcrumbs */}
          <div className="flex items-center gap-2 mb-3 text-sm">
            {breadcrumbs.map((f, idx) => (
              <React.Fragment key={f.id}>
                {idx > 0 && <ChevronRight className="h-4 w-4 opacity-60" />}
                <Button variant={idx === breadcrumbs.length - 1 ? "secondary" : "ghost"} size="sm" onClick={() => goTo(f.id)}>
                  {f.name}
                </Button>
              </React.Fragment>
            ))}
          </div>

          <Card className="h-[60vh] md:h-[70vh]">
            <CardHeader className="pb-2">
              <CardTitle className="text-base">{currentFolder.name}</CardTitle>
            </CardHeader>
            <Separator />
            <CardContent className="pt-4">
              {/* Subfolders */}
              {currentFolder.children.length > 0 && (
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-3 mb-6">
                  {currentFolder.children.map((child) => (
                    <FolderTile key={child.id} node={child} onOpen={() => openFolder(child.id)} onMenu={(action) => {
                      if (action === "rename") setRenameTarget({ type: "folder", id: child.id, name: child.name });
                      if (action === "delete") deleteFolder(child.id);
                    }} />
                  ))}
                </div>
              )}

              {/* Files */}
              {visibleFiles.length === 0 ? (
                <div className="h-48 flex items-center justify-center text-sm opacity-70">No files here yet. Use Upload to add documents.</div>
              ) : viewMode === "grid" ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-3">
                  {visibleFiles.map((file) => (
                    <FileTile key={file.id} file={file} onPreview={setViewFile} onDelete={() => deleteFile(file.id)} onRename={() => setRenameTarget({ type: "file", id: file.id, name: file.name })} />
                  ))}
                </div>
              ) : (
                <div className="space-y-2">
                  {visibleFiles.map((file) => (
                    <FileRow key={file.id} file={file} onPreview={setViewFile} onDelete={() => deleteFile(file.id)} onRename={() => setRenameTarget({ type: "file", id: file.id, name: file.name })} />
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Preview dialog */}
      <Dialog open={!!viewFile} onOpenChange={(o) => !o && setViewFile(null)}>
        <DialogContent className="max-w-5xl w-[95vw] h-[85vh] p-0 overflow-hidden">
          <DialogHeader className="px-6 pt-6">
            <DialogTitle className="flex items-center justify-between">
              <span className="truncate pr-4">{viewFile?.name}</span>
              {viewFile && (
                <div className="flex items-center gap-2">
                  <a href={viewFile.url} download={viewFile.name}>
                    <Button variant="outline" size="sm"><Download className="h-4 w-4 mr-2"/>Download</Button>
                  </a>
                  <Button variant="secondary" size="sm" onClick={() => setViewFile(null)}>Close</Button>
                </div>
              )}
            </DialogTitle>
          </DialogHeader>
          <Separator />
          <div className="w-full h-full flex items-center justify-center bg-muted/40">
            {viewFile && (
              isPreviewableImage(viewFile.type) ? (
                <img src={viewFile.url} alt={viewFile.name} className="max-h-[75vh] object-contain" />
              ) : isPreviewablePdf(viewFile.type) ? (
                <iframe src={viewFile.url} title={viewFile.name} className="w-full h-full" />
              ) : (
                <div className="text-sm opacity-80 p-6 text-center">
                  Preview not available for this file type.
                  <div className="mt-2">Use the Download button to open it locally.</div>
                </div>
              )
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* New folder dialog */}
      <Dialog open={showNewFolder} onOpenChange={setShowNewFolder}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Create new folder</DialogTitle>
          </DialogHeader>
          <div className="grid gap-2">
            <Input autoFocus value={newFolderName} onChange={(e) => setNewFolderName(e.target.value)} placeholder="Folder name" />
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setShowNewFolder(false)}>Cancel</Button>
            <Button onClick={createFolder}><Plus className="h-4 w-4 mr-2"/>Create</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Rename dialog */}
      <Dialog open={!!renameTarget} onOpenChange={(o) => !o && setRenameTarget(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Rename {renameTarget?.type}</DialogTitle>
          </DialogHeader>
          <RenameForm 
            initialName={renameTarget?.name || ""}
            onCancel={() => setRenameTarget(null)}
            onSave={(name) => renameItem(name)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ---------------- Subcomponents ----------------

// function FolderTree({ node, currentId, expanded, onOpen, onToggle, onRename, onDelete }: {
//   node: FolderNode;
//   currentId: string;
//   expanded: Record<string, boolean>;
//   onOpen: (id: string) => void;
//   onToggle: (id: string) => void;
//   onRename: (id: string, name: string) => void;
//   onDelete: (id: string) => void;
// }) {
//   const isRoot = node.id === "root";
//   const isOpen = !!expanded[node.id];

//   return (
//     <div className="pl-2">
//       <div className={`group flex items-center gap-2 py-1.5 rounded-lg px-2 hover:bg-muted/60 ${currentId === node.id ? "bg-muted" : ""}`}
//       >
//         {node.children.length > 0 ? (
//           <button className="p-1" onClick={() => onToggle(node.id)}>{isOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}</button>
//         ) : (
//           <div className="w-6" />
//         )}
//         <button className="flex items-center gap-2 flex-1 text-left" onClick={() => onOpen(node.id)}>
//           <Folder className="h-4 w-4" />
//           <span className="truncate">{node.name}</span>
//           {!isRoot && <Badge variant="outline" className="ml-2">{node.files.length}</Badge>}
//         </button>
//         {!isRoot && (
//           <DropdownMenu>
//             <DropdownMenuTrigger asChild>
//               <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100 transition-opacity"><MoreVertical className="h-4 w-4"/></Button>
//             </DropdownMenuTrigger>
//             <DropdownMenuContent align="end">
//               <DropdownMenuLabel>Folder</DropdownMenuLabel>
//               <DropdownMenuItem onClick={() => onRename(node.id, node.name)}><Pencil className="h-4 w-4 mr-2"/>Rename</DropdownMenuItem>
//               <DropdownMenuSeparator />
//               <DropdownMenuItem onClick={() => onDelete(node.id)} className="text-red-600"><Trash2 className="h-4 w-4 mr-2"/>Delete</DropdownMenuItem>
//             </DropdownMenuContent>
//           </DropdownMenu>
//         )}
//       </div>
//       {isOpen && node.children.length > 0 && (
//         <div className="pl-4">
//           {node.children.map((child) => (
//             <FolderTree key={child.id} node={child} currentId={currentId} expanded={expanded} onOpen={onOpen} onToggle={onToggle} onRename={onRename} onDelete={onDelete} />
//           ))}
//         </div>
//       )}
//     </div>
//   );
// }

function iconForType(type: string) {
  if (type.startsWith("image/")) return <ImageIcon className="h-5 w-5"/>;
  if (type === "application/pdf") return <FileText className="h-5 w-5"/>;
  if (/(zip|x-7z-compressed|x-rar-compressed)/.test(type)) return <FileArchive className="h-5 w-5"/>;
  return <FileText className="h-5 w-5"/>;
}

function FileTile({ file, onPreview, onDelete, onRename }: { file: DocFile; onPreview: (f: DocFile) => void; onDelete: () => void; onRename: () => void; }) {
  return (
    <Card className="group hover:shadow-sm transition-shadow">
      <CardContent className="p-3">
        <div className="aspect-video rounded-xl bg-muted/60 flex items-center justify-center overflow-hidden">
          {file.type.startsWith("image/") ? (
            <img src={file.url} alt={file.name} className="object-cover w-full h-full" />
          ) : file.type === "application/pdf" ? (
            <div className="flex flex-col items-center justify-center text-xs opacity-80">
              <FileText className="h-8 w-8 mb-2"/>
              PDF
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center text-xs opacity-80">
              {iconForType(file.type)}
              <span className="mt-2">{file.type.split("/")[1] || "file"}</span>
            </div>
          )}
        </div>
        <div className="mt-3 flex items-start gap-2">
          {iconForType(file.type)}
          <div className="flex-1 min-w-0">
            <div className="truncate text-sm font-medium" title={file.name}>{file.name}</div>
            <div className="text-xs opacity-70">{formatBytes(file.size)} • {new Date(file.uploadedAt).toLocaleDateString()}</div>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100 transition-opacity"><MoreVertical className="h-4 w-4"/></Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => onPreview(file)}><Eye className="h-4 w-4 mr-2"/>View</DropdownMenuItem>
              <a href={file.url} download={file.name}>
                <DropdownMenuItem><Download className="h-4 w-4 mr-2"/>Download</DropdownMenuItem>
              </a>
              <DropdownMenuItem onClick={onRename}><Pencil className="h-4 w-4 mr-2"/>Rename</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={onDelete} className="text-red-600"><Trash2 className="h-4 w-4 mr-2"/>Delete</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardContent>
    </Card>
  );
}

function FileRow({ file, onPreview, onDelete, onRename }: { file: DocFile; onPreview: (f: DocFile) => void; onDelete: () => void; onRename: () => void; }) {
  return (
    <div className="group flex items-center gap-3 p-3 rounded-xl border hover:bg-muted/40">
      {iconForType(file.type)}
      <div className="flex-1 min-w-0">
        <div className="truncate text-sm font-medium">{file.name}</div>
        <div className="text-xs opacity-70">{file.type || "file"}</div>
      </div>
      <div className="text-xs w-24 opacity-70">{formatBytes(file.size)}</div>
      <div className="text-xs w-40 opacity-70">{formatDate(file.uploadedAt)}</div>
      <div className="flex items-center gap-2">
        <Button variant="outline" size="sm" onClick={() => onPreview(file)}><Eye className="h-4 w-4 mr-2"/>View</Button>
        <a href={file.url} download={file.name}><Button variant="outline" size="sm"><Download className="h-4 w-4 mr-2"/>Download</Button></a>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100 transition-opacity"><MoreVertical className="h-4 w-4"/></Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={onRename}><Pencil className="h-4 w-4 mr-2"/>Rename</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={onDelete} className="text-red-600"><Trash2 className="h-4 w-4 mr-2"/>Delete</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
}

function FolderTile({ node, onOpen, onMenu }: { node: FolderNode; onOpen: () => void; onMenu: (action: "rename" | "delete") => void; }) {
  return (
    <Card className="group cursor-pointer hover:shadow-sm" onDoubleClick={onOpen}>
      <CardContent className="p-3">
        <div className="aspect-video rounded-xl bg-muted/40 flex items-center justify-center">
          <Folder className="h-8 w-8" />
        </div>
        <div className="mt-3 flex items-start gap-2">
          <Folder className="h-5 w-5" />
          <div className="flex-1 min-w-0">
            <div className="truncate text-sm font-medium">{node.name}</div>
            <div className="text-xs opacity-70">{node.files.length} files • {node.children.length} subfolders</div>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100 transition-opacity"><MoreVertical className="h-4 w-4"/></Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => onMenu("rename")}><Pencil className="h-4 w-4 mr-2"/>Rename</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => onMenu("delete")} className="text-red-600"><Trash2 className="h-4 w-4 mr-2"/>Delete</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        <Button variant="outline" className="mt-3 w-full" onClick={onOpen}>Open</Button>
      </CardContent>
    </Card>
  );
}

function RenameForm({ initialName, onSave, onCancel }: { initialName: string; onSave: (name: string) => void; onCancel: () => void; }) {
  const [name, setName] = useState(initialName);
  useEffect(() => setName(initialName), [initialName]);
  return (
    <form
      onSubmit={(e) => { e.preventDefault(); onSave(name.trim() || initialName); }}
      className="grid gap-4"
    >
      <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Name" />
      <div className="flex items-center justify-end gap-2">
        <Button type="button" variant="ghost" onClick={onCancel}>Cancel</Button>
        <Button type="submit"><Pencil className="h-4 w-4 mr-2"/>Save</Button>
      </div>
    </form>
  );
}
