import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { api, API_CONFIG } from '@/lib/api'
import { statusColors } from '../data/schema'
import { BarChart3, Clock, DollarSign, Users } from 'lucide-react'

interface Props {
  open: boolean
  onOpenChange: (open: boolean) => void
}

interface TimesheetStats {
  total: number
  totalHours: number
  totalBillableHours: number
  totalEarnings: number
  statusBreakdown: Array<{
    status: string
    count: number
    totalHours: number
    totalBillableHours: number
    totalEarnings: number
  }>
}

export function TimesheetStatsDialog({ open, onOpenChange }: Props) {
  const [stats, setStats] = useState<TimesheetStats | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (open) {
      fetchStats()
    }
  }, [open])

  const fetchStats = async () => {
    setIsLoading(true)
    setError(null)
    try {
      const data = await api.get<TimesheetStats>(`${API_CONFIG.ENDPOINTS.TIMESHEETS}stats`)
      setStats(data)
    } catch (err) {
      console.error('Error fetching timesheet stats:', err)
      setError(err instanceof Error ? err.message : 'Failed to fetch statistics')
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className='sm:max-w-2xl'>
        <DialogHeader>
          <DialogTitle className='flex items-center gap-2'>
            <BarChart3 className='h-5 w-5' />
            Timesheet Statistics
          </DialogTitle>
          <DialogDescription>
            Overview of all timesheet entries and their current status.
          </DialogDescription>
        </DialogHeader>
        
        <div className='space-y-6 py-4'>
          {isLoading ? (
            <div className='space-y-4'>
              <div className='grid grid-cols-2 md:grid-cols-4 gap-4'>
                {Array.from({ length: 4 }).map((_, i) => (
                  <Card key={i}>
                    <CardHeader className='pb-2'>
                      <Skeleton className='h-4 w-16' />
                    </CardHeader>
                    <CardContent>
                      <Skeleton className='h-8 w-12' />
                    </CardContent>
                  </Card>
                ))}
              </div>
              <Skeleton className='h-32 w-full' />
            </div>
          ) : error ? (
            <div className='text-center py-8'>
              <p className='text-muted-foreground mb-4'>{error}</p>
              <Button onClick={fetchStats} variant='outline'>
                Try Again
              </Button>
            </div>
          ) : stats ? (
            <>
              {/* Overview Cards */}
              <div className='grid grid-cols-2 md:grid-cols-4 gap-4'>
                <Card>
                  <CardHeader className='flex flex-row items-center justify-between space-y-0 pb-2'>
                    <CardTitle className='text-sm font-medium'>Total Entries</CardTitle>
                    <Users className='h-4 w-4 text-muted-foreground' />
                  </CardHeader>
                  <CardContent>
                    <div className='text-2xl font-bold'>{stats.total}</div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className='flex flex-row items-center justify-between space-y-0 pb-2'>
                    <CardTitle className='text-sm font-medium'>Total Hours</CardTitle>
                    <Clock className='h-4 w-4 text-muted-foreground' />
                  </CardHeader>
                  <CardContent>
                    <div className='text-2xl font-bold'>{stats.totalHours.toFixed(1)}h</div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className='flex flex-row items-center justify-between space-y-0 pb-2'>
                    <CardTitle className='text-sm font-medium'>Billable Hours</CardTitle>
                    <Clock className='h-4 w-4 text-muted-foreground' />
                  </CardHeader>
                  <CardContent>
                    <div className='text-2xl font-bold'>{stats.totalBillableHours.toFixed(1)}h</div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className='flex flex-row items-center justify-between space-y-0 pb-2'>
                    <CardTitle className='text-sm font-medium'>Total Earnings</CardTitle>
                    <DollarSign className='h-4 w-4 text-muted-foreground' />
                  </CardHeader>
                  <CardContent>
                    <div className='text-2xl font-bold'>${stats.totalEarnings.toFixed(2)}</div>
                  </CardContent>
                </Card>
              </div>

              {/* Status Breakdown */}
              <Card>
                <CardHeader>
                  <CardTitle className='text-lg'>Status Breakdown</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className='space-y-4'>
                    {stats.statusBreakdown.map((item) => (
                      <div key={item.status} className='flex items-center justify-between p-3 rounded-lg border'>
                        <div className='flex items-center gap-3'>
                          <Badge 
                            variant='secondary' 
                            className={`capitalize ${statusColors[item.status as keyof typeof statusColors]}`}
                          >
                            {item.status}
                          </Badge>
                          <span className='font-medium'>{item.count} entries</span>
                        </div>
                        <div className='text-right text-sm text-muted-foreground'>
                          <div>{item.totalHours.toFixed(1)}h worked</div>
                          <div>{item.totalBillableHours.toFixed(1)}h billable</div>
                          <div className='font-medium text-foreground'>${item.totalEarnings.toFixed(2)}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Efficiency Metrics */}
              {stats.totalHours > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className='text-lg'>Efficiency Metrics</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className='grid grid-cols-2 gap-4'>
                      <div className='text-center p-4 rounded-lg bg-muted'>
                        <div className='text-2xl font-bold text-primary'>
                          {((stats.totalBillableHours / stats.totalHours) * 100).toFixed(1)}%
                        </div>
                        <div className='text-sm text-muted-foreground'>Billable Efficiency</div>
                      </div>
                      <div className='text-center p-4 rounded-lg bg-muted'>
                        <div className='text-2xl font-bold text-primary'>
                          ${(stats.totalEarnings / stats.totalBillableHours || 0).toFixed(2)}
                        </div>
                        <div className='text-sm text-muted-foreground'>Avg. Hourly Rate</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </>
          ) : null}
        </div>
      </DialogContent>
    </Dialog>
  )
}