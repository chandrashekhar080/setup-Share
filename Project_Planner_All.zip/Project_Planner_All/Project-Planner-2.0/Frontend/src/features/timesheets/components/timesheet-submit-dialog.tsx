import { useState } from 'react'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Badge } from '@/components/ui/badge'
import { Timesheet, statusColors } from '../data/schema'
import { useTimesheets } from '../hooks/use-timesheets'
import { useTimesheetsContext } from '../context/timesheets-context'
import { toast } from 'sonner'
import { format } from 'date-fns'

interface Props {
  open: boolean
  onOpenChange: (open: boolean) => void
  timesheet: Timesheet
}

export function TimesheetSubmitDialog({ open, onOpenChange, timesheet }: Props) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { submitTimesheet } = useTimesheets()
  const { setOpen } = useTimesheetsContext()

  const handleSubmit = async () => {
    setIsSubmitting(true)
    try {
      const result = await submitTimesheet(timesheet.uid)
      if (result.success) {
        toast.success('Timesheet submitted for approval')
        setOpen(null)
        onOpenChange(false)
      } else {
        toast.error(result.error || 'Failed to submit timesheet')
      }
    } catch (error) {
      console.error('Error submitting timesheet:', error)
      toast.error('Something went wrong')
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className='sm:max-w-md'>
        <DialogHeader>
          <DialogTitle>Submit Timesheet for Approval</DialogTitle>
          <DialogDescription>
            Are you sure you want to submit this timesheet for approval? 
            Once submitted, you won't be able to edit it until it's approved or rejected.
          </DialogDescription>
        </DialogHeader>
        
        <div className='space-y-4 py-4'>
          <div className='grid grid-cols-2 gap-4 text-sm'>
            <div>
              <span className='font-medium'>ID:</span>
              <p className='font-mono text-xs'>{timesheet.uid}</p>
            </div>
            <div>
              <span className='font-medium'>Member:</span>
              <p>{timesheet.member}</p>
            </div>
            <div>
              <span className='font-medium'>Start Date:</span>
              <p>{timesheet.startDate ? format(new Date(timesheet.startDate), 'MMM dd, yyyy') : '-'}</p>
            </div>
            <div>
              <span className='font-medium'>Hours Worked:</span>
              <p>{timesheet.hoursWorked ? `${timesheet.hoursWorked}h` : '-'}</p>
            </div>
            <div>
              <span className='font-medium'>Status:</span>
              <Badge 
                variant='secondary' 
                className={`capitalize ${statusColors[timesheet.status as keyof typeof statusColors]}`}
              >
                {timesheet.status}
              </Badge>
            </div>
            <div>
              <span className='font-medium'>Earnings:</span>
              <p>{timesheet.totalEarnings ? `$${timesheet.totalEarnings.toFixed(2)}` : '-'}</p>
            </div>
          </div>
          
          {timesheet.description && (
            <div>
              <span className='font-medium text-sm'>Description:</span>
              <p className='text-sm text-muted-foreground mt-1'>{timesheet.description}</p>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button 
            variant='outline' 
            onClick={() => onOpenChange(false)}
            disabled={isSubmitting}
          >
            Cancel
          </Button>
          <Button 
            onClick={handleSubmit}
            disabled={isSubmitting}
          >
            {isSubmitting ? 'Submitting...' : 'Submit for Approval'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}