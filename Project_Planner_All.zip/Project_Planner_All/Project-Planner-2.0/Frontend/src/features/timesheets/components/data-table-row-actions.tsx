import { DotsHorizontalIcon } from '@radix-ui/react-icons'
import { Row } from '@tanstack/react-table'

import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuSeparator,
  DropdownMenuShortcut,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'

import { Timesheet, statusOptions } from '../data/schema'
import { useTimesheetsContext } from '../context/timesheets-context'

interface DataTableRowActionsProps<TData> {
  row: Row<TData>
}

export function DataTableRowActions<TData>({
  row,
}: DataTableRowActionsProps<TData>) {
  const timesheet = row.original as Timesheet
  const { setOpen, setCurrentRow } = useTimesheetsContext()

  const handleEdit = () => {
    setCurrentRow(timesheet)
    setOpen('update')
  }

  const handleDelete = () => {
    setCurrentRow(timesheet)
    setOpen('delete')
  }

  const handleSubmit = () => {
    setCurrentRow(timesheet)
    setOpen('submit')
  }

  const handleApprove = () => {
    setCurrentRow(timesheet)
    setOpen('approve')
  }

  const handleReject = () => {
    setCurrentRow(timesheet)
    setOpen('reject')
  }

  const canEdit = timesheet.status === 'draft' || timesheet.status === 'rejected'
  const canSubmit = timesheet.status === 'draft'
  const canApprove = timesheet.status === 'submitted'
  const canDelete = timesheet.status === 'draft' || timesheet.status === 'rejected'

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant='ghost'
          className='flex h-8 w-8 p-0 data-[state=open]:bg-muted'
        >
          <DotsHorizontalIcon className='h-4 w-4' />
          <span className='sr-only'>Open menu</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align='end' className='w-[160px]'>
        {canEdit && (
          <DropdownMenuItem onClick={handleEdit}>
            Edit
          </DropdownMenuItem>
        )}
        
        <DropdownMenuItem onClick={() => navigator.clipboard.writeText(timesheet.uid)}>
          Copy ID
        </DropdownMenuItem>
        
        <DropdownMenuSeparator />
        
        {canSubmit && (
          <DropdownMenuItem onClick={handleSubmit}>
            Submit for Approval
          </DropdownMenuItem>
        )}
        
        {canApprove && (
          <>
            <DropdownMenuItem onClick={handleApprove}>
              Approve
            </DropdownMenuItem>
            <DropdownMenuItem onClick={handleReject}>
              Reject
            </DropdownMenuItem>
          </>
        )}
        
        <DropdownMenuSub>
          <DropdownMenuSubTrigger>Status</DropdownMenuSubTrigger>
          <DropdownMenuSubContent>
            <DropdownMenuRadioGroup value={timesheet.status}>
              {statusOptions.map((status) => (
                <DropdownMenuRadioItem key={status.value} value={status.value}>
                  {status.label}
                </DropdownMenuRadioItem>
              ))}
            </DropdownMenuRadioGroup>
          </DropdownMenuSubContent>
        </DropdownMenuSub>
        
        <DropdownMenuSeparator />
        
        {canDelete && (
          <DropdownMenuItem onClick={handleDelete}>
            Delete
            <DropdownMenuShortcut>⌘⌫</DropdownMenuShortcut>
          </DropdownMenuItem>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}