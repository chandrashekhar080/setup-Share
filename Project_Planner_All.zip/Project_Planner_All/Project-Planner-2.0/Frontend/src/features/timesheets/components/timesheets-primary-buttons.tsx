import { Button } from '@/components/ui/button'
import { Plus, FileSpreadsheet, BarChart3 } from 'lucide-react'
import { useTimesheetsContext } from '../context/timesheets-context'

export function TimesheetsPrimaryButtons() {
  const { setOpen } = useTimesheetsContext()

  return (
    <div className='flex flex-wrap items-center gap-2'>
      <Button
        variant='outline'
        size='sm'
        onClick={() => setOpen('view')}
        className='h-8'
      >
        <BarChart3 className='mr-2 h-4 w-4' />
        Statistics
      </Button>
      
      <Button
        variant='outline'
        size='sm'
        onClick={() => {
          // TODO: Implement export functionality
          console.log('Export timesheets')
        }}
        className='h-8'
      >
        <FileSpreadsheet className='mr-2 h-4 w-4' />
        Export
      </Button>

      <Button
        size='sm'
        onClick={() => setOpen('create')}
        className='h-8'
      >
        <Plus className='mr-2 h-4 w-4' />
        Add Timesheet
      </Button>
    </div>
  )
}