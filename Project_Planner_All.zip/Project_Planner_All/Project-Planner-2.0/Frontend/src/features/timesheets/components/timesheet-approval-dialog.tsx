import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Timesheet, statusColors } from '../data/schema'
import { useTimesheets } from '../hooks/use-timesheets'
import { useTimesheetsContext } from '../context/timesheets-context'
import { toast } from 'sonner'
import { format } from 'date-fns'

interface Props {
  open: boolean
  onOpenChange: (open: boolean) => void
  timesheet: Timesheet
  action: 'approve' | 'reject'
}

const approvalSchema = z.object({
  approvedBy: z.string().min(2, 'Name must be at least 2 characters'),
  rejectionReason: z.string().optional(),
})

type ApprovalForm = z.infer<typeof approvalSchema>

export function TimesheetApprovalDialog({ open, onOpenChange, timesheet, action }: Props) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { approveTimesheet, rejectTimesheet } = useTimesheets()
  const { setOpen } = useTimesheetsContext()

  const form = useForm<ApprovalForm>({
    resolver: zodResolver(approvalSchema),
    defaultValues: {
      approvedBy: '',
      rejectionReason: '',
    },
  })

  const onSubmit = async (data: ApprovalForm) => {
    setIsSubmitting(true)
    try {
      let result
      if (action === 'approve') {
        result = await approveTimesheet(timesheet.uid, data.approvedBy)
      } else {
        result = await rejectTimesheet(timesheet.uid, data.approvedBy, data.rejectionReason || '')
      }

      if (result.success) {
        toast.success(`Timesheet ${action}d successfully`)
        setOpen(null)
        onOpenChange(false)
        form.reset()
      } else {
        toast.error(result.error || `Failed to ${action} timesheet`)
      }
    } catch (error) {
      console.error(`Error ${action}ing timesheet:`, error)
      toast.error('Something went wrong')
    } finally {
      setIsSubmitting(false)
    }
  }

  const isReject = action === 'reject'

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className='sm:max-w-md'>
        <DialogHeader>
          <DialogTitle>
            {isReject ? 'Reject' : 'Approve'} Timesheet
          </DialogTitle>
          <DialogDescription>
            {isReject 
              ? 'Provide a reason for rejecting this timesheet entry.'
              : 'Confirm approval of this timesheet entry.'
            }
          </DialogDescription>
        </DialogHeader>
        
        <div className='space-y-4 py-4'>
          <div className='grid grid-cols-2 gap-4 text-sm'>
            <div>
              <span className='font-medium'>ID:</span>
              <p className='font-mono text-xs'>{timesheet.uid}</p>
            </div>
            <div>
              <span className='font-medium'>Member:</span>
              <p>{timesheet.member}</p>
            </div>
            <div>
              <span className='font-medium'>Start Date:</span>
              <p>{timesheet.startDate ? format(new Date(timesheet.startDate), 'MMM dd, yyyy') : '-'}</p>
            </div>
            <div>
              <span className='font-medium'>Hours Worked:</span>
              <p>{timesheet.hoursWorked ? `${timesheet.hoursWorked}h` : '-'}</p>
            </div>
            <div>
              <span className='font-medium'>Status:</span>
              <Badge 
                variant='secondary' 
                className={`capitalize ${statusColors[timesheet.status as keyof typeof statusColors]}`}
              >
                {timesheet.status}
              </Badge>
            </div>
            <div>
              <span className='font-medium'>Earnings:</span>
              <p>{timesheet.totalEarnings ? `$${timesheet.totalEarnings.toFixed(2)}` : '-'}</p>
            </div>
          </div>
          
          {timesheet.description && (
            <div>
              <span className='font-medium text-sm'>Description:</span>
              <p className='text-sm text-muted-foreground mt-1'>{timesheet.description}</p>
            </div>
          )}
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className='space-y-4'>
            <FormField
              control={form.control}
              name='approvedBy'
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{isReject ? 'Rejected by' : 'Approved by'} *</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder='Enter your name' />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {isReject && (
              <FormField
                control={form.control}
                name='rejectionReason'
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Rejection Reason</FormLabel>
                    <FormControl>
                      <Textarea 
                        {...field} 
                        placeholder='Explain why this timesheet is being rejected...'
                        rows={3}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            <DialogFooter>
              <Button 
                type='button'
                variant='outline' 
                onClick={() => {
                  onOpenChange(false)
                  form.reset()
                }}
                disabled={isSubmitting}
              >
                Cancel
              </Button>
              <Button 
                type='submit'
                variant={isReject ? 'destructive' : 'default'}
                disabled={isSubmitting}
              >
                {isSubmitting 
                  ? `${isReject ? 'Rejecting' : 'Approving'}...` 
                  : `${isReject ? 'Reject' : 'Approve'} Timesheet`
                }
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}