import { ConfirmDialog } from '@/components/confirm-dialog'
import { useTimesheetsContext } from '../context/timesheets-context'
import { TimesheetsMutateDrawer } from './timesheets-mutate-drawer'
import { TimesheetApprovalDialog } from './timesheet-approval-dialog'
import { TimesheetSubmitDialog } from './timesheet-submit-dialog'
import { TimesheetStatsDialog } from './timesheet-stats-dialog'
import { useTimesheets } from '../hooks/use-timesheets'
import { toast } from 'sonner'

export function TimesheetsDialogs() {
  const { open, setOpen, currentRow, setCurrentRow } = useTimesheetsContext()
  const { deleteTimesheet } = useTimesheets()

  const handleDelete = async () => {
    if (!currentRow) return

    const result = await deleteTimesheet(currentRow.uid)
    if (result.success) {
      toast.success('Timesheet deleted successfully')
      setOpen(null)
      setTimeout(() => {
        setCurrentRow(null)
      }, 500)
    } else {
      toast.error(result.error || 'Failed to delete timesheet')
    }
  }

  return (
    <>
      <TimesheetsMutateDrawer
        key='timesheet-create'
        open={open === 'create'}
        onOpenChange={() => setOpen('create')}
      />

      <TimesheetStatsDialog
        key='timesheet-stats'
        open={open === 'view'}
        onOpenChange={() => setOpen('view')}
      />

      {currentRow && (
        <>
          <TimesheetsMutateDrawer
            key={`timesheet-update-${currentRow.uid}`}
            open={open === 'update'}
            onOpenChange={() => {
              setOpen('update')
              setTimeout(() => {
                setCurrentRow(null)
              }, 500)
            }}
            currentRow={currentRow}
          />

          <TimesheetSubmitDialog
            key={`timesheet-submit-${currentRow.uid}`}
            open={open === 'submit'}
            onOpenChange={() => {
              setOpen('submit')
              setTimeout(() => {
                setCurrentRow(null)
              }, 500)
            }}
            timesheet={currentRow}
          />

          <TimesheetApprovalDialog
            key={`timesheet-approve-${currentRow.uid}`}
            open={open === 'approve'}
            onOpenChange={() => {
              setOpen('approve')
              setTimeout(() => {
                setCurrentRow(null)
              }, 500)
            }}
            timesheet={currentRow}
            action="approve"
          />

          <TimesheetApprovalDialog
            key={`timesheet-reject-${currentRow.uid}`}
            open={open === 'reject'}
            onOpenChange={() => {
              setOpen('reject')
              setTimeout(() => {
                setCurrentRow(null)
              }, 500)
            }}
            timesheet={currentRow}
            action="reject"
          />

          <ConfirmDialog
            key='timesheet-delete'
            destructive
            open={open === 'delete'}
            onOpenChange={() => {
              setOpen('delete')
              setTimeout(() => {
                setCurrentRow(null)
              }, 500)
            }}
            handleConfirm={handleDelete}
            className='max-w-md'
            title={`Delete timesheet: ${currentRow.uid}?`}
            desc={
              <>
                You are about to delete a timesheet entry for{' '}
                <strong>{currentRow.member}</strong>. <br />
                This action cannot be undone.
              </>
            }
            confirmText='Delete'
          />
        </>
      )}
    </>
  )
}