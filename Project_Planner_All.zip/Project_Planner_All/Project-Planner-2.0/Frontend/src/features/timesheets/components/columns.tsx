import { ColumnDef } from '@tanstack/react-table'
import { Badge } from '@/components/ui/badge'
import { Checkbox } from '@/components/ui/checkbox'
import { DataTableColumnHeader } from './data-table-column-header'
import { DataTableRowActions } from './data-table-row-actions'
import { Timesheet, statusColors } from '../data/schema'
import { format } from 'date-fns'

export const columns: ColumnDef<Timesheet>[] = [
  {
    id: 'select',
    header: ({ table }) => (
      <Checkbox
        checked={
          table.getIsAllPageRowsSelected() ||
          (table.getIsSomePageRowsSelected() && 'indeterminate')
        }
        onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
        aria-label='Select all'
        className='translate-y-[2px]'
      />
    ),
    cell: ({ row }) => (
      <Checkbox
        checked={row.getIsSelected()}
        onCheckedChange={(value) => row.toggleSelected(!!value)}
        aria-label='Select row'
        className='translate-y-[2px]'
      />
    ),
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: 'uid',
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title='ID' />
    ),
    cell: ({ row }) => (
      <div className='w-[80px] font-mono text-xs'>
        {row.getValue('uid')}
      </div>
    ),
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: 'member',
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title='Member' />
    ),
    cell: ({ row }) => {
      return (
        <div className='flex space-x-2'>
          <span className='max-w-[200px] truncate font-medium'>
            {row.getValue('member')}
          </span>
        </div>
      )
    },
  },
  {
    accessorKey: 'project',
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title='Project' />
    ),
    cell: ({ row }) => {
      return (
        <div className='flex space-x-2'>
          <span className='max-w-[150px] truncate font-mono text-xs'>
            {row.getValue('project')}
          </span>
        </div>
      )
    },
    filterFn: (row, id, value) => {
      return value.includes(row.getValue(id))
    },
  },
  {
    accessorKey: 'task',
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title='Task' />
    ),
    cell: ({ row }) => {
      return (
        <div className='flex space-x-2'>
          <span className='max-w-[150px] truncate font-mono text-xs'>
            {row.getValue('task')}
          </span>
        </div>
      )
    },
    filterFn: (row, id, value) => {
      return value.includes(row.getValue(id))
    },
  },
  {
    accessorKey: 'startDate',
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title='Start Date' />
    ),
    cell: ({ row }) => {
      const date = row.getValue('startDate') as string
      return (
        <div className='flex w-[100px] items-center'>
          <span className='text-sm'>
            {date ? format(new Date(date), 'MMM dd, yyyy') : '-'}
          </span>
        </div>
      )
    },
    filterFn: (row, id, value) => {
      return value.includes(row.getValue(id))
    },
  },
  {
    accessorKey: 'hoursWorked',
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title='Hours' />
    ),
    cell: ({ row }) => {
      const hours = row.getValue('hoursWorked') as number
      return (
        <div className='flex w-[80px] items-center'>
          <span className='text-sm font-medium'>
            {hours ? `${hours}h` : '-'}
          </span>
        </div>
      )
    },
  },
  {
    accessorKey: 'billableHours',
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title='Billable' />
    ),
    cell: ({ row }) => {
      const hours = row.getValue('billableHours') as number
      return (
        <div className='flex w-[80px] items-center'>
          <span className='text-sm font-medium'>
            {hours ? `${hours}h` : '-'}
          </span>
        </div>
      )
    },
  },
  {
    accessorKey: 'totalEarnings',
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title='Earnings' />
    ),
    cell: ({ row }) => {
      const earnings = row.getValue('totalEarnings') as number
      return (
        <div className='flex w-[100px] items-center'>
          <span className='text-sm font-medium'>
            {earnings ? `$${earnings.toFixed(2)}` : '-'}
          </span>
        </div>
      )
    },
  },
  {
    accessorKey: 'status',
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title='Status' />
    ),
    cell: ({ row }) => {
      const status = row.getValue('status') as keyof typeof statusColors

      if (!status) {
        return null
      }

      return (
        <div className='flex w-[100px] items-center'>
          <Badge 
            variant='secondary' 
            className={`capitalize ${statusColors[status]}`}
          >
            {status}
          </Badge>
        </div>
      )
    },
    filterFn: (row, id, value) => {
      return value.includes(row.getValue(id))
    },
  },
  {
    accessorKey: 'description',
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title='Description' />
    ),
    cell: ({ row }) => {
      const description = row.getValue('description') as string
      return (
        <div className='flex max-w-[200px] items-center'>
          <span className='truncate text-sm text-muted-foreground'>
            {description || '-'}
          </span>
        </div>
      )
    },
  },
  {
    id: 'actions',
    cell: ({ row }) => <DataTableRowActions row={row} />,
  },
]