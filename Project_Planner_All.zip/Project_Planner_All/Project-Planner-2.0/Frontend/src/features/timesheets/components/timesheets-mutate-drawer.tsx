import { z } from 'zod'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { Button } from '@/components/ui/button'
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import {
  Sheet,
  SheetClose,
  SheetContent,
  SheetDescription,
  SheetFooter,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet'
import { SelectDropdown } from '@/components/select-dropdown'
import { Timesheet, timesheetFormSchema, statusOptions } from '../data/schema'
import { useTimesheets } from '../hooks/use-timesheets'
import { useProjects } from '@/hooks/use-projects'
import { useTasks } from '@/hooks/use-tasks'
import { toast } from 'sonner'
import { useState, useEffect } from 'react'

interface Props {
  open: boolean
  onOpenChange: (open: boolean) => void
  currentRow?: Timesheet
}

type TimesheetForm = z.infer<typeof timesheetFormSchema>

export function TimesheetsMutateDrawer({ open, onOpenChange, currentRow }: Props) {
  const isUpdate = !!currentRow
  const { createTimesheet, updateTimesheet } = useTimesheets()
  const { getProjectOptions, isLoading: projectsLoading } = useProjects()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [selectedProject, setSelectedProject] = useState<string>('')
  
  const { getTaskOptions, isLoading: tasksLoading } = useTasks(selectedProject)

  const form = useForm<TimesheetForm>({
    resolver: zodResolver(timesheetFormSchema),
    defaultValues: {
      project: '',
      task: '',
      member: '',
      startDate: '',
      endDate: '',
      hoursWorked: 0,
      billableHours: 0,
      hourlyRate: 0,
      description: '',
      status: 'draft',
    },
  })

  // Reset form when currentRow changes
  useEffect(() => {
    if (currentRow) {
      form.reset({
        project: currentRow.project || '',
        task: currentRow.task || '',
        member: currentRow.member || '',
        startDate: currentRow.startDate || '',
        endDate: currentRow.endDate || '',
        hoursWorked: currentRow.hoursWorked || 0,
        billableHours: currentRow.billableHours || 0,
        hourlyRate: currentRow.hourlyRate || 0,
        description: currentRow.description || '',
        status: currentRow.status || 'draft',
      })
    } else {
      form.reset({
        project: '',
        task: '',
        member: '',
        startDate: '',
        endDate: '',
        hoursWorked: 0,
        billableHours: 0,
        hourlyRate: 0,
        description: '',
        status: 'draft',
      })
    }
  }, [currentRow, form])

  const onSubmit = async (data: TimesheetForm) => {
    setIsSubmitting(true)
    try {
      const timesheetData = {
        ...data,
        createdBy: 'current-user', // In real app, get from auth context
      }

      let result
      if (isUpdate && currentRow) {
        result = await updateTimesheet(currentRow.uid, timesheetData)
      } else {
        result = await createTimesheet(timesheetData)
      }

      if (result.success) {
        toast.success(isUpdate ? 'Timesheet updated successfully' : 'Timesheet created successfully')
        onOpenChange(false)
        form.reset()
      } else {
        toast.error(result.error || 'Something went wrong')
      }
    } catch (error) {
      console.error('Error submitting timesheet:', error)
      toast.error('Something went wrong')
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Sheet
      open={open}
      onOpenChange={(v) => {
        onOpenChange(v)
        if (!v) {
          form.reset()
        }
      }}
    >
      <SheetContent className='flex flex-col sm:max-w-md'>
        <SheetHeader className='text-left'>
          <SheetTitle>{isUpdate ? 'Update' : 'Create'} Timesheet</SheetTitle>
          <SheetDescription>
            {isUpdate
              ? 'Update the timesheet entry with the necessary information.'
              : 'Add a new timesheet entry by providing the necessary information.'}
            Click save when you&apos;re done.
          </SheetDescription>
        </SheetHeader>
        <Form {...form}>
          <form
            id='timesheet-form'
            onSubmit={form.handleSubmit(onSubmit)}
            className='flex-1 space-y-4 px-1'
          >
            <FormField
              control={form.control}
              name='project'
              render={({ field }) => (
                <FormItem className='space-y-1'>
                  <FormLabel>Project *</FormLabel>
                  <SelectDropdown
                    defaultValue={field.value}
                    onValueChange={(value) => {
                      field.onChange(value)
                      setSelectedProject(value)
                      // Reset task selection when project changes
                      form.setValue('task', '')
                    }}
                    placeholder={projectsLoading ? 'Loading projects...' : 'Select project'}
                    items={getProjectOptions()}
                    disabled={projectsLoading}
                  />
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name='task'
              render={({ field }) => (
                <FormItem className='space-y-1'>
                  <FormLabel>Task *</FormLabel>
                  <SelectDropdown
                    defaultValue={field.value}
                    onValueChange={field.onChange}
                    placeholder={tasksLoading ? 'Loading tasks...' : selectedProject ? 'Select task' : 'Select project first'}
                    items={getTaskOptions()}
                    disabled={tasksLoading || !selectedProject}
                  />
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name='member'
              render={({ field }) => (
                <FormItem className='space-y-1'>
                  <FormLabel>Member *</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder='Enter member name' />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className='grid grid-cols-2 gap-4'>
              <FormField
                control={form.control}
                name='startDate'
                render={({ field }) => (
                  <FormItem className='space-y-1'>
                    <FormLabel>Start Date *</FormLabel>
                    <FormControl>
                      <Input {...field} type='date' />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name='endDate'
                render={({ field }) => (
                  <FormItem className='space-y-1'>
                    <FormLabel>End Date</FormLabel>
                    <FormControl>
                      <Input {...field} type='date' />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className='grid grid-cols-2 gap-4'>
              <FormField
                control={form.control}
                name='hoursWorked'
                render={({ field }) => (
                  <FormItem className='space-y-1'>
                    <FormLabel>Hours Worked</FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        type='number' 
                        step='0.25'
                        min='0'
                        max='24'
                        onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name='billableHours'
                render={({ field }) => (
                  <FormItem className='space-y-1'>
                    <FormLabel>Billable Hours</FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        type='number' 
                        step='0.25'
                        min='0'
                        max='24'
                        onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name='hourlyRate'
              render={({ field }) => (
                <FormItem className='space-y-1'>
                  <FormLabel>Hourly Rate ($)</FormLabel>
                  <FormControl>
                    <Input 
                      {...field} 
                      type='number' 
                      step='0.01'
                      min='0'
                      onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name='status'
              render={({ field }) => (
                <FormItem className='space-y-1'>
                  <FormLabel>Status</FormLabel>
                  <SelectDropdown
                    defaultValue={field.value}
                    onValueChange={field.onChange}
                    placeholder='Select status'
                    items={statusOptions}
                  />
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name='description'
              render={({ field }) => (
                <FormItem className='space-y-1'>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field} 
                      placeholder='Enter description (optional)'
                      rows={3}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </form>
        </Form>
        <SheetFooter className='gap-2'>
          <SheetClose asChild>
            <Button variant='outline' disabled={isSubmitting}>
              Cancel
            </Button>
          </SheetClose>
          <Button 
            form='timesheet-form' 
            type='submit' 
            disabled={isSubmitting}
          >
            {isSubmitting ? 'Saving...' : 'Save changes'}
          </Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  )
}