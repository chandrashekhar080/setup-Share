import { Header } from '@/components/layout/header'
import { Main } from '@/components/layout/main'
import { ProfileDropdown } from '@/components/profile-dropdown'
import { Search } from '@/components/search'
import { ThemeSwitch } from '@/components/theme-switch'
import { columns } from './components/columns'
import { DataTable } from './components/data-table'
import { TimesheetsDialogs } from './components/timesheets-dialogs'
import { TimesheetsPrimaryButtons } from './components/timesheets-primary-buttons'
import TimesheetsProvider from './context/timesheets-context'
import { useTimesheets } from './hooks/use-timesheets'

export default function Timesheets() {
  const { timesheets, isLoading } = useTimesheets()

  return (
    <TimesheetsProvider>
      <Header fixed>
        <Search />
        <div className='ml-auto flex items-center space-x-4'>
          <ThemeSwitch />
          <ProfileDropdown />
        </div>
      </Header>

      <Main>
        <div className='mb-2 flex flex-wrap items-center justify-between space-y-2 gap-x-4'>
          <div>
            <h2 className='text-2xl font-bold tracking-tight'>Timesheets</h2>
            <p className='text-muted-foreground'>
              Track and manage your time entries for projects and tasks.
            </p>
          </div>
          <TimesheetsPrimaryButtons />
        </div>
        <div className='-mx-4 flex-1 overflow-auto px-4 py-1 lg:flex-row lg:space-y-0 lg:space-x-12'>
          <DataTable 
            data={timesheets || []} 
            columns={columns} 
            isLoading={isLoading}
          />
        </div>
      </Main>

      <TimesheetsDialogs />
    </TimesheetsProvider>
  )
}