import { useState, useEffect, useCallback } from 'react'
import { api, API_CONFIG } from '@/lib/api'
import { Timesheet } from '../data/schema'

interface UseTimesheetsOptions {
  project?: string
  task?: string
  member?: string
  status?: string
  startDate?: string
  endDate?: string
}

export function useTimesheets(options: UseTimesheetsOptions = {}) {
  const [timesheets, setTimesheets] = useState<Timesheet[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchTimesheets = useCallback(async () => {
    try {
      setIsLoading(true)
      setError(null)

      const queryParams = new URLSearchParams()
      if (options.project) queryParams.append('project', options.project)
      if (options.task) queryParams.append('task', options.task)
      if (options.member) queryParams.append('member', options.member)
      if (options.status) queryParams.append('status', options.status)
      if (options.startDate) queryParams.append('startDate', options.startDate)
      if (options.endDate) queryParams.append('endDate', options.endDate)

      const endpoint = `${API_CONFIG.ENDPOINTS.TIMESHEETS}${queryParams.toString() ? `?${queryParams.toString()}` : ''}`
      const data = await api.get<Timesheet[]>(endpoint)
      
      setTimesheets(data || [])
    } catch (err) {
      console.error('Error fetching timesheets:', err)
      setError(err instanceof Error ? err.message : 'Failed to fetch timesheets')
      setTimesheets([])
    } finally {
      setIsLoading(false)
    }
  }, [options.project, options.task, options.member, options.status, options.startDate, options.endDate])

  useEffect(() => {
    fetchTimesheets()
  }, [fetchTimesheets])

  const createTimesheet = useCallback(async (timesheetData: Partial<Timesheet>) => {
    try {
      await api.post(API_CONFIG.ENDPOINTS.TIMESHEETS, timesheetData)
      await fetchTimesheets() // Refresh the list
      return { success: true }
    } catch (err) {
      console.error('Error creating timesheet:', err)
      return { 
        success: false, 
        error: err instanceof Error ? err.message : 'Failed to create timesheet' 
      }
    }
  }, [fetchTimesheets])

  const updateTimesheet = useCallback(async (uid: string, timesheetData: Partial<Timesheet>) => {
    try {
      await api.post(API_CONFIG.ENDPOINTS.TIMESHEETS, { ...timesheetData, edit: uid })
      await fetchTimesheets() // Refresh the list
      return { success: true }
    } catch (err) {
      console.error('Error updating timesheet:', err)
      return { 
        success: false, 
        error: err instanceof Error ? err.message : 'Failed to update timesheet' 
      }
    }
  }, [fetchTimesheets])

  const deleteTimesheet = useCallback(async (uid: string) => {
    try {
      await api.post(`${API_CONFIG.ENDPOINTS.TIMESHEETS}deletetimesheet`, { uid })
      await fetchTimesheets() // Refresh the list
      return { success: true }
    } catch (err) {
      console.error('Error deleting timesheet:', err)
      return { 
        success: false, 
        error: err instanceof Error ? err.message : 'Failed to delete timesheet' 
      }
    }
  }, [fetchTimesheets])

  const submitTimesheet = useCallback(async (uid: string) => {
    try {
      await api.post(`${API_CONFIG.ENDPOINTS.TIMESHEETS}submit`, { uid })
      await fetchTimesheets() // Refresh the list
      return { success: true }
    } catch (err) {
      console.error('Error submitting timesheet:', err)
      return { 
        success: false, 
        error: err instanceof Error ? err.message : 'Failed to submit timesheet' 
      }
    }
  }, [fetchTimesheets])

  const approveTimesheet = useCallback(async (uid: string, approvedBy: string) => {
    try {
      await api.post(`${API_CONFIG.ENDPOINTS.TIMESHEETS}approve`, { 
        uid, 
        action: 'approve', 
        approvedBy 
      })
      await fetchTimesheets() // Refresh the list
      return { success: true }
    } catch (err) {
      console.error('Error approving timesheet:', err)
      return { 
        success: false, 
        error: err instanceof Error ? err.message : 'Failed to approve timesheet' 
      }
    }
  }, [fetchTimesheets])

  const rejectTimesheet = useCallback(async (uid: string, rejectedBy: string, reason: string) => {
    try {
      await api.post(`${API_CONFIG.ENDPOINTS.TIMESHEETS}approve`, { 
        uid, 
        action: 'reject', 
        approvedBy: rejectedBy,
        rejectionReason: reason
      })
      await fetchTimesheets() // Refresh the list
      return { success: true }
    } catch (err) {
      console.error('Error rejecting timesheet:', err)
      return { 
        success: false, 
        error: err instanceof Error ? err.message : 'Failed to reject timesheet' 
      }
    }
  }, [fetchTimesheets])

  const getTimesheetForEdit = useCallback(async (uid: string) => {
    try {
      const data = await api.post<Timesheet>(`${API_CONFIG.ENDPOINTS.TIMESHEETS}edittimesheet`, { uid })
      return { success: true, data }
    } catch (err) {
      console.error('Error fetching timesheet for edit:', err)
      return { 
        success: false, 
        error: err instanceof Error ? err.message : 'Failed to fetch timesheet' 
      }
    }
  }, [])

  return {
    timesheets,
    isLoading,
    error,
    fetchTimesheets,
    createTimesheet,
    updateTimesheet,
    deleteTimesheet,
    submitTimesheet,
    approveTimesheet,
    rejectTimesheet,
    getTimesheetForEdit,
  }
}