import { z } from 'zod'

// Timesheet schema matching the backend model
export const timesheetSchema = z.object({
  uid: z.string(),
  project: z.string(),
  task: z.string(),
  member: z.string(),
  startDate: z.string(),
  endDate: z.string().optional(),
  hoursWorked: z.number().optional(),
  billableHours: z.number().optional(),
  hourlyRate: z.number().optional(),
  description: z.string().optional(),
  status: z.enum(['draft', 'submitted', 'approved', 'rejected', 'paid']),
  approvedBy: z.string().optional(),
  approvedAt: z.string().optional(),
  rejectionReason: z.string().optional(),
  isActive: z.boolean().optional(),
  createdBy: z.string(),
  lastUpdatedBy: z.string().optional(),
  createdAt: z.string().optional(),
  updatedAt: z.string().optional(),
  totalEarnings: z.number().optional(),
  durationHours: z.number().optional(),
  efficiency: z.number().optional(),
})

export type Timesheet = z.infer<typeof timesheetSchema>

// Form schema for creating/editing timesheets
export const timesheetFormSchema = z.object({
  project: z.string().min(1, 'Project is required'),
  task: z.string().min(1, 'Task is required'),
  member: z.string().min(2, 'Member name must be at least 2 characters'),
  startDate: z.string().min(1, 'Start date is required'),
  endDate: z.string().optional(),
  hoursWorked: z.number().min(0, 'Hours worked cannot be negative').max(24, 'Hours worked cannot exceed 24').optional(),
  billableHours: z.number().min(0, 'Billable hours cannot be negative').max(24, 'Billable hours cannot exceed 24').optional(),
  hourlyRate: z.number().min(0, 'Hourly rate cannot be negative').optional(),
  description: z.string().max(1000, 'Description cannot exceed 1000 characters').optional(),
  status: z.enum(['draft', 'submitted', 'approved', 'rejected', 'paid']).optional(),
})

export type TimesheetForm = z.infer<typeof timesheetFormSchema>

// Status options for dropdowns
export const statusOptions = [
  { label: 'Draft', value: 'draft' },
  { label: 'Submitted', value: 'submitted' },
  { label: 'Approved', value: 'approved' },
  { label: 'Rejected', value: 'rejected' },
  { label: 'Paid', value: 'paid' },
] as const

// Status colors for badges
export const statusColors = {
  draft: 'bg-gray-100 text-gray-800',
  submitted: 'bg-blue-100 text-blue-800',
  approved: 'bg-green-100 text-green-800',
  rejected: 'bg-red-100 text-red-800',
  paid: 'bg-purple-100 text-purple-800',
} as const