import React, { useState } from 'react'
import useDialogState from '@/hooks/use-dialog-state'
import { Timesheet } from '../data/schema'

type TimesheetsDialogType = 'create' | 'update' | 'delete' | 'submit' | 'approve' | 'reject' | 'view'

interface TimesheetsContextType {
  open: TimesheetsDialogType | null
  setOpen: (str: TimesheetsDialogType | null) => void
  currentRow: Timesheet | null
  setCurrentRow: React.Dispatch<React.SetStateAction<Timesheet | null>>
  refreshTimesheets: () => void
  setRefreshTimesheets: React.Dispatch<React.SetStateAction<() => void>>
}

const TimesheetsContext = React.createContext<TimesheetsContextType | null>(null)

interface Props {
  children: React.ReactNode
}

export default function TimesheetsProvider({ children }: Props) {
  const [open, setOpen] = useDialogState<TimesheetsDialogType>(null)
  const [currentRow, setCurrentRow] = useState<Timesheet | null>(null)
  const [refreshTimesheets, setRefreshTimesheets] = useState<() => void>(() => () => {})

  return (
    <TimesheetsContext.Provider value={{ 
      open, 
      setOpen, 
      currentRow, 
      setCurrentRow,
      refreshTimesheets,
      setRefreshTimesheets
    }}>
      {children}
    </TimesheetsContext.Provider>
  )
}

// eslint-disable-next-line react-refresh/only-export-components
export const useTimesheetsContext = () => {
  const timesheetsContext = React.useContext(TimesheetsContext)

  if (!timesheetsContext) {
    throw new Error('useTimesheetsContext has to be used within <TimesheetsContext>')
  }

  return timesheetsContext
}