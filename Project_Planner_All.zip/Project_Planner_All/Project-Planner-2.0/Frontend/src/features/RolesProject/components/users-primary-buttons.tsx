import { IconPlus, IconRefresh } from '@tabler/icons-react'
import { Button } from '@/components/ui/button'
import { useUsers } from '../context/users-context'
import { useProjects } from '../hooks/use-projects'
import { useNavigate } from '@tanstack/react-router'

export function UsersPrimaryButtons() {
  const { setOpen } = useUsers()
  const { refresh, loading } = useProjects()
  const navigate=useNavigate()

  return (
    <div className='flex gap-2'>
      <Button
        variant="outline"
        onClick={refresh}
        disabled={loading}
        className='space-x-1'
      >
        <IconRefresh size={18} className={loading ? 'animate-spin' : ''} />
        <span>Refresh</span>
      </Button>
      <Button 
        onClick={() => navigate({ to: '/addRoles' })}
        className='space-x-1'
      >
        <span>Add Role</span> 
        <IconPlus size={18} />
      </Button>
    </div>
  )
}
