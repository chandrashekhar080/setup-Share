import { ColumnDef } from '@tanstack/react-table'
import { cn } from '@/lib/utils'
import { Checkbox } from '@/components/ui/checkbox'
import LongText from '@/components/long-text'
import { Project } from '../data/schema'
import { DataTableColumnHeader } from './data-table-column-header'
import { DataTableRowActions } from './data-table-row-actions'
import { formatCurrency } from '../api/projects-api'

export const columns: ColumnDef<Project>[] = [
  {
    id: 'select',
    header: ({ table }) => (
      <Checkbox
        checked={
          table.getIsAllPageRowsSelected() ||
          (table.getIsSomePageRowsSelected() && 'indeterminate')
        }
        onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
        aria-label='Select all'
        className='translate-y-[2px]'
      />
    ),
    meta: {
      className: cn(
        'sticky md:table-cell left-0 z-10 rounded-tl',
        'bg-background group-hover/row:bg-muted group-data-[state=selected]/row:bg-muted'
      ),
    },
    cell: ({ row }) => (
      <Checkbox
        checked={row.getIsSelected()}
        onCheckedChange={(value) => row.toggleSelected(!!value)}
        aria-label='Select row'
        className='translate-y-[2px]'
      />
    ),
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: 'uid',
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title='ID' />
    ),
    cell: ({ row }) => (
      <LongText className='max-w-24 font-mono text-xs'>{row.getValue('uid')}</LongText>
    ),
    meta: {
      className: cn(
        'drop-shadow-[0_1px_2px_rgb(0_0_0_/_0.1)] dark:drop-shadow-[0_1px_2px_rgb(255_255_255_/_0.1)] lg:drop-shadow-none',
        'bg-background group-hover/row:bg-muted group-data-[state=selected]/row:bg-muted',
        'sticky left-6 md:table-cell'
      ),
    },
    enableHiding: false,
  },
  {
    accessorKey: 'projectName',
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title='Role Name' />
    ),
    cell: ({ row }) => {
      const roleName = row.getValue('roleName') as string
      return <LongText className='max-w-48 font-medium'>{roleName}</LongText>
    },
    meta: { className: 'w-48' },
  },
  {
    accessorKey: 'Role Description',
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title='Role Description' />
    ),
    cell: ({ row }) => (
      <div className='w-fit text-nowrap max-w-32'>
        <LongText>{row.getValue('roleDescription')}</LongText>
      </div>
    ),
  },
  {
    accessorKey: 'Role Status',
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title='Role Status' />
    ),
    cell: ({ row }) => (
      <div className='w-fit text-nowrap max-w-32'>
        <LongText>{row.getValue('roleStatus')}</LongText>
      </div>
    ),
  },
  {
    accessorKey: 'Action',
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title='Action' />
    ),
    cell: ({ row }) => {
      const budget = row.getValue('action') as number
      return (
        <div className='w-fit text-nowrap font-medium'>
          {formatCurrency(budget)}
        </div>
      )
    },
  },
  {
    id: 'actions',
    cell: DataTableRowActions,
  },
]

// Legacy compatibility - keeping User type columns for existing components
export const userColumns = columns as ColumnDef<any>[]
