import { useState } from 'react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import { useNavigate } from '@tanstack/react-router'

const MODULES = [
  'Contracts',
  'Credit Notes ',
  'Customers',
  'Email Templates',
  'Estimates',
  'Expenses',
  'Invoices',
  'Items',
  'Knowledge Base',
  'Payments',
  'Projects',
  'Proposals',
  'Reports',
  'Staff Roles',
  'Settings',
  'Staff',
  'Subscriptions',
  'Tasks',
  'Task Checklist Templates',
  'Estimate Request',
  'Leads',
  'Inventory',
  'Account Planning',
  'Asset Management',
  'Site Manager',
  'HR Management',
  'Purchase Items',
  'Purchase Vendors',
  'Purchase Vendor-Items',
  'Purchase request',
  'Purchase Quotations',
  'Purchase Orders',
  'Purchase Order Return',
  'Purchase Contracts',
  'Purchase Invoices',
  'Purchase Debit Notes',
  'Purchase reports',
  'Purchase Settings',
  'Change the approval status of purchase orders',
  'Change the approval status of purchase quotations',
  'Change the approval status of purchase requests'
]

const PERMISSIONS = ['create', 'view', 'edit', 'delete', 'download', 'all'] as const

type PermissionType = (typeof PERMISSIONS)[number]

type RoleFormData = {
  roleName: string
  roleDescription: string
  roleStatus: string
  permissions: {
    [module: string]: {
      [key in PermissionType]: boolean
    }
  }
}

export default function RoleForm() {
  const [form, setForm] = useState<RoleFormData>({
    roleName: '',
    roleDescription: '',
    roleStatus: 'active',
    permissions: Object.fromEntries(
      MODULES.map((module) => [
        module,
        Object.fromEntries(PERMISSIONS.map((p) => [p, false])) as Record<PermissionType, boolean>,
      ])
    ),
  })

  const handleInputChange = (field: keyof RoleFormData, value: string) => {
    setForm((prev) => ({ ...prev, [field]: value }))
  }

  const handleCheckboxChange = (module: string, permission: PermissionType, checked: boolean) => {
    const updated = { ...form.permissions }
    updated[module][permission] = checked

    if (permission === 'all') {
      for (const p of PERMISSIONS) {
        updated[module][p] = checked
      }
    } else {
    
      updated[module].all =
        PERMISSIONS.slice(0, -1).every((p) => updated[module][p]) 
    }

    setForm((prev) => ({ ...prev, permissions: updated }))
  }

  const handleSubmit = () => {
    console.log('Submitted Role Data:', form)
  }
const navigate=useNavigate()
  return (
    <div className="p-6">
      <h2 className="text-xl font-semibold mb-4">Add Role & Permissions</h2>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Input
          placeholder="Role Name"
          value={form.roleName}
          onChange={(e) => handleInputChange('roleName', e.target.value)}
        />
        <Input
          placeholder="Role Description"
          value={form.roleDescription}
          onChange={(e) => handleInputChange('roleDescription', e.target.value)}
        />
        <Input
          placeholder="Active"
          value={form.roleStatus}
          onChange={(e) => handleInputChange('roleStatus', e.target.value)}
        />
      </div>

      <div className="overflow-x-auto ">
        <table className="min-w-full text-sm text-left border border-gray-300">
          <thead className="bg-gray-100">
            <tr>
              <th className="px-4 py-2 font-semibold">Module Name</th>
              {PERMISSIONS.map((perm) => (
                <th key={perm} className="border border-gray-300 px-8 py-2 capitalize font-semibold text-center">
                  {perm}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {MODULES.map((module) => (
              <tr key={module} className="border-t border-gray-300 even:bg-gray-50">
                <td className="border border-gray-300 px-4 py-2">{module}</td>
                {PERMISSIONS.map((perm) => (
                  <td key={perm} className="border border-gray-300 text-center">
                    <Checkbox className='border border-gray-300'
                      checked={form.permissions[module][perm]}
                      onCheckedChange={(checked) =>
                        handleCheckboxChange(module, perm, !!checked)
                      }
                    />
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-6 flex gap-4">
        <Button onClick={handleSubmit}>Save</Button>
        <Button variant="outline" onClick={() => navigate({ to: "/rolesProjects" })}>Cancel</Button>
      </div>
    </div>
  )
}
