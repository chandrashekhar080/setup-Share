import { Cross2Icon } from '@radix-ui/react-icons'
import { Table } from '@tanstack/react-table'
import { Button } from '@/components/ui/button'
import { DataTableViewOptions } from './data-table-view-options'
import { ProjectFilter } from '../data/schema'
import { useState, useEffect,  useMemo } from 'react'
import { useDebounce } from '@/hooks/use-debounce'
import { Loader2 } from 'lucide-react'

interface ProjectsTableToolbarProps<TData> {
  table: Table<TData>
  filter: ProjectFilter
  onFilterChange: (filter: ProjectFilter) => void
  loading?: boolean
}

export function ProjectsTableToolbar<TData>({
  table,
  filter,
  onFilterChange,
  loading,
}: ProjectsTableToolbarProps<TData>) {
  const [searchValue, setSearchValue] = useState(filter.q || '')
  const [customerValue, setCustomerValue] = useState(filter.customer || '')
  const [projectManagerValue, setProjectManagerValue] = useState(filter.projectManager || '')
  
  const isFiltered = useMemo(() => 
    Object.values(filter).some(value => value !== undefined && value !== ''), 
    [filter]
  )

  // Sync local state when filter prop changes from outside
  useEffect(() => {
    setSearchValue(filter.q || '')
    setCustomerValue(filter.customer || '')
    setProjectManagerValue(filter.projectManager || '')
  }, [filter.q, filter.customer, filter.projectManager])

  // Debounced filter update function
  const debouncedFilterUpdate = useDebounce((updates: Partial<ProjectFilter>) => {
    const newFilter = { ...filter, ...updates }
    onFilterChange(newFilter)
  }, 500)

  // Handle text input changes with debouncing
  useEffect(() => {
    const updates: Partial<ProjectFilter> = {}
    
    // Only include changed values
    if (searchValue !== (filter.q || '')) {
      updates.q = searchValue || undefined
    }
    if (customerValue !== (filter.customer || '')) {
      updates.customer = customerValue || undefined
    }
    if (projectManagerValue !== (filter.projectManager || '')) {
      updates.projectManager = projectManagerValue || undefined
    }

    // Only update if there are actual changes
    if (Object.keys(updates).length > 0) {
      debouncedFilterUpdate(updates)
    }
  }, [searchValue, customerValue, projectManagerValue, filter.q, filter.customer, filter.projectManager, debouncedFilterUpdate])

  const handleReset = () => {
    // Reset local state
    setSearchValue('')
    setCustomerValue('')
    setProjectManagerValue('')
    
    // Reset filters immediately
    onFilterChange({})
    table.resetColumnFilters()
  }

  return (
    <div className='flex items-center justify-between'>
      <div className='flex flex-1 flex-col-reverse items-start gap-y-2 sm:flex-row sm:items-center sm:space-x-2'>
        {/* Search Input */}
        {/* <Input
          placeholder='Search projects...'
          value={searchValue}
          onChange={(event) => handleSearchChange(event.target.value)}
          className='h-8 w-[150px] lg:w-[250px]'
        />
         */}
        {/* Customer Filter */}
        {/* <Input
          placeholder='Filter by customer...'
          value={customerValue}
          onChange={(event) => handleCustomerChange(event.target.value)}
          className='h-8 w-[150px] lg:w-[200px]'
        /> */}
        
        {/* Project Manager Filter */}
        {/* <Input
          placeholder='Filter by project manager...'
          value={projectManagerValue}
          onChange={(event) => handleProjectManagerChange(event.target.value)}
          className='h-8 w-[150px] lg:w-[200px]'
        /> */}
        
        <div className='flex gap-x-2'>
          {/* Status Filter */}
          {/* <Select value={filter.status || 'all'} onValueChange={handleStatusChange}>
            <SelectTrigger className='h-8 w-[120px]'>
              <SelectValue placeholder='Status' />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value='all'>All Status</SelectItem>
              <SelectItem value='planning'>Planning</SelectItem>
              <SelectItem value='in_progress'>In Progress</SelectItem>
              <SelectItem value='completed'>Completed</SelectItem>
              <SelectItem value='on_hold'>On Hold</SelectItem>
              <SelectItem value='cancelled'>Cancelled</SelectItem>
            </SelectContent>
          </Select> */}
          
          {/* Priority Filter */}
          {/* <Select value={filter.priority || 'all'} onValueChange={handlePriorityChange}>
            <SelectTrigger className='h-8 w-[120px]'>
              <SelectValue placeholder='Priority' />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value='all'>All Priority</SelectItem>
              <SelectItem value='low'>Low</SelectItem>
              <SelectItem value='medium'>Medium</SelectItem>
              <SelectItem value='high'>High</SelectItem>
              <SelectItem value='urgent'>Urgent</SelectItem>
            </SelectContent>
          </Select> */}
        </div>
        
        {/* Loading Indicator */}
        {loading && (
          <div className='flex items-center space-x-2 text-sm text-muted-foreground'>
            <Loader2 className='h-4 w-4 animate-spin' />
            <span>Filtering...</span>
          </div>
        )}

        {/* Reset Button */}
        {isFiltered && (
          <Button
            variant='ghost'
            onClick={handleReset}
            className='h-8 px-2 lg:px-3'
            disabled={loading}
          >
            Reset
            <Cross2Icon className='ml-2 h-4 w-4' />
          </Button>
        )}
      </div>
      <DataTableViewOptions table={table} />
    </div>
  )
}