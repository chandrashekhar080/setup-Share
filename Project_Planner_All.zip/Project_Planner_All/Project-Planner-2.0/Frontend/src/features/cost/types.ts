export type CostStatus = "paid" | "unpaid" | "overdue";

export type CostCategory =
  | "Rent"
  | "Utilities"
  | "Salaries"
  | "Marketing"
  | "Travel"
  | "Supplies"
  | "Software"
  | "Other";

export interface CostItem {
  id: string;
  date: string; // ISO date
  description: string;
  category: CostCategory;
  vendor?: string;
  amount: number;
  status: CostStatus;
  reference?: string; // invoice no / bill id
  createdBy?: string;
}
