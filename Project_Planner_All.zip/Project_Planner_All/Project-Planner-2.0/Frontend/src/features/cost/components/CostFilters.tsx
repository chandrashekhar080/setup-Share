import { useMemo, useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar as CalendarIcon, RotateCcw } from "lucide-react";
import { cn } from "@/lib/utils";
import type { CostCategory, CostItem, CostStatus } from "../types";
import { format } from "date-fns";

export interface FilterState {
  q: string;
  status: CostStatus | "all";
  category: CostCategory | "all";
  from?: Date;
  to?: Date;
}

const categories: CostCategory[] = [
  "Rent",
  "Utilities",
  "Salaries",
  "Marketing",
  "Travel",
  "Supplies",
  "Software",
  "Other",
];

export function useFilteredCosts(costs: CostItem[], filters: FilterState) {
  return useMemo(() => {
    return costs.filter((c) => {
      const q = filters.q.toLowerCase();
      const matchesQ = !q ||
        c.description.toLowerCase().includes(q) ||
        (c.vendor?.toLowerCase().includes(q)) ||
        (c.reference?.toLowerCase().includes(q));
      const matchesStatus = filters.status === "all" || c.status === filters.status;
      const matchesCategory = filters.category === "all" || c.category === filters.category;
      const d = new Date(c.date);
      const afterFrom = !filters.from || d >= new Date(filters.from.setHours(0,0,0,0));
      const beforeTo = !filters.to || d <= new Date(filters.to.setHours(23,59,59,999));
      return matchesQ && matchesStatus && matchesCategory && afterFrom && beforeTo;
    });
  }, [costs, filters]);
}

interface Props {
  value: FilterState;
  onChange: (v: FilterState) => void;
}

export default function CostFilters({ value, onChange }: Props) {
  const [fromOpen, setFromOpen] = useState(false);
  const [toOpen, setToOpen] = useState(false);

  function reset() {
    onChange({ q: "", status: "all", category: "all" });
  }

  return (
    <div className="flex flex-col gap-3 md:flex-row md:items-end md:gap-4">
      <div className="w-full md:max-w-xs">
        <Input
          placeholder="Search description, vendor, reference..."
          value={value.q}
          onChange={(e) => onChange({ ...value, q: e.target.value })}
        />
      </div>

      <div className="grid grid-cols-2 gap-3 md:flex md:flex-row md:items-center">
        <Select value={value.status} onValueChange={(v) => onChange({ ...value, status: v as any })}>
          <SelectTrigger className="w-[150px]"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All</SelectItem>
            <SelectItem value="paid">Paid</SelectItem>
            <SelectItem value="unpaid">Unpaid</SelectItem>
            <SelectItem value="overdue">Overdue</SelectItem>
          </SelectContent>
        </Select>

        <Select value={value.category} onValueChange={(v) => onChange({ ...value, category: v as any })}>
          <SelectTrigger className="w-[180px]"><SelectValue placeholder="Category" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All</SelectItem>
            {categories.map((c) => (
              <SelectItem key={c} value={c}>{c}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Popover open={fromOpen} onOpenChange={setFromOpen}>
          <PopoverTrigger asChild>
            <Button variant="outline" className={cn("justify-start w-[170px]", !value.from && "text-muted-foreground")}> 
              <CalendarIcon className="mr-2 h-4 w-4" />
              {value.from ? format(value.from, "MMM d, yyyy") : "From"}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="p-0" align="start">
            <Calendar mode="single" selected={value.from} onSelect={(d) => onChange({ ...value, from: d })} initialFocus />
          </PopoverContent>
        </Popover>

        <Popover open={toOpen} onOpenChange={setToOpen}>
          <PopoverTrigger asChild>
            <Button variant="outline" className={cn("justify-start w-[170px]", !value.to && "text-muted-foreground")}> 
              <CalendarIcon className="mr-2 h-4 w-4" />
              {value.to ? format(value.to, "MMM d, yyyy") : "To"}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="p-0" align="start">
            <Calendar mode="single" selected={value.to} onSelect={(d) => onChange({ ...value, to: d })} initialFocus />
          </PopoverContent>
        </Popover>

        <Button variant="ghost" className="md:ml-1" onClick={reset}>
          <RotateCcw className="mr-2 h-4 w-4" /> Reset
        </Button>
      </div>
    </div>
  );
}