import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Download, Plus } from "lucide-react";
import { columns as makeColumns } from "./columns";
import CostFormDialog from "./CostFormDialog";
import CostFilters, { FilterState, useFilteredCosts } from "./CostFilters";
import { CostTable } from "./CostTable";
import type { CostItem } from "../types";
import { mockCosts } from "../data/mock";

export default function CostsClient() {
  const [items, setItems] = useState<CostItem[]>(mockCosts);
  const [filters, setFilters] = useState<FilterState>({ q: "", status: "all", category: "all" });
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<CostItem | null>(null);

  const filtered = useFilteredCosts(items, filters);

  function handleSave(item: CostItem) {
    setItems((prev) => {
      const exists = prev.some((p) => p.id === item.id);
      if (exists) return prev.map((p) => (p.id === item.id ? item : p));
      return [item, ...prev];
    });
    setEditing(null);
  }

  function handleDelete(item: CostItem) {
    setItems((prev) => prev.filter((p) => p.id !== item.id));
  }

  function exportCSV() {
    const header = ["Date", "Description", "Category", "Vendor", "Amount", "Status", "Reference", "Created By"]; 
    const rows = filtered.map((c) => [
      new Date(c.date).toISOString(),
      c.description,
      c.category,
      c.vendor ?? "",
      c.amount,
      c.status,
      c.reference ?? "",
      c.createdBy ?? "",
    ]);
    const csv = [header, ...rows]
      .map((r) => r.map((v) => `"${String(v).replaceAll('"', '""')}"`).join(","))
      .join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `costs_export_${new Date().toISOString().slice(0,10)}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  const totals = useMemo(() => {
    const total = filtered.reduce((sum, i) => sum + i.amount, 0);
    const unpaid = filtered.filter((i) => i.status !== "paid").reduce((s, i) => s + i.amount, 0);
    const month = new Date().getMonth();
    const year = new Date().getFullYear();
    const thisMonth = filtered
      .filter((i) => {
        const d = new Date(i.date);
        return d.getMonth() === month && d.getFullYear() === year;
      })
      .reduce((s, i) => s + i.amount, 0);
    return { total, unpaid, thisMonth };
  }, [filtered]);

  const columns = useMemo(
    () => makeColumns((row) => { setEditing(row); setDialogOpen(true); }, handleDelete),
    [items]
  );

  return (
    <div className="space-y-6 p-6">
        
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Cost Management</h1>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={exportCSV}><Download className="mr-2 h-4 w-4"/>Export CSV</Button>
          <Button onClick={() => { setEditing(null); setDialogOpen(true); }}><Plus className="mr-2 h-4 w-4"/>Add Cost</Button>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-3">
        <Card className="shadow-sm">
          <CardHeader className="pb-2"><CardTitle className="text-sm">Total (Filtered)</CardTitle></CardHeader>
          <CardContent className="text-2xl font-semibold">₹ {totals.total.toLocaleString("en-IN")}</CardContent>
        </Card>
        <Card className="shadow-sm">
          <CardHeader className="pb-2"><CardTitle className="text-sm">This Month</CardTitle></CardHeader>
          <CardContent className="text-2xl font-semibold">₹ {totals.thisMonth.toLocaleString("en-IN")}</CardContent>
        </Card>
        <Card className="shadow-sm">
          <CardHeader className="pb-2"><CardTitle className="text-sm">Unpaid</CardTitle></CardHeader>
          <CardContent className="text-2xl font-semibold">₹ {totals.unpaid.toLocaleString("en-IN")}</CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CostFilters value={filters} onChange={setFilters} />
        </CardHeader>
        <Separator />
        <CardContent className="pt-6">
          <CostTable columns={columns} data={filtered} />
        </CardContent>
      </Card>

      <CostFormDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        onSave={handleSave}
        editing={editing}
      />
    </div>
  );
}
