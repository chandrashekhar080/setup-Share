import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { Calendar as CalendarIcon } from "lucide-react";
import type { CostCategory, CostItem, CostStatus } from "../types";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onSave: (item: CostItem) => void;
  editing?: CostItem | null;
}

const categories: CostCategory[] = [
  "Rent",
  "Utilities",
  "Salaries",
  "Marketing",
  "Travel",
  "Supplies",
  "Software",
  "Other",
];

export default function CostFormDialog({ open, onOpenChange, onSave, editing }: Props) {
  const [date, setDate] = useState<Date | undefined>(editing ? new Date(editing.date) : new Date());
  const [description, setDescription] = useState(editing?.description ?? "");
  const [category, setCategory] = useState<CostCategory>(editing?.category ?? "Other");
  const [vendor, setVendor] = useState(editing?.vendor ?? "");
  const [amount, setAmount] = useState(editing?.amount?.toString() ?? "");
  const [status, setStatus] = useState<CostStatus>(editing?.status ?? "unpaid");
  const [reference, setReference] = useState(editing?.reference ?? "");

  useEffect(() => {
    if (editing) {
      setDate(new Date(editing.date));
      setDescription(editing.description);
      setCategory(editing.category);
      setVendor(editing.vendor ?? "");
      setAmount(String(editing.amount));
      setStatus(editing.status);
      setReference(editing.reference ?? "");
    } else {
      setDate(new Date());
      setDescription("");
      setCategory("Other");
      setVendor("");
      setAmount("");
      setStatus("unpaid");
      setReference("");
    }
  }, [editing, open]);

  function handleSave() {
    if (!date || !description || !amount) return;
    const parsed = Number(amount);
    if (Number.isNaN(parsed)) return;
    const newItem: CostItem = {
      id: editing?.id ?? `c_${crypto.randomUUID()}`,
      date: date.toISOString(),
      description,
      category,
      vendor: vendor || undefined,
      amount: parsed,
      status,
      reference: reference || undefined,
      createdBy: editing?.createdBy ?? "You",
    };
    onSave(newItem);
    onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>{editing ? "Edit Cost" : "Add Cost"}</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-1 gap-4">
          <div className="grid gap-2">
            <Label>Date</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className={cn("justify-start", !date && "text-muted-foreground")}> 
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {date ? format(date, "PPP") : <span>Pick a date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="p-0" align="start">
                <Calendar mode="single" selected={date} onSelect={setDate} initialFocus />
              </PopoverContent>
            </Popover>
          </div>
          <div className="grid gap-2">
            <Label>Description</Label>
            <Input value={description} onChange={(e) => setDescription(e.target.value)} placeholder="e.g. Office Rent" />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label>Category</Label>
              <Select value={category} onValueChange={(v) => setCategory(v as CostCategory)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((c) => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label>Status</Label>
              <Select value={status} onValueChange={(v) => setStatus(v as any)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="paid">Paid</SelectItem>
                  <SelectItem value="unpaid">Unpaid</SelectItem>
                  <SelectItem value="overdue">Overdue</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label>Vendor</Label>
              <Input value={vendor} onChange={(e) => setVendor(e.target.value)} placeholder="e.g. ACME Pvt Ltd" />
            </div>
            <div className="grid gap-2">
              <Label>Amount (₹)</Label>
              <Input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0.00" />
            </div>
          </div>
          <div className="grid gap-2">
            <Label>Reference</Label>
            <Input value={reference} onChange={(e) => setReference(e.target.value)} placeholder="Invoice / Bill No." />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button onClick={handleSave}>{editing ? "Save Changes" : "Add Cost"}</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
