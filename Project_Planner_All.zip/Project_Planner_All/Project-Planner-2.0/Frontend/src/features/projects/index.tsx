import { Header } from '@/components/layout/header'
import { Main } from '@/components/layout/main'
import { ProfileDropdown } from '@/components/profile-dropdown'
import { Search } from '@/components/search'
import { ThemeSwitch } from '@/components/theme-switch'
import { columns } from '../projects/components/users-columns'
import { UsersDialogs } from '../projects/components/users-dialogs'
import { UsersPrimaryButtons } from '../projects/components/users-primary-buttons'
import { ProjectsTable } from '../projects/components/projects-table'
import UsersProvider from '../projects/context/users-context'
import { useProjects } from '../projects/hooks/use-projects'
import { useCallback } from 'react'
import { useProjectSocket } from '@/hooks/use-socket'
import { Skeleton } from '@/components/ui/skeleton'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { AlertTriangle, RefreshCw } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function Projects() {
  const { projects, loading, error, refresh, filter, updateFilter } = useProjects()

  // Use Socket.IO for real-time updates instead of custom events
  const stableRefresh = useCallback(() => {
    refresh()
  }, [refresh])

  useProjectSocket(stableRefresh)

  return (
    <UsersProvider>
      <Header fixed>
        <Search />
        <div className='ml-auto flex items-center space-x-4'>
          <ThemeSwitch />
          <ProfileDropdown />
        </div>
      </Header>

      <Main>
        <div className='mb-2 flex flex-wrap items-center justify-between space-y-2'>
          <div>
            <h2 className='text-2xl font-bold tracking-tight'>Projects List</h2>
            <p className='text-muted-foreground'>
              Manage your projects and track their progress here.
            </p>
          </div>
          <UsersPrimaryButtons />
        </div>

        {/* Loading State - Only show skeleton on initial load, not on filter changes */}
        {loading && projects.length === 0 && (
          <div className='space-y-4'>
            <div className='flex items-center space-x-4'>
              <Skeleton className='h-4 w-[250px]' />
              <Skeleton className='h-4 w-[200px]' />
            </div>
            <div className='space-y-2'>
              {Array.from({ length: 5 }).map((_, i) => (
                <Skeleton key={i} className='h-16 w-full' />
              ))}
            </div>
          </div>
        )}

        {/* Error State */}
        {error && !loading && (
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription className="flex items-center justify-between">
              <span>{error}</span>
              <Button
                variant="outline"
                size="sm"
                onClick={refresh}
                className="ml-4"
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Retry
              </Button>
            </AlertDescription>
          </Alert>
        )}

        {/* Data Table */}
        {(!loading || projects.length > 0) && !error && (
          <div className='-mx-4 flex-1 overflow-auto px-4 py-1 lg:flex-row lg:space-y-0 lg:space-x-12'>
            <div className={`transition-opacity duration-200 ${loading ? 'opacity-70' : 'opacity-100'}`}>
              <ProjectsTable 
                data={projects} 
                columns={columns} 
                filter={filter}
                onFilterChange={updateFilter}
                loading={loading}
              />
            </div>
          </div>
        )}

        {/* Empty State */}
        {!loading && !error && projects.length === 0 && (
          <div className='flex flex-col items-center justify-center py-12'>
            <div className='text-center'>
              <h3 className='text-lg font-medium text-gray-900 dark:text-gray-100'>
                No projects found
              </h3>
              <p className='text-sm text-gray-500 dark:text-gray-400 mt-1'>
                Get started by creating your first project.
              </p>
            </div>
          </div>
        )}
      </Main>

      <UsersDialogs />
    </UsersProvider>
  )
}
