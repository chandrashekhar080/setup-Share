import { ColumnDef } from '@tanstack/react-table'
import { cn } from '@/lib/utils'
import { Badge } from '@/components/ui/badge'
import { Checkbox } from '@/components/ui/checkbox'
import LongText from '@/components/long-text'
import { statusColors, statusLabels, priorityColors, priorityLabels } from '../data/data'
import { Project } from '../data/schema'
import { DataTableColumnHeader } from './data-table-column-header'
import { DataTableRowActions } from './data-table-row-actions'
import { formatCurrency } from '../api/projects-api'

export const columns: ColumnDef<Project>[] = [
  {
    id: 'select',
    header: ({ table }) => (
      <Checkbox
        checked={
          table.getIsAllPageRowsSelected() ||
          (table.getIsSomePageRowsSelected() && 'indeterminate')
        }
        onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
        aria-label='Select all'
        className='translate-y-[2px]'
      />
    ),
    meta: {
      className: cn(
        'sticky md:table-cell left-0 z-10 rounded-tl',
        'bg-background group-hover/row:bg-muted group-data-[state=selected]/row:bg-muted'
      ),
    },
    cell: ({ row }) => (
      <Checkbox
        checked={row.getIsSelected()}
        onCheckedChange={(value) => row.toggleSelected(!!value)}
        aria-label='Select row'
        className='translate-y-[2px]'
      />
    ),
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: 'uid',
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title='ID' />
    ),
    cell: ({ row }) => (
      <LongText className='max-w-24 font-mono text-xs'>{row.getValue('uid')}</LongText>
    ),
    meta: {
      className: cn(
        'drop-shadow-[0_1px_2px_rgb(0_0_0_/_0.1)] dark:drop-shadow-[0_1px_2px_rgb(255_255_255_/_0.1)] lg:drop-shadow-none',
        'bg-background group-hover/row:bg-muted group-data-[state=selected]/row:bg-muted',
        'sticky left-6 md:table-cell'
      ),
    },
    enableHiding: false,
  },
  {
    accessorKey: 'projectName',
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title='Project Name' />
    ),
    cell: ({ row }) => {
      const projectName = row.getValue('projectName') as string
      return <LongText className='max-w-48 font-medium'>{projectName}</LongText>
    },
    meta: { className: 'w-48' },
  },
  {
    accessorKey: 'customer',
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title='Customer' />
    ),
    cell: ({ row }) => (
      <div className='w-fit text-nowrap max-w-32'>
        <LongText>{row.getValue('customer')}</LongText>
      </div>
    ),
  },
  {
    accessorKey: 'projectManager',
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title='Manager' />
    ),
    cell: ({ row }) => (
      <div className='w-fit text-nowrap max-w-32'>
        <LongText>{row.getValue('projectManager')}</LongText>
      </div>
    ),
  },
  {
    accessorKey: 'totalBudget',
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title='Budget' />
    ),
    cell: ({ row }) => {
      const budget = row.getValue('totalBudget') as number
      return (
        <div className='w-fit text-nowrap font-medium'>
          {formatCurrency(budget)}
        </div>
      )
    },
  },
  {
    accessorKey: 'progress',
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title='Progress' />
    ),
    cell: ({ row }) => {
      const progress = (row.getValue('progress') as number) || 0
      return (
        <div className='flex items-center space-x-2'>
          <div className='w-16 bg-gray-200 rounded-full h-2'>
            <div
              className='bg-blue-600 h-2 rounded-full transition-all duration-300'
              style={{ width: `${progress}%` }}
            />
          </div>
          <span className='text-xs font-medium w-8'>{progress}%</span>
        </div>
      )
    },
    enableSorting: true,
  },
  {
    accessorKey: 'status',
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title='Status' />
    ),
    cell: ({ row }) => {
      const status = row.getValue('status') as string
      const badgeColor = statusColors.get(status as any)
      const statusLabel = statusLabels.get(status as any) || status
      return (
        <div className='flex space-x-2'>
          <Badge variant='outline' className={cn('capitalize', badgeColor)}>
            {statusLabel}
          </Badge>
        </div>
      )
    },
    filterFn: (row, id, value) => {
      return value.includes(row.getValue(id))
    },
    enableHiding: false,
    enableSorting: false,
  },
  {
    accessorKey: 'priority',
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title='Priority' />
    ),
    cell: ({ row }) => {
      const priority = row.getValue('priority') as string
      const badgeColor = priorityColors.get(priority as any)
      const priorityLabel = priorityLabels.get(priority as any) || priority
      return (
        <div className='flex space-x-2'>
          <Badge variant='outline' className={cn('capitalize', badgeColor)}>
            {priorityLabel}
          </Badge>
        </div>
      )
    },
    filterFn: (row, id, value) => {
      return value.includes(row.getValue(id))
    },
    enableSorting: false,
  },
  {
    accessorKey: 'endDate',
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title='Due Date' />
    ),
    cell: ({ row }) => {
      const endDate = row.getValue('endDate') as string
      const date = new Date(endDate)
      const isOverdue = row.original.isOverdue
      return (
        <div className={cn(
          'w-fit text-nowrap text-sm',
          isOverdue && 'text-red-600 font-medium'
        )}>
          {date.toLocaleDateString()}
          {isOverdue && (
            <span className='ml-1 text-xs'>(Overdue)</span>
          )}
        </div>
      )
    },
    enableSorting: true,
  },
  {
    id: 'actions',
    cell: DataTableRowActions,
  },
]

// Legacy compatibility - keeping User type columns for existing components
export const userColumns = columns as ColumnDef<any>[]
