import { z } from 'zod'

// Task schema matching the backend model
export const taskSchema = z.object({
  uid: z.string(),
  taskname: z.string(),
  project: z.string(),
  assignee: z.string().nullable().optional(),
  duedate: z.string().nullable().optional(),
  priority: z.enum(['low', 'medium', 'high', 'urgent']).optional(),
  progress: z.number().min(0).max(100).optional(),
  comments: z.string().nullable().optional(),
  status: z.enum(['todo', 'in-progress', 'completed', 'cancelled']).optional(),
  label: z.string().nullable().optional(), // For UI labels/tags
  isActive: z.union([z.boolean(), z.number()]).optional(), // API returns 1/0 instead of true/false
  createdBy: z.string().nullable().optional(),
  lastUpdatedBy: z.string().nullable().optional(),
  createdAt: z.string().optional(),
  updatedAt: z.string().optional(),
})

export type Task = z.infer<typeof taskSchema>

// Form schema for creating/editing tasks
export const taskFormSchema = z.object({
  taskname: z.string().min(1, 'Task name is required'),
  project: z.string().min(1, 'Project is required'),
  assignee: z.string().optional(),
  duedate: z.string().optional(),
  priority: z.enum(['low', 'medium', 'high', 'urgent']).optional(),
  progress: z.number().min(0, 'Progress cannot be negative').max(100, 'Progress cannot exceed 100').optional(),
  comments: z.string().optional(),
  status: z.enum(['todo', 'in-progress', 'completed', 'cancelled']).optional(),
})

export type TaskForm = z.infer<typeof taskFormSchema>

// Priority options for dropdowns
export const priorityOptions = [
  { label: 'Low', value: 'low' },
  { label: 'Medium', value: 'medium' },
  { label: 'High', value: 'high' },
  { label: 'Urgent', value: 'urgent' },
] as const

// Status options for dropdowns
export const statusOptions = [
  { label: 'To Do', value: 'todo' },
  { label: 'In Progress', value: 'in-progress' },
  { label: 'Completed', value: 'completed' },
  { label: 'Cancelled', value: 'cancelled' },
] as const

// Priority colors for badges
export const priorityColors = {
  low: 'bg-gray-100 text-gray-800',
  medium: 'bg-blue-100 text-blue-800',
  high: 'bg-orange-100 text-orange-800',
  urgent: 'bg-red-100 text-red-800',
} as const

// Status colors for badges
export const statusColors = {
  'todo': 'bg-gray-100 text-gray-800',
  'in-progress': 'bg-blue-100 text-blue-800',
  'completed': 'bg-green-100 text-green-800',
  'cancelled': 'bg-red-100 text-red-800',
} as const
