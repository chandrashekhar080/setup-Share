import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { mockInvoices } from "./data"
import { Invoice } from "./types"
import InvoiceTable from "./InvoiceTable"
import InvoiceDialog from "./InvoiceDialog"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"

export default function Invoices() {
  const [invoices, setInvoices] = useState<Invoice[]>(mockInvoices)
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null)
  const [editingInvoice, setEditingInvoice] = useState<Invoice | null>(null)
  const [search, setSearch] = useState("")

  const handleCreate = (newInvoice: Omit<Invoice, "id">) => {
    const id = `INV-${(invoices.length + 1).toString().padStart(3, "0")}`
    setInvoices([...invoices, { ...newInvoice, id }])
  }

  const handleDelete = (id: string) => {
    setInvoices((prev) => prev.filter((inv) => inv.id !== id))
  }

  const handleUpdate = (updated: Invoice) => {
    setInvoices((prev) =>
      prev.map((inv) => (inv.id === updated.id ? updated : inv))
    )
    setEditingInvoice(null)
  }

  const filteredInvoices = invoices.filter(
    (inv) =>
      inv.client.toLowerCase().includes(search.toLowerCase()) ||
      inv.id.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className="p-6 space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <h1 className="text-2xl font-semibold">Invoices</h1>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Input
            placeholder="Search invoices..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full sm:w-[250px]"
          />
          <InvoiceDialog onCreate={handleCreate} />
        </div>
      </div>

      {/* Table inside card */}
      <Card className="rounded-2xl shadow-md">
        <CardContent>
          <InvoiceTable
            invoices={filteredInvoices}
            onView={(inv) => setSelectedInvoice(inv)}
            onEdit={(inv) => setEditingInvoice(inv)}
            onDelete={handleDelete}
          />
        </CardContent>
      </Card>

      {/* View Dialog */}
      <Dialog
        open={!!selectedInvoice}
        onOpenChange={() => setSelectedInvoice(null)}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Invoice Details</DialogTitle>
          </DialogHeader>
          {selectedInvoice && (
            <div className="space-y-2">
              <p>
                <b>ID:</b> {selectedInvoice.id}
              </p>
              <p>
                <b>Client:</b> {selectedInvoice.client}
              </p>
              <p>
                <b>Date:</b> {selectedInvoice.date}
              </p>
              <p>
                <b>Amount:</b> {selectedInvoice.amount}
              </p>
              <p>
                <b>Status:</b> {selectedInvoice.status}
              </p>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      {editingInvoice && (
        <InvoiceDialog
          invoice={editingInvoice}
          onUpdate={handleUpdate}
          triggerButton={false}
          onClose={() => setEditingInvoice(null)}
        />
      )}
    </div>
  )
}
