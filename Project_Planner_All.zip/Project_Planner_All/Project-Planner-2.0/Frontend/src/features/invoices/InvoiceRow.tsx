import { Button } from "@/components/ui/button"
import { TableCell, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Eye, Pencil, Trash2 } from "lucide-react"
import { Invoice } from "./types"

export default function InvoiceRow({
  invoice,
  onView,
  onEdit,
  onDelete,
}: {
  invoice: Invoice
  onView: (invoice: Invoice) => void
  onEdit: (invoice: Invoice) => void
  onDelete: (id: string) => void
}) {
  return (
    <TableRow>
      <TableCell className="font-medium">{invoice.id}</TableCell>
      <TableCell>{invoice.client}</TableCell>
      <TableCell>{invoice.date}</TableCell>
      <TableCell>{invoice.amount}</TableCell>
      <TableCell>
        <Badge
          variant={
            invoice.status === "Paid"
              ? "default"
              : invoice.status === "Pending"
              ? "secondary"
              : "destructive"
          }
        >
          {invoice.status}
        </Badge>
      </TableCell>
      <TableCell className="flex gap-2 justify-end">
        <Button size="sm" variant="outline" onClick={() => onView(invoice)}>
          <Eye className="h-4 w-4 mr-1" /> View
        </Button>
        <Button size="sm" variant="outline" onClick={() => onEdit(invoice)}>
          <Pencil className="h-4 w-4 mr-1" /> Edit
        </Button>
        <Button
          size="sm"
          variant="destructive"
          onClick={() => onDelete(invoice.id)}
        >
          <Trash2 className="h-4 w-4 mr-1" /> Delete
        </Button>
      </TableCell>
    </TableRow>
  )
}
