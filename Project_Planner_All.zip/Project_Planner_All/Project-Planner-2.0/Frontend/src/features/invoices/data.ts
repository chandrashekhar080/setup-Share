import { Invoice } from "./types"

export const mockInvoices: Invoice[] = [
  {
    id: "INV-001",
    client: "Acme Corp",
    date: "2025-08-01",
    amount: "$2,500",
    status: "Paid",
  },
  {
    id: "INV-002",
    client: "Globex Inc",
    date: "2025-08-10",
    amount: "$1,200",
    status: "Pending",
  },
  {
    id: "INV-003",
    client: "Soylent Ltd",
    date: "2025-07-28",
    amount: "$800",
    status: "Overdue",
  },
]
