export type Invoice = {
  id: string
  client: string
  date: string
  amount: string
  status: "Paid" | "Pending" | "Overdue"
}
