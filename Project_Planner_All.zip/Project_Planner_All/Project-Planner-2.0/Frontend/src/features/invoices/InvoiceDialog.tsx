import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Invoice } from "./types"

type InvoiceForm = {
  client: string
  date: string
  amount: string
  status: "Paid" | "Pending" | "Overdue"
}

export default function InvoiceDialog({
  invoice,
  onCreate,
  onUpdate,
  triggerButton = true,
  onClose,
}: {
  invoice?: Invoice | null
  onCreate?: (invoice: Omit<Invoice, "id">) => void
  onUpdate?: (invoice: Invoice) => void
  triggerButton?: boolean
  onClose?: () => void
}) {
  const [form, setForm] = useState<InvoiceForm>({
    client: "",
    date: "",
    amount: "",
    status: "Pending",
  })

  const [open, setOpen] = useState(false)

  // Prefill when editing
  useEffect(() => {
    if (invoice) {
      setForm({
        client: invoice.client,
        date: invoice.date,
        amount: invoice.amount,
        status: invoice.status,
      })
      setOpen(true) // open dialog when editing
    }
  }, [invoice])

  const handleChange = (key: keyof InvoiceForm, value: string) => {
    setForm((prev) => ({ ...prev, [key]: value }))
  }

  const handleSubmit = () => {
    if (!form.client || !form.amount || !form.date) return

    if (invoice && onUpdate) {
      onUpdate({ ...invoice, ...form })
    } else if (onCreate) {
      onCreate(form)
    }

    setOpen(false)
    if (onClose) onClose()
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      {triggerButton && !invoice && (
        <DialogTrigger asChild>
          <Button size="sm" onClick={() => setOpen(true)}>+ New Invoice</Button>
        </DialogTrigger>
      )}
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>
            {invoice ? "Edit Invoice" : "Create Invoice"}
          </DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-2">
          <div className="grid gap-2">
            <Label>Client</Label>
            <Input
              value={form.client}
              onChange={(e) => handleChange("client", e.target.value)}
            />
          </div>
          <div className="grid gap-2">
            <Label>Date</Label>
            <Input
              type="date"
              value={form.date}
              onChange={(e) => handleChange("date", e.target.value)}
            />
          </div>
          <div className="grid gap-2">
            <Label>Amount</Label>
            <Input
              type="text"
              value={form.amount}
              onChange={(e) => handleChange("amount", e.target.value)}
            />
          </div>
          <div className="grid gap-2">
            <Label>Status</Label>
            <Select
              value={form.status}
              onValueChange={(v) => handleChange("status", v)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Paid">Paid</SelectItem>
                <SelectItem value="Pending">Pending</SelectItem>
                <SelectItem value="Overdue">Overdue</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <Button className="w-full mt-2" onClick={handleSubmit}>
          {invoice ? "Update" : "Create"}
        </Button>
      </DialogContent>
    </Dialog>
  )
}
