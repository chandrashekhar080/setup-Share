// src/data/users.ts

export const User = [
  {
    id: "1",
    company: "Tech Solutions Pvt Ltd",
    primaryContact: "Rajesh Sharma",
    primaryEmail: "rajesh.sharma@techsolutions.com",
    phone: "+91 98765 43210",
    active: true,
    group: "A",
    dateCreated: new Date("2023-05-10"),
  },
  {
    id: "2",
    company: "Global Traders Inc",
    primaryContact: "Anita Verma",
    primaryEmail: "anita.verma@globaltraders.com",
    phone: "+91 91234 56789",
    active: false,
    group: "B",
    dateCreated: new Date("2022-11-15"),
  },
  {
    id: "3",
    company: "Future Tech Labs",
    primaryContact: "Vikram Singh",
    primaryEmail: "vikram.singh@futuretech.com",
    phone: "+91 99887 77665",
    active: true,
    group: "C",
    dateCreated: new Date("2024-02-20"),
  },
]
