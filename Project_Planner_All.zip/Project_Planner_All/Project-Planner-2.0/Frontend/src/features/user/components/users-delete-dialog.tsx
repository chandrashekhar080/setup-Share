'use client'

import { useState } from 'react'
import { IconAlertTriangle } from '@tabler/icons-react'
import { showSubmittedData } from '@/utils/show-submitted-data'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { ConfirmDialog } from '@/components/confirm-dialog'
import { User } from '../data/schema' // <-- using Company schema

interface Props {
  open: boolean
  onOpenChange: (open: boolean) => void
  currentRow: User
}

export function CompanyDeleteDialog({ open, onOpenChange, currentRow }: Props) {
  const [value, setValue] = useState('')

  const handleDelete = () => {
    if (value.trim() !== currentRow.company) return

    onOpenChange(false)
    showSubmittedData(currentRow, 'The following company has been deleted:')
  }

  return (
    <ConfirmDialog
      open={open}
      onOpenChange={onOpenChange}
      handleConfirm={handleDelete}
      disabled={value.trim() !== currentRow.company}
      title={
        <span className='text-destructive'>
          <IconAlertTriangle
            className='stroke-destructive mr-1 inline-block'
            size={18}
          />{' '}
          Delete Company
        </span>
      }
      desc={
        <div className='space-y-4'>
          <p className='mb-2'>
            Are you sure you want to delete company{' '}
            <span className='font-bold'>{currentRow.company}</span>?
            <br />
            This will permanently remove the company record created on{' '}
            <span className='font-bold'>
              {new Date(currentRow.dateCreated).toLocaleDateString()}
            </span>{' '}
            with primary contact{' '}
            <span className='font-bold'>{currentRow.primaryContact}</span>.
          </p>

          <div className="grid gap-2 text-sm">
            <p><strong>Email:</strong> {currentRow.primaryEmail}</p>
            <p><strong>Phone:</strong> {currentRow.phone}</p>
            <p><strong>Group:</strong> {currentRow.group}</p>
            <p><strong>Status:</strong> {currentRow.active ? "Active" : "Inactive"}</p>
          </div>

          <Label className='my-2'>
            Company Name:
            <Input
              value={value}
              onChange={(e) => setValue(e.target.value)}
              placeholder='Enter company name to confirm deletion.'
            />
          </Label>

          <Alert variant='destructive'>
            <AlertTitle>Warning!</AlertTitle>
            <AlertDescription>
              This operation cannot be rolled back. Please confirm carefully.
            </AlertDescription>
          </Alert>
        </div>
      }
      confirmText='Delete'
      destructive
    />
  )
}
