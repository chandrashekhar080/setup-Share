// app/(dashboard)/notifications/api/api.ts

export async function getNotifications() {
  await new Promise((r) => setTimeout(r, 500)) // simulate delay

  return [
    {
      id: '1',
      title: 'New Project Created',
      message: 'Project "Website Redesign" has been created by Shivani.',
      createdAt: new Date().toISOString(),
      read: false,
    },
    {
      id: '2',
      title: 'You’ve been invited',
      message: 'You’ve been invited to join "Team Alpha".',
      createdAt: new Date(Date.now() - 1000 * 60 * 60).toISOString(),
      read: false,
    },
    {
      id: '3',
      title: 'Role Updated',
      message: 'Your role has been updated to "Editor".',
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
      read: true,
    },
    {
      id: '4',
      title: 'Access Changed',
      message: 'You now have download access to Project X.',
      createdAt: new Date(Date.now() - 1000 * 60 * 5).toISOString(),
      read: false,
    },
  ]
}
