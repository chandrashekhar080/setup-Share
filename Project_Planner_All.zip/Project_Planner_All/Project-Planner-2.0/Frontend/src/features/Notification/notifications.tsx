'use client'

import { useEffect, useState } from 'react'
import { BellIcon } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Card } from '@/components/ui/card'
import { cn } from '@/lib/utils'
import { getNotifications } from './api/api'
import { Header } from '@/components/layout/header'
import { TopNav } from '@/components/layout/top-nav'
import { Search } from '@/components/search'
import { ThemeSwitch } from '@/components/theme-switch'
import { ProfileDropdown } from '@/components/profile-dropdown'

type Notification = {
  id: string
  title: string
  message: string
  createdAt: string
  read: boolean
}

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await getNotifications()
        // Sort by newest first
        const sorted = data.sort(
          (a: Notification, b: Notification) =>
            new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        )
        setNotifications(sorted)
      } catch (err) {
        console.error('Error fetching notifications', err)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  const handleMarkAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((notif) =>
        notif.id === id ? { ...notif, read: true } : notif
      )
    )
    // Optionally call backend to mark read
  }
const topNav = [
  {
    title: 'Overview',
    href: 'dashboard/overview',
    isActive: true,
    disabled: false,
  },
  {
    title: 'Customers',
    href: 'dashboard/customers',
    isActive: false,
    disabled: true,
  },
  {
    title: 'Products',
    href: 'dashboard/products',
    isActive: false,
    disabled: true,
  },
  {
    title: 'Settings',
    href: 'dashboard/settings',
    isActive: false,
    disabled: true,
  },
]

  return (
    <div className="p-6 space-y-6">
        <Header>
                      <TopNav links={topNav} />
                      <div className='ml-auto flex items-center space-x-4'>
                        <Search />
                        <ThemeSwitch />
                        <ProfileDropdown />
                      </div>
                    </Header>
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-semibold flex items-center gap-2">
          <BellIcon className="w-6 h-6" />
          Notifications
        </h2>
      </div>

      {loading ? (
        <div className="space-y-4">
          {Array.from({ length: 5 }).map((_, i) => (
            <Card key={i} className="p-4">
              <Skeleton className="h-4 w-1/3 mb-2" />
              <Skeleton className="h-3 w-2/3" />
            </Card>
          ))}
        </div>
      ) : notifications.length === 0 ? (
        <div className="text-center text-muted-foreground">
          No notifications found.
        </div>
      ) : (
        <div className="space-y-4">
          {notifications.map((notif) => (
            <Card
              key={notif.id}
              onClick={() => handleMarkAsRead(notif.id)}
              className={cn(
                'p-4 transition hover:shadow-md cursor-pointer',
                !notif.read && 'border-blue-600 border'
              )}
            >
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-semibold">{notif.title}</h3>
                  <p className="text-sm text-muted-foreground">
                    {notif.message}
                  </p>
                  <p className="text-xs text-gray-400 mt-1">
                    {new Date(notif.createdAt).toLocaleString()}
                  </p>
                </div>
                {!notif.read && <Badge variant="default">New</Badge>}
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
