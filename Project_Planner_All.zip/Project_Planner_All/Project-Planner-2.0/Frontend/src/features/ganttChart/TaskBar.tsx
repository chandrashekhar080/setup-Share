import React from 'react';
import { Task } from './types';
import { getOffsetPercentage, getWidthPercentage } from './dateUtils';

interface TaskBarProps {
  task: Task;
  timelineStart: string;
  timelineDays: number;
}

const TaskBar: React.FC<TaskBarProps> = ({ task, timelineStart, timelineDays }) => {
  return (
    <div
      className="absolute h-8 bg-blue-500 text-white text-xs flex items-center justify-center rounded-md"
      style={{
        width: `${getWidthPercentage(task.start, task.end, timelineDays)}%`,
        left: `${getOffsetPercentage(task.start, timelineStart, timelineDays)}%`,
      }}
    >
      {task.name}
    </div>
  );
};

export default TaskBar;
