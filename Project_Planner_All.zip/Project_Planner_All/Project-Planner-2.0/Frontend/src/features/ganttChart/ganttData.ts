import { Module } from './types';

export const ganttModules: Module[] = [
  {
    module: 'Project Management',
    tasks: [
      { name: 'Planning', start: '2025-08-18', end: '2025-09-05', color: '#3b82f6' },
      { name: 'Execution', start: '2025-09-06', end: '2025-09-20', color: '#2563eb' },
    ],
  },
  {
    module: 'User Management',
    tasks: [
      { name: 'Roles & Permissions', start: '2025-08-25', end: '2025-09-10', color: '#f97316' },
    ],
  },
  {
    module: 'Task Management',
    tasks: [
      { name: 'Create Tasks', start: '2025-09-01', end: '2025-09-12', color: '#16a34a' },
    ],
  },
  {
    module: 'Document Management',
    tasks: [
      { name: 'Upload Docs', start: '2025-09-03', end: '2025-09-15', color: '#f43f5e' },
    ],
  },
  {
    module: 'Invoices',
    tasks: [
      { name: 'Invoice Generation', start: '2025-09-05', end: '2025-09-18', color: '#7c3aed' },
    ],
  },
  {
    module: 'Cost Management',
    tasks: [
      { name: 'Budgeting', start: '2025-09-08', end: '2025-09-22', color: '#eab308' },
    ],
  },
  {
    module: 'Resource Management',
    tasks: [
      { name: 'Resource Allocation', start: '2025-09-10', end: '2025-09-25', color: '#0ea5e9' },
    ],
  },
];
