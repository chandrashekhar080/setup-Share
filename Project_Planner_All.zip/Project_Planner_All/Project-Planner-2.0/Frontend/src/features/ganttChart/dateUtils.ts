export const getDaysDifference = (start: string, end: string) => {
  const startDate = new Date(start).getTime();
  const endDate = new Date(end).getTime();
  return Math.ceil((endDate - startDate) / (1000 * 60 * 60 * 24));
};

export const getOffsetPercentage = (start: string, timelineStart: string, timelineDays: number) => {
  const startDate = new Date(start).getTime();
  const baseDate = new Date(timelineStart).getTime();
  const offsetDays = (startDate - baseDate) / (1000 * 60 * 60 * 24);
  return (offsetDays / timelineDays) * 100;
};

export const getWidthPercentage = (start: string, end: string, timelineDays: number) => {
  const days = getDaysDifference(start, end);
  return (days / timelineDays) * 100;
};

export const generateTimelineDates = (start: string, end: string) => {
  const dates = [];
  let current = new Date(start);
  const endDate = new Date(end);
  while (current <= endDate) {
    dates.push(new Date(current));
    current.setDate(current.getDate() + 1);
  }
  return dates;
};
