import React from 'react';
import { generateTimelineDates } from './dateUtils';

interface HeaderProps {
  timelineStart: string;
  timelineEnd: string;
}

const monthNames = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

const GanttHeader: React.FC<HeaderProps> = ({ timelineStart, timelineEnd }) => {
  const dates = generateTimelineDates(timelineStart, timelineEnd);

  return (
    <div className="flex border-b border-gray-300 sticky top-0 bg-white z-10">
      {dates.map((date, index) => (
        <div key={index} className="w-12 text-center border-r border-gray-200 text-xs relative">
          {date.getDate() === 1 && (
            <div className="absolute top-0 left-0 w-full text-[10px] font-semibold bg-white">
              {monthNames[date.getMonth()]} {date.getFullYear()}
            </div>
          )}
          <div className="pt-4">{date.getDate()}</div>
        </div>
      ))}
    </div>
  );
};

export default GanttHeader;
