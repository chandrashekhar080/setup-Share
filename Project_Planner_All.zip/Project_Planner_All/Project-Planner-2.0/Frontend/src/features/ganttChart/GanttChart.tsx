import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ganttModules } from './ganttData';
import TaskBar from './TaskBar';
import GanttHeader from './GanttHeader';
import TodayLine from './TodayLine';
import { getDaysDifference } from './dateUtils';

const GanttChart: React.FC = () => {
  const timelineStart = '2025-08-18';
  const timelineEnd = '2025-09-25';
  const timelineDays = getDaysDifference(timelineStart, timelineEnd);

  return (
    <Card className="overflow-x-auto max-w-full">
      <CardHeader>
        <CardTitle> Gantt Chart</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6 relative">
        <GanttHeader timelineStart={timelineStart} timelineEnd={timelineEnd} />
        {ganttModules.map((module) => (
          <div key={module.module} className="relative">
            <h3 className="font-medium mb-2">{module.module}</h3>
            <div className="relative h-8 bg-gray-100 rounded-md">
              {module.tasks.map((task) => (
                <TaskBar
                  key={task.name}
                  task={task}
                  timelineStart={timelineStart}
                  timelineDays={timelineDays}
                />
              ))}
              <TodayLine timelineStart={timelineStart} timelineEnd={timelineEnd} />
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
};

export default GanttChart;
