export interface Task {
  name: string;
  start: string; // YYYY-MM-DD
  end: string;   // YYYY-MM-DD
  color?: string; // Optional task color
}

export interface Module {
  module: string;
  tasks: Task[];
}
