import React from 'react';
import { getOffsetPercentage, getDaysDifference } from './dateUtils';

interface TodayLineProps {
  timelineStart: string;
  timelineEnd: string;
}

const TodayLine: React.FC<TodayLineProps> = ({ timelineStart, timelineEnd }) => {
  const timelineDays = getDaysDifference(timelineStart, timelineEnd);
  const today = new Date().toISOString().split('T')[0];
  const left = getOffsetPercentage(today, timelineStart, timelineDays);

  return (
    <div
      className="absolute h-full border-l-2 border-red-500"
      style={{ left: `${left}%` }}
      title="Today"
    />
  );
};

export default TodayLine;
