import { Resource } from "../types";

export const mockResources: Resource[] = [
  { id: "1", name: "Laptop", category: "Equipment", status: "Active", assignedTo: "Govind Patel", createdAt: new Date() },
  { id: "2", name: "Projector", category: "Equipment", status: "Maintenance", createdAt: new Date() },
  { id: "3", name: "Hammer", category: "Tools", status: "Active", createdAt: new Date() },
  { id: "4", name: "Invoice Doc", category: "Documents", status: "Active", createdAt: new Date() },
  { id: "5", name: "John Doe", category: "Staff", status: "Active", createdAt: new Date() },
];
