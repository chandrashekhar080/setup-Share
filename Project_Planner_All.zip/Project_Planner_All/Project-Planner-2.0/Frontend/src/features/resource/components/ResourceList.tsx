import { useState } from 'react'
import { Button } from '@/components/ui/button'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Resource } from '../types'
import ResourceDialog from './ResourceDialog'

interface ResourceListProps {
  resources: Resource[]
  onEdit: (res: Resource) => void
  onDelete: (id: string) => void
}

export default function ResourceList({
  resources,
  onEdit,
  onDelete,
}: ResourceListProps) {
  const [editingResource, setEditingResource] = useState<Resource | undefined>(
    undefined
  )
  const [editing, setEditing] = useState<Resource | null>(null)
  const [dialogOpen, setDialogOpen] = useState(false)
  function handleEdit(res: Resource) {
    setEditing(res)
    setDialogOpen(true)
  }
  return (
    <Table>
      {/* Table Header */}
      <TableHeader>
        <TableRow>
          <TableHead>Name</TableHead>
          <TableHead>Category</TableHead>
          <TableHead>Status</TableHead>
          <TableHead>Assigned To</TableHead>
          <TableHead>Actions</TableHead>
        </TableRow>
      </TableHeader>

      {/* Table Body */}
      <TableBody>
        {resources.map((res) => (
          <TableRow key={res.id}>
            <TableCell>{res.name}</TableCell>
            <TableCell>{res.category}</TableCell>
            <TableCell>{res.status}</TableCell>
            <TableCell>{res.assignedTo || '-'}</TableCell>
            <TableCell className='space-x-2'>
              {/* <Button
                size='sm'
                variant='outline'
                onClick={() => {
                  ;(setEditingResource(res), onEdit(res))
                }}
              > */}
                
                <ResourceDialog
                  triggerText='Edit'
                  resource={editingResource}
                  onSubmit={handleEdit}
                 
                />
            
              {/* </Button> */}
             
              <Button
                size='sm'
                variant='destructive'
                onClick={() => onDelete(res.id)}
              >
                Delete
              </Button>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  )
}
