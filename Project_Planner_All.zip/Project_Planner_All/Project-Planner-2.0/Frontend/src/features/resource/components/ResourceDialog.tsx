import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import ResourceForm from "./ResourceForm";
import { Resource } from "../types";

interface Props {
  triggerText: string;
  resource?: Resource;
  onSubmit: (data: Resource) => void;
}

export default function ResourceDialog({ triggerText, resource, onSubmit }: Props) {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button>{triggerText}</Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{resource ? "Edit Resource" : "Add Resource"}</DialogTitle>
        </DialogHeader>
        <ResourceForm resource={resource} onSubmit={onSubmit} />
      </DialogContent>
    </Dialog>
  );
}
