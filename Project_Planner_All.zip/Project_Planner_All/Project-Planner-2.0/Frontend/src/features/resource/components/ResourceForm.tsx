import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Resource, ResourceCategory } from "../types";

interface Props {
  resource?: Resource;
  onSubmit: (data: Resource) => void;
}

const categories: ResourceCategory[] = ["Equipment", "Tools", "Staff", "Inventory", "Documents"];

export default function ResourceForm({ resource, onSubmit }: Props) {
  const [name, setName] = useState(resource?.name || "");
  const [category, setCategory] = useState<ResourceCategory>(resource?.category || "Equipment");
  const [status, setStatus] = useState<Resource["status"]>(resource?.status || "Active");
  const [assignedTo, setAssignedTo] = useState(resource?.assignedTo || "");

  const handleSubmit = () => {
    const newResource: Resource = {
      id: resource?.id || Date.now().toString(),
      name,
      category,
      status,
      assignedTo,
      createdAt: resource?.createdAt || new Date(),
    };
    onSubmit(newResource);
  };

  return (
    <div className="space-y-4">
      <Input placeholder="Resource Name" value={name} onChange={(e) => setName(e.target.value)} />
      <Select onValueChange={(val: ResourceCategory) => setCategory(val)} defaultValue={category}>
        <SelectTrigger>
          <SelectValue placeholder="Select Category" />
        </SelectTrigger>
        <SelectContent>
          {categories.map((cat) => (
            <SelectItem key={cat} value={cat}>{cat}</SelectItem>
          ))}
        </SelectContent>
      </Select>
      <Select onValueChange={(val: Resource["status"]) => setStatus(val)} defaultValue={status}>
        <SelectTrigger>
          <SelectValue placeholder="Select Status" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="Active">Active</SelectItem>
          <SelectItem value="Inactive">Inactive</SelectItem>
          <SelectItem value="Maintenance">Maintenance</SelectItem>
        </SelectContent>
      </Select>
      <Input placeholder="Assigned To" value={assignedTo} onChange={(e) => setAssignedTo(e.target.value)} />
      <Button onClick={handleSubmit}>Save Resource</Button>
    </div>
  );
}
