import { useState } from "react";
import ResourceList from "../components/ResourceList";
import ResourceDialog from "../components/ResourceDialog";
import { Resource } from "../types";
import { mockResources } from "../data/data";

export default function ResourceClient() {
  const [resources, setResources] = useState<Resource[]>(mockResources);
  const [editingResource, setEditingResource] = useState<Resource | undefined>(undefined);
    const [editing, setEditing] = useState<Resource | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);

function handleEdit(res: Resource) {
    setEditing(res);
    setDialogOpen(true);
  }

  const handleDelete = (id: string) => {
    setResources(prev => prev.filter(r => r.id !== id));
  };

  return (
    <div className="space-y-4 shadow-sm border m-8 rounded-xl p-2">
      <ResourceDialog triggerText="Add Resource" onSubmit={handleEdit}  
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        editing={editing}
        />
      <ResourceList resources={resources} onEdit={(res) => setEditingResource(res)} onDelete={handleDelete} />
      {/* {editingResource && (
        <ResourceDialog triggerText="Edit" resource={editingResource} onSubmit={handleEdit} />
      )} */}
    </div>
  );
}
