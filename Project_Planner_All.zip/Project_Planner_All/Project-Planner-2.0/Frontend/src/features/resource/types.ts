export type ResourceCategory = "Equipment" | "Tools" | "Staff" | "Inventory" | "Documents";

export type Resource = {
  id: string;
  name: string;
  category: ResourceCategory;
  status: "Active" | "Inactive" | "Maintenance";
  assignedTo?: string;
  createdAt: Date;
};
