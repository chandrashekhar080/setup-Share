/**
 * Custom hooks for project management
 * Provides state management and API integration for projects
 */

import { useState, useEffect, useCallback, useRef } from 'react'
import { toast } from 'sonner'
import {
  Project,
  CreateProject,
  UpdateProject,
  ProjectFilter,
  ProjectStats,
} from '../data/schema'
import {
  getProjects,
  getProjectForEdit,
  createProject,
  updateProject,
  deleteProject,
  getProjectStats,
  searchProjects,
  bulkDeleteProjects,
} from '../api/projects-api'

// Hook for managing projects list
export const useProjects = (initialFilter?: ProjectFilter) => {
  const [projects, setProjects] = useState<Project[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [filter, setFilter] = useState<ProjectFilter>(initialFilter || {})
  
  // Use refs to prevent stale closures and unnecessary re-renders
  const filterRef = useRef<ProjectFilter>(initialFilter || {})
  const abortControllerRef = useRef<AbortController | null>(null)

  // Update filter ref when filter state changes
  useEffect(() => {
    filterRef.current = filter
  }, [filter])

  // Fetch projects - stable function that doesn't depend on filter state
  const fetchProjects = useCallback(async (currentFilter?: ProjectFilter) => {
    // Cancel any ongoing request
    if (abortControllerRef.current) {
      abortControllerRef.current.abort()
    }

    // Create new abort controller for this request
    abortControllerRef.current = new AbortController()

    try {
      setLoading(true)
      setError(null)
      const filterToUse = currentFilter !== undefined ? currentFilter : filterRef.current
      const data = await getProjects(filterToUse, abortControllerRef.current.signal)
      
      // Only update state if request wasn't aborted
      if (!abortControllerRef.current.signal.aborted) {
        setProjects(data)
      }
    } catch (err) {
      // Don't show error if request was aborted
      if (err instanceof Error && err.name === 'AbortError') {
        return
      }
      
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch projects'
      setError(errorMessage)
      toast.error(errorMessage)
    } finally {
      // Only update loading state if request wasn't aborted
      if (!abortControllerRef.current?.signal.aborted) {
        setLoading(false)
      }
    }
  }, [])

  // Update filter and refetch with optimized comparison
  const updateFilter = useCallback((newFilter: ProjectFilter) => {
    // Only update if filter actually changed (deep comparison)
    const currentFilter = filterRef.current
    const hasChanged = Object.keys({...currentFilter, ...newFilter}).some(
      key => currentFilter[key as keyof ProjectFilter] !== newFilter[key as keyof ProjectFilter]
    )
    
    if (hasChanged) {
      setFilter(newFilter)
      filterRef.current = newFilter // Update ref immediately to prevent race conditions
      fetchProjects(newFilter)
    }
  }, [fetchProjects])

  // Refresh projects with current filter
  const refresh = useCallback(() => {
    fetchProjects(filterRef.current)
  }, [fetchProjects])

  // Cleanup abort controller on unmount
  useEffect(() => {
    return () => {
      if (abortControllerRef.current) {
        abortControllerRef.current.abort()
      }
    }
  }, [])

  // Initial load only
  useEffect(() => {
    fetchProjects(filterRef.current)
  }, [fetchProjects])

  return {
    projects,
    loading,
    error,
    filter,
    updateFilter,
    refresh,
    setProjects,
  }
}

// Hook for managing single project operations
export const useProject = () => {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Create project
  const create = useCallback(async (projectData: CreateProject): Promise<boolean> => {
    try {
      setLoading(true)
      setError(null)
      await createProject(projectData)
      toast.success('Project created successfully')
      return true
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to create project'
      setError(errorMessage)
      toast.error(errorMessage)
      return false
    } finally {
      setLoading(false)
    }
  }, [])

  // Update project
  const update = useCallback(async (uid: string, projectData: UpdateProject): Promise<boolean> => {
    try {
      setLoading(true)
      setError(null)
      await updateProject(uid, projectData)
      toast.success('Project updated successfully')
      return true
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to update project'
      setError(errorMessage)
      toast.error(errorMessage)
      return false
    } finally {
      setLoading(false)
    }
  }, [])

  // Delete project
  const remove = useCallback(async (uid: string): Promise<boolean> => {
    try {
      setLoading(true)
      setError(null)
      await deleteProject(uid)
      toast.success('Project deleted successfully')
      return true
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to delete project'
      setError(errorMessage)
      toast.error(errorMessage)
      return false
    } finally {
      setLoading(false)
    }
  }, [])

  // Get project for editing
  const getForEdit = useCallback(async (uid: string): Promise<Project | null> => {
    try {
      setLoading(true)
      setError(null)
      const project = await getProjectForEdit(uid)
      return project
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch project'
      setError(errorMessage)
      toast.error(errorMessage)
      return null
    } finally {
      setLoading(false)
    }
  }, [])

  // Bulk delete projects
  const bulkRemove = useCallback(async (uids: string[]): Promise<boolean> => {
    try {
      setLoading(true)
      setError(null)
      await bulkDeleteProjects(uids)
      toast.success(`${uids.length} project(s) deleted successfully`)
      return true
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to delete projects'
      setError(errorMessage)
      toast.error(errorMessage)
      return false
    } finally {
      setLoading(false)
    }
  }, [])

  return {
    loading,
    error,
    create,
    update,
    remove,
    getForEdit,
    bulkRemove,
  }
}

// Hook for project statistics
export const useProjectStats = () => {
  const [stats, setStats] = useState<ProjectStats | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchStats = useCallback(async () => {
    try {
      setLoading(true)
      setError(null)
      const data = await getProjectStats()
      setStats(data)
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch project statistics'
      setError(errorMessage)
      toast.error(errorMessage)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchStats()
  }, [fetchStats])

  return {
    stats,
    loading,
    error,
    refresh: fetchStats,
  }
}

// Hook for project search
export const useProjectSearch = () => {
  const [results, setResults] = useState<Project[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const search = useCallback(async (
    query: string,
    filter?: Omit<ProjectFilter, 'q'>
  ): Promise<void> => {
    if (!query || query.trim().length < 2) {
      setResults([])
      return
    }

    try {
      setLoading(true)
      setError(null)
      const data = await searchProjects(query, filter)
      setResults(data)
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Search failed'
      setError(errorMessage)
      toast.error(errorMessage)
      setResults([])
    } finally {
      setLoading(false)
    }
  }, [])

  const clearResults = useCallback(() => {
    setResults([])
    setError(null)
  }, [])

  return {
    results,
    loading,
    error,
    search,
    clearResults,
  }
}

// Hook for optimistic updates
export const useOptimisticProjects = (initialProjects: Project[] = []) => {
  const [projects, setProjects] = useState<Project[]>(initialProjects)

  // Add project optimistically
  const addProject = useCallback((project: Project) => {
    setProjects(prev => [project, ...prev])
  }, [])

  // Update project optimistically
  const updateProjectOptimistic = useCallback((uid: string, updates: Partial<Project>) => {
    setProjects(prev =>
      prev.map(project =>
        project.uid === uid ? { ...project, ...updates } : project
      )
    )
  }, [])

  // Remove project optimistically
  const removeProject = useCallback((uid: string) => {
    setProjects(prev => prev.filter(project => project.uid !== uid))
  }, [])

  // Remove multiple projects optimistically
  const removeProjects = useCallback((uids: string[]) => {
    setProjects(prev => prev.filter(project => !uids.includes(project.uid)))
  }, [])

  // Revert optimistic update
  const revertProjects = useCallback((originalProjects: Project[]) => {
    setProjects(originalProjects)
  }, [])

  return {
    projects,
    setProjects,
    addProject,
    updateProject: updateProjectOptimistic,
    removeProject,
    removeProjects,
    revertProjects,
  }
}

// Hook for project form management
export const useProjectForm = () => {
  const [isOpen, setIsOpen] = useState(false)
  const [mode, setMode] = useState<'create' | 'edit'>('create')
  const [selectedProject, setSelectedProject] = useState<Project | null>(null)

  const openCreateForm = useCallback(() => {
    setMode('create')
    setSelectedProject(null)
    setIsOpen(true)
  }, [])

  const openEditForm = useCallback((project: Project) => {
    setMode('edit')
    setSelectedProject(project)
    setIsOpen(true)
  }, [])

  const closeForm = useCallback(() => {
    setIsOpen(false)
    setSelectedProject(null)
  }, [])

  return {
    isOpen,
    mode,
    selectedProject,
    openCreateForm,
    openEditForm,
    closeForm,
  }
}