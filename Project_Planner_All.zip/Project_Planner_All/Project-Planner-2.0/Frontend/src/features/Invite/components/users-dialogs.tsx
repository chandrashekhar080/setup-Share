import { useUsers } from '../context/users-context'
import { ProjectFormDialog } from './project-form-dialog'
import { UsersDeleteDialog } from './users-delete-dialog'

export function UsersDialogs() {
  const { open, setOpen, currentRow, setCurrentRow } = useUsers()
  return (
    <>
      <ProjectFormDialog
        key='project-add'
        open={open === 'add'}
        onOpenChange={() => setOpen('add')}
        mode="create"
      />

      {currentRow && (
        <>
          <ProjectFormDialog
            key={`project-edit-${currentRow.uid}`}
            open={open === 'edit'}
            onOpenChange={() => {
              setOpen('edit')
              setTimeout(() => {
                setCurrentRow(null)
              }, 500)
            }}
            mode="edit"
            project={currentRow}
          />

          <UsersDeleteDialog
            key={`project-delete-${currentRow.uid}`}
            open={open === 'delete'}
            onOpenChange={() => {
              setOpen('delete')
              setTimeout(() => {
                setCurrentRow(null)
              }, 500)
            }}
            currentRow={currentRow}
          />
        </>
      )}
    </>
  )
}
