/**
 * Project Form Dialog Component
 * Modal wrapper for the project form
 */

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { ScrollArea } from '@/components/ui/scroll-area'
import { ProjectForm } from './project-form'
import { Project } from '../data/schema'

interface ProjectFormDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  mode: 'create' | 'edit'
  project?: Project | null
}

export function ProjectFormDialog({
  open,
  onOpenChange,
  mode,
  project,
}: ProjectFormDialogProps) {
  const handleSuccess = () => {
    onOpenChange(false)
    // Socket.IO will handle real-time updates automatically
  }

  const handleCancel = () => {
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle>
            {mode === 'create' ? 'Create New Project' : 'Edit Project'}
          </DialogTitle>
          <DialogDescription>
            {mode === 'create'
              ? 'Fill in the details below to create a new project.'
              : 'Update the project information below.'}
          </DialogDescription>
        </DialogHeader>
        
        <ScrollArea className="max-h-[70vh] pr-4">
          <ProjectForm
            project={project}
            mode={mode}
            onSuccess={handleSuccess}
            onCancel={handleCancel}
          />
        </ScrollArea>
      </DialogContent>
    </Dialog>
  )
}