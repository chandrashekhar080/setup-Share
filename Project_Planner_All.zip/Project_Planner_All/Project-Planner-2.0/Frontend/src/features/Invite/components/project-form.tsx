/**
 * Project Form Component
 * Handles creating and editing projects with proper validation
 */

import { useState, useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { CalendarIcon, Loader2 } from 'lucide-react'
// import { format } from 'date-fns'

import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
// import { Label } from '@/components/ui/label'
// import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Form,
  FormControl,
  // FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form'
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover'
import { Calendar } from '@/components/ui/calendar'
import { cn } from '@/lib/utils'

import {
  CreateProject,
  UpdateProject,
  Project,
  createProjectSchema,
  updateProjectSchema,
} from '../data/schema'
import { useProject } from '../hooks/use-projects'

interface ProjectFormProps {
  project?: Project | null
  mode: 'create' | 'edit'
  onSuccess?: () => void
  onCancel?: () => void
}

export function ProjectForm({ project, mode, onSuccess, onCancel }: ProjectFormProps) {
  const { create, update, loading } = useProject()
  const [isSubmitting, setIsSubmitting] = useState(false)

  const schema = mode === 'create' ? createProjectSchema : updateProjectSchema
  const form = useForm<CreateProject | UpdateProject>({
    resolver: zodResolver(schema) as any,
    defaultValues: {
      projectName: '',
      customer: '',
      supervisor: '',
      startDate: new Date(),
      endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
      projectDetails: '',
      projectManager: '',
      totalBudget: 0,
      allocatedFunds: 0,
      budgetNotes: '',
      progress: 0,
      milestone: '',
      followedByName: '',
      priority: 'medium',
      statusNotes: '',
      status: 'planning',
      team: [],
      tags: [],
    },
  })

  // Populate form when editing
  useEffect(() => {
    if (mode === 'edit' && project) {
      form.reset({
        projectName: project.projectName,
        customer: project.customer,
        supervisor: project.supervisor || '',
        startDate: new Date(project.startDate),
        endDate: new Date(project.endDate),
        projectDetails: project.projectDetails || '',
        projectManager: project.projectManager,
        totalBudget: project.totalBudget,
        allocatedFunds: project.allocatedFunds || 0,
        budgetNotes: project.budgetNotes || '',
        progress: project.progress || 0,
        milestone: project.milestone || '',
        followedByName: project.followedByName || '',
        priority: project.priority,
        statusNotes: project.statusNotes || '',
        status: project.status,
        team: project.team || [],
        tags: project.tags || [],
      })
    }
  }, [mode, project, form])

  const onSubmit = async (data: CreateProject | UpdateProject) => {
    setIsSubmitting(true)
    try {
      let success = false

      if (mode === 'create') {
        // Validate and prepare data for creation
        const validatedData = createProjectSchema.parse(data)
        console.log('Submitting project data:', validatedData)
        success = await create(validatedData)
      } else if (mode === 'edit' && project) {
        // Validate and prepare data for update
        const validatedData = updateProjectSchema.parse(data)
        success = await update(project.uid, validatedData)
      }

      if (success) {
        form.reset()
        onSuccess?.()
      }
    } catch (error) {
      console.error('Form submission error:', error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const isLoading = loading || isSubmitting

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        {/* Basic Information */}
        <div className="space-y-4">
          <h3 className="text-lg font-medium">Basic Information</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="projectName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Member Name *</FormLabel>
                  <FormControl>
                    <Input placeholder="Entermember name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="customer"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email *</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter Email" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="projectManager"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Role *</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter your role" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="supervisor"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Invite</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter Invite" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

        
        </div>

        {/* Timeline */}
        <div className="space-y-4">
         
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="startDate"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>Joined Date *</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full pl-3 text-left font-normal",
                            !field.value && "text-muted-foreground"
                          )}
                        >
                          {field.value ? (
                            field.value.toLocaleDateString()
                          ) : (
                            <span>Pick a date</span>
                          )}
                          <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={field.value}
                        onSelect={field.onChange}
                        disabled={(date) =>
                          date < new Date("1900-01-01")
                        }
                      />
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />

         <FormField
              control={form.control}
              name="status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Status</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="planning">Planning</SelectItem>
                      <SelectItem value="in_progress">In Progress</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="on_hold">On Hold</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
               <FormField
              control={form.control}
              name="status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Action</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="planning">Active</SelectItem>
                      <SelectItem value="in_progress">Un active</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        </div>

  
    

        {/* Form Actions */}
        <div className="flex items-center justify-end space-x-2 pt-4 border-t">
          <Button
            type="button"
            variant="outline"
            onClick={onCancel}
            disabled={isLoading}
          >
            Cancel
          </Button>
          <Button type="submit" disabled={isLoading}>
            {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {mode === 'create' ? 'Create Member' : 'Update Member'}
          </Button>
        </div>
      </form>
    </Form>
  )
}