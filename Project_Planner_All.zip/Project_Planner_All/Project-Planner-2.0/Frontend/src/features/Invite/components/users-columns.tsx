import { ColumnDef } from '@tanstack/react-table'
import { cn } from '@/lib/utils'
import { Checkbox } from '@/components/ui/checkbox'
import LongText from '@/components/long-text'
import { Project } from '../data/schema'
import { DataTableColumnHeader } from './data-table-column-header'
import { DataTableRowActions } from './data-table-row-actions'
import { formatCurrency } from '../api/projects-api'

export const columns: ColumnDef<Project>[] = [
  {
    id: 'select',
    header: ({ table }) => (
      <Checkbox
        checked={
          table.getIsAllPageRowsSelected() ||
          (table.getIsSomePageRowsSelected() && 'indeterminate')
        }
        onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
        aria-label='Select all'
        className='translate-y-[2px]'
      />
    ),
    meta: {
      className: cn(
        'sticky md:table-cell left-0 z-10 rounded-tl',
        'bg-background group-hover/row:bg-muted group-data-[state=selected]/row:bg-muted'
      ),
    },
    cell: ({ row }) => (
      <Checkbox
        checked={row.getIsSelected()}
        onCheckedChange={(value) => row.toggleSelected(!!value)}
        aria-label='Select row'
        className='translate-y-[2px]'
      />
    ),
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: 'uid',
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title='ID' />
    ),
    cell: ({ row }) => (
      <LongText className='max-w-24 font-mono text-xs'>{row.getValue('uid')}</LongText>
    ),
    meta: {
      className: cn(
        'drop-shadow-[0_1px_2px_rgb(0_0_0_/_0.1)] dark:drop-shadow-[0_1px_2px_rgb(255_255_255_/_0.1)] lg:drop-shadow-none',
        'bg-background group-hover/row:bg-muted group-data-[state=selected]/row:bg-muted',
        'sticky left-6 md:table-cell'
      ),
    },
    enableHiding: false,
  },
  {
    accessorKey: 'projectName',
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title='Member Name' />
    ),
    cell: ({ row }) => {
      const memberName = row.getValue('memberName') as string
      return <LongText className='max-w-48 font-medium'>{memberName}</LongText>
    },
    meta: { className: 'w-48' },
  },
  {
    accessorKey: 'Email',
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title='Email' />
    ),
    cell: ({ row }) => (
      <div className='w-fit text-nowrap max-w-32'>
        <LongText>{row.getValue('email')}</LongText>
      </div>
    ),
  },
  {
    accessorKey: 'Role ',
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title='Role ' />
    ),
    cell: ({ row }) => (
      <div className='w-fit text-nowrap max-w-32'>
        <LongText>{row.getValue('role')}</LongText>
      </div>
    ),
  },
   {
    accessorKey: 'Invite',
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title='Invite' />
    ),
    cell: ({ row }) => (
      <div className='w-fit text-nowrap max-w-32'>
        <LongText>{row.getValue('invite')}</LongText>
      </div>
    ),
  },
   {
    accessorKey: 'Status ',
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title='Status ' />
    ),
    cell: ({ row }) => (
      <div className='w-fit text-nowrap max-w-32'>
        <LongText>{row.getValue('status')}</LongText>
      </div>
    ),
  },
   {
    accessorKey: 'Joined Date ',
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title='Joined Date ' />
    ),
    cell: ({ row }) => (
      <div className='w-fit text-nowrap max-w-32'>
        <LongText>{row.getValue('joineddate')}</LongText>
      </div>
    ),
  },
  {
    accessorKey: 'Action',
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title='Action' />
    ),
    cell: ({ row }) => {
      const budget = row.getValue('action') as number
      return (
        <div className='w-fit text-nowrap font-medium'>
          {formatCurrency(budget)}
        </div>
      )
    },
  },
  {
    id: 'actions',
    cell: DataTableRowActions,
  },
]

// Legacy compatibility - keeping User type columns for existing components
export const userColumns = columns as ColumnDef<any>[]



