import { z } from 'zod'

// Project Status Schema - matching server model
const projectStatusSchema = z.union([
  z.literal('planning'),
  z.literal('in_progress'),
  z.literal('completed'),
  z.literal('on_hold'),
  z.literal('cancelled'),
])
export type ProjectStatus = z.infer<typeof projectStatusSchema>

// Project Priority Schema - matching server model
const projectPrioritySchema = z.union([
  z.literal('low'),
  z.literal('medium'),
  z.literal('high'),
  z.literal('urgent'),
])
export type ProjectPriority = z.infer<typeof projectPrioritySchema>

// Team Member Schema
const teamMemberSchema = z.object({
  name: z.string(),
  role: z.string(),
  email: z.string().optional(),
})
export type TeamMember = z.infer<typeof teamMemberSchema>

// Attachment Schema
const attachmentSchema = z.object({
  filename: z.string(),
  originalName: z.string(),
  mimeType: z.string(),
  size: z.number(),
  uploadDate: z.coerce.date(),
})
export type Attachment = z.infer<typeof attachmentSchema>

// Main Project Schema - flexible to handle MySQL data types
const projectSchema = z.object({
  _id: z.string().optional(),
  uid: z.string(),
  projectName: z.string().min(1),
  customer: z.string().min(1),
  supervisor: z.string().nullable().optional().transform(val => val || ''),
  startDate: z.coerce.date(),
  endDate: z.coerce.date(),
  duration: z.union([z.number(), z.string()]).nullable().optional().transform(val => 
    val ? (typeof val === 'string' ? parseInt(val) || 0 : val) : 0
  ),
  projectDetails: z.string().nullable().optional().transform(val => val || ''),
  projectManager: z.string().min(1),
  totalBudget: z.union([z.number(), z.string()]).transform(val => 
    typeof val === 'string' ? parseFloat(val) || 0 : val
  ),
  allocatedFunds: z.union([z.number(), z.string()]).transform(val => 
    typeof val === 'string' ? parseFloat(val) || 0 : val
  ),
  budgetNotes: z.string().nullable().optional().transform(val => val || ''),
  progress: z.union([z.number(), z.string()]).optional().transform(val => 
    val ? (typeof val === 'string' ? parseInt(val) || 0 : val) : 0
  ),
  milestone: z.string().nullable().optional().transform(val => val || ''),
  followedByName: z.string().nullable().optional().transform(val => val || ''),
  priority: projectPrioritySchema,
  statusNotes: z.string().nullable().optional().transform(val => val || ''),
  status: projectStatusSchema,
  team: z.array(teamMemberSchema).optional().default([]),
  tags: z.array(z.string()).optional().default([]),
  attachments: z.array(attachmentSchema).optional().default([]),
  lastUpdatedBy: z.string().nullable().optional().transform(val => val || ''),
  createdAt: z.coerce.date().optional(),
  updatedAt: z.coerce.date().optional(),
  // Virtual fields from server
  remainingBudget: z.union([z.number(), z.string()]).optional().transform(val => 
    val ? (typeof val === 'string' ? parseFloat(val) || 0 : val) : 0
  ),
  budgetUtilization: z.union([z.number(), z.string()]).optional().transform(val => 
    val ? (typeof val === 'string' ? parseFloat(val) || 0 : val) : 0
  ),
  durationDays: z.union([z.number(), z.string()]).optional().transform(val => 
    val ? (typeof val === 'string' ? parseInt(val) || 0 : val) : 0
  ),
  daysRemaining: z.union([z.number(), z.string()]).optional().transform(val => 
    val ? (typeof val === 'string' ? parseInt(val) || 0 : val) : 0
  ),
  isOverdue: z.union([z.boolean(), z.number()]).optional().transform(val => 
    typeof val === 'number' ? Boolean(val) : Boolean(val)
  ),
})
export { projectSchema }
export type Project = z.infer<typeof projectSchema>

// Project List Schema
export const projectListSchema = z.array(projectSchema)

// Project Creation Schema (for forms)
export const createProjectSchema = z.object({
  projectName: z.string().min(1, 'Project name is required'),
  customer: z.string().min(1, 'Customer is required'),
  projectManager: z.string().min(1, 'Project manager is required'),
  supervisor: z.string().optional().default(''),
  startDate: z.coerce.date(),
  endDate: z.coerce.date(),
  projectDetails: z.string().optional().default(''),
  totalBudget: z.number().min(0, 'Budget must be positive').default(0),
  allocatedFunds: z.number().min(0, 'Allocated funds must be positive').default(0),
  budgetNotes: z.string().optional().default(''),
  progress: z.number().min(0).max(100).default(0),
  milestone: z.string().optional().default(''),
  followedByName: z.string().optional().default(''),
  priority: projectPrioritySchema.default('medium'),
  statusNotes: z.string().optional().default(''),
  status: projectStatusSchema.default('planning'),
  team: z.array(teamMemberSchema).optional().default([]),
  tags: z.array(z.string()).optional().default([]),
  uid: z.string().optional(), // Allow uid to be provided but not required
}).refine((data) => {
  // Validate that end date is after start date
  return data.endDate >= data.startDate;
}, {
  message: "End date must be after start date",
  path: ["endDate"],
})
export type CreateProject = z.infer<typeof createProjectSchema>

// Project Update Schema (for forms)
export const updateProjectSchema = createProjectSchema.partial()
export type UpdateProject = z.infer<typeof updateProjectSchema>

// Project Filter Schema
export const projectFilterSchema = z.object({
  status: projectStatusSchema.optional(),
  priority: projectPrioritySchema.optional(),
  customer: z.string().optional(),
  projectManager: z.string().optional(),
  q: z.string().optional(), // search query
})
export type ProjectFilter = z.infer<typeof projectFilterSchema>

// Project Statistics Schema
export const projectStatsSchema = z.object({
  total: z.number(),
  planning: z.number(),
  in_progress: z.number(),
  completed: z.number(),
  on_hold: z.number(),
  totalBudget: z.number(),
  allocatedFunds: z.number(),
})
export type ProjectStats = z.infer<typeof projectStatsSchema>

// Legacy compatibility - keeping User type for existing components
export type User = Project
export const userListSchema = projectListSchema


export type PermissionType = 'create' | 'view' | 'edit' | 'delete' | 'download' | 'all'

export interface Role {
  id: string
  roleName: string
  roleDescription: string
  roleStatus: string
  permissions: {
    [moduleName: string]: {
      [key in PermissionType]: boolean
    }
  }
}
