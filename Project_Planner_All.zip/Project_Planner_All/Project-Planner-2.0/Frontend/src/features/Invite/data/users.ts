import { faker } from '@faker-js/faker'

export const users = Array.from({ length: 20 }, () => {
  const projectTypes = ['Website', 'Mobile App', 'E-commerce', 'Dashboard', 'API', 'Platform', 'System']
  const projectAdjectives = ['Modern', 'Smart', 'Advanced', 'Digital', 'Cloud', 'Enterprise', 'Custom']
  const milestones = ['Planning', 'Design', 'Development', 'Testing', 'Deployment', 'Maintenance']
  const supervisors = ['John Smith', 'Sarah Johnson', 'Mike Davis', 'Emily Brown', 'David Wilson', 'Lisa Garcia']
  
  const projectType = faker.helpers.arrayElement(projectTypes)
  const projectAdjective = faker.helpers.arrayElement(projectAdjectives)
  const companyName = faker.company.name().split(' ')[0]
  
  const projectName = `${projectAdjective} ${projectType}`
  // const clientName = faker.person.fullName()
  const projectNotes = faker.lorem.sentence({ min: 5, max: 15 })
  
  return {
    id: faker.string.uuid(),
    firstName: projectName,
    lastName: `for ${companyName}`,
    username: `PRJ-${faker.string.alphanumeric({ length: 6, casing: 'upper' })}`,
    email: companyName, // Customer company name
    phoneNumber: faker.phone.number({ style: 'international' }),
    notes: projectNotes,
    milestone: faker.helpers.arrayElement(milestones),
    supervisor: faker.helpers.arrayElement(supervisors),
    status: faker.helpers.arrayElement([
      'active',      // In Progress
      'inactive',    // Completed
      'invited',     // Planning
      'suspended',   // On Hold
    ]),
    role: faker.helpers.arrayElement([
      'superadmin',  // Critical
      'admin',       // High
      'manager',     // Medium
      'cashier',     // Low
    ]),
    createdAt: faker.date.past(),
    updatedAt: faker.date.recent(),
  }
})
