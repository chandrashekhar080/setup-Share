import {
  IconAlertTriangle,
  IconCircleCheck,
  IconClock,
  IconFlame,
  IconPlayerPlay,
  IconPlayerPause,
  IconX,
  IconClipboardList,
} from '@tabler/icons-react'
import { ProjectStatus, ProjectPriority } from './schema'

// Project Status Colors and Labels
export const statusColors = new Map<ProjectStatus, string>([
  ['planning', 'bg-sky-200/40 text-sky-900 dark:text-sky-100 border-sky-300'],
  ['in_progress', 'bg-teal-100/30 text-teal-900 dark:text-teal-200 border-teal-200'],
  ['completed', 'bg-green-100/30 text-green-900 dark:text-green-200 border-green-200'],
  ['on_hold', 'bg-yellow-100/30 text-yellow-900 dark:text-yellow-200 border-yellow-200'],
  ['cancelled', 'bg-destructive/10 dark:bg-destructive/50 text-destructive dark:text-primary border-destructive/10'],
])

export const statusLabels = new Map<ProjectStatus, string>([
  ['planning', 'Planning'],
  ['in_progress', 'In Progress'],
  ['completed', 'Completed'],
  ['on_hold', 'On Hold'],
  ['cancelled', 'Cancelled'],
])

export const statusIcons = new Map<ProjectStatus, any>([
  ['planning', IconClipboardList],
  ['in_progress', IconPlayerPlay],
  ['completed', IconCircleCheck],
  ['on_hold', IconPlayerPause],
  ['cancelled', IconX],
])

// Project Priority Colors and Labels
export const priorityColors = new Map<ProjectPriority, string>([
  ['low', 'bg-neutral-100/40 text-neutral-700 dark:text-neutral-300 border-neutral-200'],
  ['medium', 'bg-blue-100/30 text-blue-900 dark:text-blue-200 border-blue-200'],
  ['high', 'bg-orange-100/30 text-orange-900 dark:text-orange-200 border-orange-200'],
  ['urgent', 'bg-red-100/30 text-red-900 dark:text-red-200 border-red-200'],
])

export const priorityLabels = new Map<ProjectPriority, string>([
  ['low', 'Low'],
  ['medium', 'Medium'],
  ['high', 'High'],
  ['urgent', 'Urgent'],
])

export const priorityIcons = new Map<ProjectPriority, any>([
  ['low', IconCircleCheck],
  ['medium', IconClock],
  ['high', IconAlertTriangle],
  ['urgent', IconFlame],
])

// Priority Types for Filters
export const priorityTypes = [
  {
    label: 'Low',
    value: 'low',
    icon: IconCircleCheck,
  },
  {
    label: 'Medium',
    value: 'medium',
    icon: IconClock,
  },
  {
    label: 'High',
    value: 'high',
    icon: IconAlertTriangle,
  },
  {
    label: 'Urgent',
    value: 'urgent',
    icon: IconFlame,
  },
] as const

// Status Types for Filters
export const statusTypes = [
  {
    label: 'Planning',
    value: 'planning',
    icon: IconClipboardList,
  },
  {
    label: 'In Progress',
    value: 'in_progress',
    icon: IconPlayerPlay,
  },
  {
    label: 'Completed',
    value: 'completed',
    icon: IconCircleCheck,
  },
  {
    label: 'On Hold',
    value: 'on_hold',
    icon: IconPlayerPause,
  },
  {
    label: 'Cancelled',
    value: 'cancelled',
    icon: IconX,
  },
] as const

// Legacy compatibility
export const callTypes = statusColors
export const userTypes = priorityTypes
