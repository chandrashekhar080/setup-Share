/**
 * Projects API Service
 * Handles all project-related API operations with proper error handling
 */

import { api, buildQueryString, API_CONFIG } from '@/lib/api'
import {
  Project,
  CreateProject,
  UpdateProject,
  ProjectFilter,
  ProjectStats,
  projectListSchema,
  projectStatsSchema,
} from '../data/schema'

const ENDPOINTS = {
  PROJECTS: API_CONFIG.ENDPOINTS.PROJECTS,
  PROJECT_STATS: `${API_CONFIG.ENDPOINTS.PROJECTS}/stats`,
  PROJECT_SEARCH: `${API_CONFIG.ENDPOINTS.PROJECTS}/search`,
} as const

/**
 * Get all projects with optional filtering
 */
export const getProjects = async (filter?: ProjectFilter, signal?: AbortSignal): Promise<Project[]> => {
  const queryString = filter ? buildQueryString(filter) : ''
  const endpoint = `${ENDPOINTS.PROJECTS}${queryString}`
  
  const data = await api.get<Project[]>(endpoint, { signal })
  
  // Validate response data
  return projectListSchema.parse(data)
}

/**
 * Get project by UID for editing
 */
export const getProjectForEdit = async (uid: string): Promise<Project> => {
  if (!uid) {
    throw new Error('Project UID is required')
  }

  const data = await api.post<Project>(`${ENDPOINTS.PROJECTS}editproject`, { uid })
  
  // Validate response data
  return data
}

/**
 * Create a new project
 */
export const createProject = async (projectData: CreateProject): Promise<void> => {
  // Validate input data
  if (!projectData.projectName || !projectData.customer) {
    throw new Error('Project name and customer are required')
  }

  await api.post(ENDPOINTS.PROJECTS, projectData)
}

/**
 * Update an existing project
 */
export const updateProject = async (uid: string, projectData: UpdateProject): Promise<void> => {
  if (!uid) {
    throw new Error('Project UID is required')
  }

  // Use legacy POST endpoint with edit flag (working method)
  const updateData = {
    ...projectData,
    edit: uid,
  }

  await api.post(ENDPOINTS.PROJECTS, updateData)
}

/**
 * Delete a project
 */
export const deleteProject = async (uid: string): Promise<void> => {
  if (!uid) {
    throw new Error('Project UID is required')
  }

  // Use legacy POST endpoint (working method)
  await api.post(`${ENDPOINTS.PROJECTS}deleteproject`, { uid })
}

/**
 * Get project statistics
 */
export const getProjectStats = async (): Promise<ProjectStats> => {
  const data = await api.get<ProjectStats>(ENDPOINTS.PROJECT_STATS)
  
  // Validate response data
  return projectStatsSchema.parse(data)
}

/**
 * Search projects
 */
export const searchProjects = async (
  query: string,
  filter?: Omit<ProjectFilter, 'q'>
): Promise<Project[]> => {
  if (!query || query.trim().length < 2) {
    throw new Error('Search query must be at least 2 characters long')
  }

  const searchParams = {
    q: query.trim(),
    ...filter,
  }

  const queryString = buildQueryString(searchParams)
  const endpoint = `${ENDPOINTS.PROJECT_SEARCH}${queryString}`
  
  const data = await api.get<Project[]>(endpoint)
  
  // Validate response data
  return projectListSchema.parse(data)
}

/**
 * Bulk operations
 */
export const bulkDeleteProjects = async (uids: string[]): Promise<void> => {
  if (!uids || uids.length === 0) {
    throw new Error('At least one project UID is required')
  }

  // Delete projects one by one (server doesn't support bulk delete)
  const deletePromises = uids.map(uid => deleteProject(uid))
  await Promise.all(deletePromises)
}

/**
 * Export projects data
 */
export const exportProjects = async (filter?: ProjectFilter): Promise<Blob> => {
  const queryString = filter ? buildQueryString({ ...filter, export: 'csv' }) : '?export=csv'
  const endpoint = `${ENDPOINTS.PROJECTS}${queryString}`
  
  const response = await fetch(`${API_CONFIG.BASE_URL}${endpoint}`, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${localStorage.getItem('authToken')}`,
    },
  })

  if (!response.ok) {
    throw new Error('Failed to export projects')
  }

  return response.blob()
}

/**
 * Utility functions
 */

/**
 * Generate a unique project UID (7-digit number)
 */
export const generateProjectUID = (): string => {
  return Math.floor(1000000 + Math.random() * 9000000).toString()
}

/**
 * Calculate project progress based on status
 */
export const calculateProgress = (status: string, currentProgress?: number): number => {
  switch (status) {
    case 'planning':
      return currentProgress || 0
    case 'in_progress':
      return currentProgress || 25
    case 'completed':
      return 100
    case 'cancelled':
    case 'on_hold':
      return currentProgress || 0
    default:
      return currentProgress || 0
  }
}

/**
 * Format currency for budget display
 */
export const formatCurrency = (amount: number, currency = 'USD'): string => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount)
}

/**
 * Calculate days between dates
 */
export const calculateDaysBetween = (startDate: Date, endDate: Date): number => {
  const timeDiff = endDate.getTime() - startDate.getTime()
  return Math.ceil(timeDiff / (1000 * 60 * 60 * 24))
}

/**
 * Check if project is overdue
 */
export const isProjectOverdue = (endDate: Date, status: string): boolean => {
  if (status === 'completed' || status === 'cancelled') {
    return false
  }
  return new Date() > endDate
}

/**
 * Get project status color class
 */
export const getStatusColorClass = (status: string): string => {
  const statusColorMap: Record<string, string> = {
    planning: 'bg-blue-100 text-blue-800',
    in_progress: 'bg-green-100 text-green-800',
    completed: 'bg-gray-100 text-gray-800',
    on_hold: 'bg-yellow-100 text-yellow-800',
    cancelled: 'bg-red-100 text-red-800',
  }
  return statusColorMap[status] || 'bg-gray-100 text-gray-800'
}

/**
 * Get priority color class
 */
export const getPriorityColorClass = (priority: string): string => {
  const priorityColorMap: Record<string, string> = {
    low: 'bg-gray-100 text-gray-800',
    medium: 'bg-blue-100 text-blue-800',
    high: 'bg-orange-100 text-orange-800',
    urgent: 'bg-red-100 text-red-800',
  }
  return priorityColorMap[priority] || 'bg-gray-100 text-gray-800'
}