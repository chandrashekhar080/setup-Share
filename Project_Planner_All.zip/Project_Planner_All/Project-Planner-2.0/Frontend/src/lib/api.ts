/**
 * API Configuration and Utilities
 * Centralized API management with proper error handling
 */

// API Configuration
export const API_CONFIG = {
  BASE_URL: 'http://localhost:5000',
  ENDPOINTS: {
    AUTH: '/auth/',
    PROJECTS: '/project/',
    TASKS: '/task/',
    TIMESHEETS: '/timesheet/',
    USERS: '/user/',
    HEALTH: '/health'
  },
  TIMEOUT: 10000,
} as const;

// API Response Types
export interface ApiResponse<T = any> {
  status: 'success' | 'error';
  message: string;
  data?: T;
  errors?: string[];
}

export interface ApiError {
  status: number;
  message: string;
  errors?: string[];
}

// Custom API Error Class
export class ApiException extends Error {
  public status: number;
  public errors?: string[];

  constructor(status: number, message: string, errors?: string[]) {
    super(message);
    this.name = 'ApiException';
    this.status = status;
    this.errors = errors;
  }
}

// Request Configuration
interface RequestConfig extends RequestInit {
  timeout?: number;
}

/**
 * Enhanced fetch wrapper with timeout, error handling, and authentication
 */
async function apiRequest<T>(
  endpoint: string,
  config: RequestConfig = {}
): Promise<T> {
  const { timeout = API_CONFIG.TIMEOUT, ...fetchConfig } = config;
  
  // Create AbortController for timeout
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeout);

  try {
    // Get auth token from localStorage (if available)
    const token = localStorage.getItem('authToken');
    
    // Default headers
    const defaultHeaders: HeadersInit = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };

    // Add authorization header if token exists
    if (token) {
      defaultHeaders['Authorization'] = `Bearer ${token}`;
    }

    // Merge headers
    const headers = {
      ...defaultHeaders,
      ...fetchConfig.headers,
    };

    const response = await fetch(`${API_CONFIG.BASE_URL}${endpoint}`, {
      ...fetchConfig,
      headers,
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    // Handle different response statuses
    if (!response.ok) {
      let errorMessage = `HTTP ${response.status}: ${response.statusText}`;
      let errors: string[] = [];

      try {
        const errorData: ApiResponse = await response.json();
        errorMessage = errorData.message || errorMessage;
        errors = errorData.errors || [];
      } catch {
        // If response is not JSON, use default error message
      }

      throw new ApiException(response.status, errorMessage, errors);
    }

    // Handle empty responses
    const contentType = response.headers.get('content-type');
    if (!contentType || !contentType.includes('application/json')) {
      return {} as T;
    }

    const data: ApiResponse<T> = await response.json();
    
    // Handle API-level errors
    if (data.status === 'error') {
      throw new ApiException(400, data.message, data.errors);
    }

    return data.data as T;
  } catch (error) {
    clearTimeout(timeoutId);

    if (error instanceof ApiException) {
      throw error;
    }

    if (error instanceof Error) {
      if (error.name === 'AbortError') {
        throw new ApiException(408, 'Request timeout');
      }
      throw new ApiException(500, error.message);
    }

    throw new ApiException(500, 'An unexpected error occurred');
  }
}

// HTTP Methods
export const api = {
  get: <T>(endpoint: string, config?: RequestConfig) =>
    apiRequest<T>(endpoint, { ...config, method: 'GET' }),

  post: <T>(endpoint: string, data?: any, config?: RequestConfig) =>
    apiRequest<T>(endpoint, {
      ...config,
      method: 'POST',
      body: data ? JSON.stringify(data) : undefined,
    }),

  put: <T>(endpoint: string, data?: any, config?: RequestConfig) =>
    apiRequest<T>(endpoint, {
      ...config,
      method: 'PUT',
      body: data ? JSON.stringify(data) : undefined,
    }),

  delete: <T>(endpoint: string, config?: RequestConfig) =>
    apiRequest<T>(endpoint, { ...config, method: 'DELETE' }),

  patch: <T>(endpoint: string, data?: any, config?: RequestConfig) =>
    apiRequest<T>(endpoint, {
      ...config,
      method: 'PATCH',
      body: data ? JSON.stringify(data) : undefined,
    }),
};

// Utility functions
export const buildQueryString = (params: Record<string, any>): string => {
  const searchParams = new URLSearchParams();
  
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== '') {
      searchParams.append(key, String(value));
    }
  });

  const queryString = searchParams.toString();
  return queryString ? `?${queryString}` : '';
};

// Health check function
export const checkApiHealth = async (): Promise<boolean> => {
  try {
    await api.get(API_CONFIG.ENDPOINTS.HEALTH);
    return true;
  } catch {
    return false;
  }
};