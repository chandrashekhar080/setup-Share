import { useState, useEffect } from 'react'
import { api, API_CONFIG } from '@/lib/api'

export interface Task {
  uid: string
  taskname: string
  project: string
  assignee?: string | null
  duedate?: string | null
  priority?: 'low' | 'medium' | 'high' | 'urgent'
  progress?: number
  comments?: string | null
  status?: 'todo' | 'in-progress' | 'completed' | 'cancelled'
  label?: string
  isActive?: boolean | number
  createdBy?: string | null
  lastUpdatedBy?: string | null
  createdAt?: string
  updatedAt?: string
}

export function useTasks(projectId?: string) {
  const [tasks, setTasks] = useState<Task[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const fetchTasks = async () => {
    setIsLoading(true)
    setError(null)
    try {
      const params = projectId ? `?project=${projectId}` : ''
      const data = await api.get<Task[]>(`${API_CONFIG.ENDPOINTS.TASKS}${params}`)
      
      // Transform the data to ensure it matches the expected format
      const transformedTasks = (data || []).map(task => ({
        ...task,
        // Add default label if not present
        label: task.label || 'feature',
        // Ensure status matches expected values
        status: task.status === 'todo' ? 'todo' : 
                task.status === 'in-progress' ? 'in-progress' :
                task.status === 'completed' ? 'completed' :
                task.status === 'cancelled' ? 'cancelled' : 'todo'
      }))
      
      setTasks(transformedTasks)
    } catch (err) {
      console.error('Error fetching tasks:', err)
      setError(err instanceof Error ? err.message : 'Failed to fetch tasks')
      setTasks([])
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchTasks()
  }, [projectId])

  const getTaskOptions = () => {
    return tasks.map(task => ({
      label: `${task.taskname} (${task.uid})`,
      value: task.uid
    }))
  }

  return {
    tasks,
    isLoading,
    error,
    refetch: fetchTasks,
    getTaskOptions
  }
}