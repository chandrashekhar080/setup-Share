import { useState, useEffect } from 'react'
import { api, API_CONFIG } from '@/lib/api'

export interface Project {
  uid: string
  projectName: string
  customer: string
  status: string
  projectManager: string
  startDate: string
  endDate: string
  progress: number
  priority: string
}

export function useProjects() {
  const [projects, setProjects] = useState<Project[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const fetchProjects = async () => {
    setIsLoading(true)
    setError(null)
    try {
      const data = await api.get<Project[]>(API_CONFIG.ENDPOINTS.PROJECTS)
      setProjects(data || [])
    } catch (err) {
      console.error('Error fetching projects:', err)
      setError(err instanceof Error ? err.message : 'Failed to fetch projects')
      setProjects([])
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchProjects()
  }, [])

  const getProjectOptions = () => {
    return projects.map(project => ({
      label: `${project.projectName} (${project.uid})`,
      value: project.uid
    }))
  }

  return {
    projects,
    isLoading,
    error,
    refetch: fetchProjects,
    getProjectOptions
  }
}