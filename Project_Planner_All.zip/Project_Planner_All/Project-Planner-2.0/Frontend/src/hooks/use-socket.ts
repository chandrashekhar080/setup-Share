/**
 * Socket.IO hook for real-time updates
 * Replaces the custom event system with proper WebSocket communication
 */

import { useEffect, useRef } from 'react'
import { io, Socket } from 'socket.io-client'

const SOCKET_URL = 'http://localhost:5000'

export const useSocket = () => {
  const socketRef = useRef<Socket | null>(null)

  useEffect(() => {
    // Create socket connection
    socketRef.current = io(SOCKET_URL, {
      transports: ['websocket', 'polling'],
      timeout: 20000,
    })

    const socket = socketRef.current

    socket.on('connect', () => {
      console.log('🔌 Connected to server via Socket.IO')
    })

    socket.on('disconnect', () => {
      console.log('🔌 Disconnected from server')
    })

    socket.on('connect_error', (error) => {
      console.error('🔌 Socket connection error:', error)
    })

    // Cleanup on unmount
    return () => {
      if (socketRef.current) {
        socketRef.current.disconnect()
        socketRef.current = null
      }
    }
  }, [])

  return socketRef.current
}

export const useProjectSocket = (onProjectsChange: () => void) => {
  const socket = useSocket()

  useEffect(() => {
    if (!socket) return

    // Listen for project events
    const handleProjectCreated = () => {
      console.log('📝 Project created - refreshing list')
      onProjectsChange()
    }

    const handleProjectUpdated = () => {
      console.log('✏️ Project updated - refreshing list')
      onProjectsChange()
    }

    const handleProjectDeleted = () => {
      console.log('🗑️ Project deleted - refreshing list')
      onProjectsChange()
    }

    socket.on('projectCreated', handleProjectCreated)
    socket.on('projectUpdated', handleProjectUpdated)
    socket.on('projectDeleted', handleProjectDeleted)

    // Cleanup listeners
    return () => {
      socket.off('projectCreated', handleProjectCreated)
      socket.off('projectUpdated', handleProjectUpdated)
      socket.off('projectDeleted', handleProjectDeleted)
    }
  }, [socket, onProjectsChange])

  return socket
}