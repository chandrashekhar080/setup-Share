const express = require("express");
const multer = require('multer');
const path = require('path');
const router = express.Router();
const AppConfig = require("../config/AppConfig");

const {
  verifyOtp,
  signUp,
  signIn,
  deleteusers,
  adminLogin,
  deleteadmins,
  checkDomain,
  sendOTP
} = require("../controller/Authcontroller");

/**
 * Authentication Routes - Following clean architecture
 */

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, AppConfig.upload.uploadDir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const filename = `${Date.now()}-${Math.round(Math.random() * 1E9)}${ext}`;
    cb(null, filename);
  }
});

// File filter for security
const fileFilter = (req, file, cb) => {
  if (AppConfig.upload.allowedTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error('Invalid file type. Only images are allowed.'), false);
  }
};

const upload = multer({ 
  storage,
  fileFilter,
  limits: {
    fileSize: AppConfig.upload.maxFileSize
  }
});

// Authentication routes
router.post("/register/verifyotp", verifyOtp);
router.post("/register/signup", upload.single('logo'), signUp);
router.post("/login", signIn);
router.post("/adminlogin", adminLogin);
router.get("/checkdomain", checkDomain);

// Development/Testing routes (only available in non-production)
if (!AppConfig.isProduction()) {
  router.post("/sendotp", sendOTP);
  router.get("/deleteusers", deleteusers);
  router.get("/deleteadmins", deleteadmins);
}

// Handle file upload errors
router.use((error, req, res, next) => {
  if (error instanceof multer.MulterError) {
    if (error.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({
        status: 'error',
        message: `File size too large. Maximum size is ${AppConfig.upload.maxFileSize / (1024 * 1024)}MB`
      });
    }
  } else if (error) {
    return res.status(400).json({
      status: 'error',
      message: error.message
    });
  }
  next();
});

module.exports = router;