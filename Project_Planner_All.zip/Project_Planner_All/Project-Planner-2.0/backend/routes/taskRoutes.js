const express = require("express");
const router = express.Router();

const {
  settask,
  gettask,
  edittask,
  deletetask,
  getTaskStats,
  updateTaskProgress,
  searchTasks
} = require("../controller/taskController");

/**
 * Task Routes - Following RESTful conventions
 */

// GET routes
router.get("/", gettask);
router.get("/gettask", gettask); // Backward compatibility
router.get("/stats", getTaskStats);
router.get("/search", searchTasks);

// POST routes
router.post("/", settask);
router.post("/settask", settask); // Backward compatibility
router.post("/edittask", edittask); // For getting task data for editing
router.post("/updateprogress", updateTaskProgress);

// DELETE routes
router.delete("/", deletetask);
router.post("/deletetask", deletetask); // Backward compatibility

module.exports = router;