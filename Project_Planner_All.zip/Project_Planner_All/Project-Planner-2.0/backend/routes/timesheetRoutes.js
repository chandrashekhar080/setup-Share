const express = require("express");
const router = express.Router();
const {
  settimesheet,
  gettimesheet,
  edittimesheet,
  deletetimesheet,
  getTimesheetStats,
  submitTimesheet,
  approveTimesheet,
  getTimesheetSummary,
  getTimesheetsByProject,
  getTimesheetsByTask,
  getTimesheetsByMember,
} = require("../controller/timesheetController");

/**
 * Timesheet Routes - Following RESTful conventions
 */

// GET routes
router.get("/", gettimesheet);
router.get("/gettimesheet", gettimesheet); // Backward compatibility
router.get("/stats", getTimesheetStats);
router.get("/summary", getTimesheetSummary);
router.get("/project/:projectUID", getTimesheetsByProject);
router.get("/task/:taskUID", getTimesheetsByTask);
router.get("/member/:member", getTimesheetsByMember);

// POST routes
router.post("/", settimesheet);
router.post("/settimesheet", settimesheet); // Backward compatibility
router.post("/edittimesheet", edittimesheet); // For getting timesheet data for editing
router.post("/submit", submitTimesheet);
router.post("/approve", approveTimesheet);

// DELETE routes
router.delete("/", deletetimesheet);
router.post("/deletetimesheet", deletetimesheet); // Backward compatibility

module.exports = router;
