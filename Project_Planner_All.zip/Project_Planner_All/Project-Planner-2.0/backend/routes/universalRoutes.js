const express = require("express");
const router = express.Router();
const {
  findByUid,
} = require("../controller/universalController");

router.post("/findByUid", findByUid);

module.exports = router;
