const express = require("express");
const MySQLController = require("../controller/MySQLController");

const router = express.Router();

/**
 * MySQL Management Routes
 * Following RESTful conventions and your established routing patterns
 */

// Health check
router.get("/health", MySQLController.healthCheck);

// Database operations
router.get("/databases", MySQLController.listDatabases);
router.get("/overview", MySQLController.getDatabaseOverview);

// Table operations
router.post("/tables/create", MySQLController.createTables);
router.get("/tables/check", MySQLController.checkTables);
router.get("/tables/:tableName/structure", MySQLController.getTableStructure);
router.get("/tables/:tableName/count", MySQLController.getRecordCount);

// Sample data operations
router.post("/sample-data/create", MySQLController.createSampleData);

// Multi-tenant operations
router.post("/multitenant/setup", MySQLController.setupMultiTenantDemo);

// Development endpoints (only in development)
router.delete("/dev/reset-all", MySQLController.resetAllData);

module.exports = router;
