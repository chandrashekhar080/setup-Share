const express = require("express");
const router = express.Router();
const {
  setpermission,
  getpermission,
  editpermission,
  deletepermission
} = require("../controller/Rolepermissioncontroller");

router.post("/setroles", setpermission);
router.get("/getroles", getpermission);
router.post("/editroles", editpermission);
router.post("/deleteroles", deletepermission);

module.exports = router;
