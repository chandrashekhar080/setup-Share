const express = require("express");
const router = express.Router();

const {
  setproject,
  getproject,
  editproject,
  deleteproject,
  getProjectStats,
  searchProjects
} = require("../controller/projectController");

/**
 * Project Routes - Following RESTful conventions
 */

// GET routes
router.get("/", getproject);
router.get("/getproject", getproject); // Backward compatibility
router.get("/stats", getProjectStats);
router.get("/search", searchProjects);

// POST routes
router.post("/", setproject);
router.post("/setproject", setproject); // Backward compatibility
router.post("/editproject", editproject); // For getting project data for editing

// PUT routes
router.put("/:uid", (req, res, next) => {
  req.body.uid = req.params.uid;
  setproject(req, res, next);
}); // RESTful update

// DELETE routes
router.delete("/:uid", (req, res, next) => {
  req.body.uid = req.params.uid;
  deleteproject(req, res, next);
});
router.post("/deleteproject", deleteproject); // Backward compatibility

module.exports = router;