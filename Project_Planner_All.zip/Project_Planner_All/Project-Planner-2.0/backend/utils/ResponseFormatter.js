/**
 * ResponseFormatter - Standardizes API response format
 * Following Single Responsibility Principle
 */
class ResponseFormatter {
  /**
   * Format success response
   * @param {string} message - Success message
   * @param {*} data - Response data (optional)
   * @param {number} statusCode - HTTP status code (default: 200)
   * @returns {Object} Formatted response
   */
  static success(message, data = null, statusCode = 200) {
    const response = {
      status: 'success',
      message,
      ...(data && { data })
    };
    
    return { response, statusCode };
  }

  /**
   * Format error response
   * @param {string} message - Error message
   * @param {number} statusCode - HTTP status code (default: 400)
   * @param {*} errorLog - Error details for debugging (optional)
   * @returns {Object} Formatted response
   */
  static error(message, statusCode = 400, errorLog = null) {
    const response = {
      status: 'error',
      message,
      ...(errorLog && process.env.NODE_ENV === 'development' && { errorlog: errorLog })
    };
    
    return { response, statusCode };
  }

  /**
   * Format validation error response
   * @param {Array|string} errors - Validation errors
   * @returns {Object} Formatted response
   */
  static validationError(errors) {
    const message = Array.isArray(errors) 
      ? 'Validation failed'
      : errors;
      
    const response = {
      status: 'error',
      message,
      ...(Array.isArray(errors) && { errors })
    };
    
    return { response, statusCode: 422 };
  }

  /**
   * Format unauthorized response
   * @param {string} message - Error message (optional)
   * @returns {Object} Formatted response
   */
  static unauthorized(message = 'Unauthorized access') {
    return {
      response: {
        status: 'error',
        message
      },
      statusCode: 401
    };
  }

  /**
   * Format not found response
   * @param {string} message - Error message (optional)
   * @returns {Object} Formatted response
   */
  static notFound(message = 'Resource not found') {
    return {
      response: {
        status: 'error',
        message
      },
      statusCode: 404
    };
  }

  /**
   * Format internal server error response
   * @param {string} message - Error message (optional)
   * @param {*} errorLog - Error details for debugging (optional)
   * @returns {Object} Formatted response
   */
  static serverError(message = 'Internal server error', errorLog = null) {
    return this.error(message, 500, errorLog);
  }
}

module.exports = ResponseFormatter;