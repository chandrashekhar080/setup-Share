/**
 * ApiResponse Hook - Standardized response utility
 * Usage: ApiResponse.success(res, data, message, statusCode)
 *        ApiResponse.error(res, message, statusCode, data)
 */
const ApiResponse = {
  /**
   * Success response
   * @param {Object} res - Express response object
   * @param {*} data - Response data
   * @param {string} message - Success message
   * @param {number} statusCode - HTTP status code
   * @returns {Object} JSON response
   */
  success: (res, data = null, message = "Success", statusCode = 200) => {
    return res.status(statusCode).json({
      status: "success",
      message,
      data,
    });
  },

  /**
   * Error response
   * @param {Object} res - Express response object
   * @param {string} message - Error message
   * @param {number} statusCode - HTTP status code
   * @param {*} data - Additional error data
   * @returns {Object} JSON response
   */
  error: (res, message = "Error", statusCode = 500, data = null) => {
    return res.status(statusCode).json({
      status: "error",
      message,
      data,
    });
  },

  /**
   * Validation error response
   * @param {Object} res - Express response object
   * @param {Array|string} errors - Validation errors
   * @param {number} statusCode - HTTP status code
   * @returns {Object} JSON response
   */
  validationError: (res, errors, statusCode = 400) => {
    return res.status(statusCode).json({
      status: "error",
      message: "Validation failed",
      data: {
        errors: Array.isArray(errors) ? errors : [errors],
      },
    });
  },

  /**
   * Unauthorized response
   * @param {Object} res - Express response object
   * @param {string} message - Unauthorized message
   * @returns {Object} JSON response
   */
  unauthorized: (res, message = "Unauthorized") => {
    return res.status(401).json({
      status: "error",
      message,
      data: null,
    });
  },

  /**
   * Forbidden response
   * @param {Object} res - Express response object
   * @param {string} message - Forbidden message
   * @returns {Object} JSON response
   */
  forbidden: (res, message = "Forbidden") => {
    return res.status(403).json({
      status: "error",
      message,
      data: null,
    });
  },

  /**
   * Not found response
   * @param {Object} res - Express response object
   * @param {string} message - Not found message
   * @returns {Object} JSON response
   */
  notFound: (res, message = "Not found") => {
    return res.status(404).json({
      status: "error",
      message,
      data: null,
    });
  },

  /**
   * Server error response
   * @param {Object} res - Express response object
   * @param {string} message - Server error message
   * @returns {Object} JSON response
   */
  serverError: (res, message = "Internal server error") => {
    return res.status(500).json({
      status: "error",
      message,
      data: null,
    });
  },
};

module.exports = ApiResponse;
