const ApiResponse = require("./ApiResponse");

/**
 * ErrorHandler - Centralized error handling utility
 * Following Single Responsibility Principle
 */
class ErrorHandler {
  /**
   * Handle controller errors
   * @param {Error} error - Error object
   * @param {Object} res - Express response object
   * @param {string} defaultMessage - Default error message
   */
  static handleControllerError(
    error,
    res,
    defaultMessage = "Something went wrong!!"
  ) {
    console.error("Controller Error:", error);
    console.error("Error stack:", error.stack);
    console.error("Error message:", error.message);

    // Handle specific error types
    if (error.message.includes("required")) {
      return ApiResponse.validationError(res, error.message);
    }

    if (
      error.message.includes("not found") ||
      error.message.includes("not available")
    ) {
      return ApiResponse.notFound(res, error.message);
    }

    if (
      error.message.includes("already") ||
      error.message.includes("duplicate")
    ) {
      return ApiResponse.error(res, error.message, 409);
    }

    if (
      error.message.includes("Invalid") ||
      error.message.includes("expired")
    ) {
      return ApiResponse.error(res, error.message, 400);
    }

    // Default server error - return actual error in development
    const isDevelopment = process.env.NODE_ENV !== 'production';
    const errorMessage = isDevelopment ? error.message : defaultMessage;
    return ApiResponse.serverError(res, errorMessage);
  }

  /**
   * Async wrapper for route handlers
   * @param {Function} fn - Async function to wrap
   * @returns {Function} Wrapped function with error handling
   */
  static asyncWrapper(fn) {
    return (req, res, next) => {
      Promise.resolve(fn(req, res, next)).catch((error) => {
        this.handleControllerError(error, res);
      });
    };
  }

  /**
   * Handle validation errors
   * @param {Array} validationErrors - Array of validation errors
   * @param {Object} res - Express response object
   */
  static handleValidationErrors(validationErrors, res) {
    return ApiResponse.validationError(res, validationErrors);
  }

  /**
   * Global error handler middleware
   * @param {Error} err - Error object
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   * @param {Function} next - Express next function
   */
  static globalErrorHandler(err, req, res, next) {
    console.error("Global Error:", err);

    if (res.headersSent) {
      return next(err);
    }

    return ApiResponse.serverError(res, "An unexpected error occurred");
  }
}

module.exports = ErrorHandler;
