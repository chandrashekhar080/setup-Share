/**
 * AuthValidator - Handles authentication-related validation
 * Following Single Responsibility Principle
 */
class AuthValidator {
  /**
   * Validate signup data
   * @param {Object} data - Signup data
   * @returns {Array} Array of validation errors (empty if valid)
   */
  static validateSignUp(data) {
    const errors = [];
    const { name, email, password, subdomain } = data;

    if (!name || name.trim().length < 2) {
      errors.push('Name is required and must be at least 2 characters long');
    }

    if (!email || !this.isValidEmail(email)) {
      errors.push('Valid email is required');
    }

    if (!password || password.length < 6) {
      errors.push('Password is required and must be at least 6 characters long');
    }

    if (!subdomain || subdomain.trim().length < 3) {
      errors.push('Subdomain is required and must be at least 3 characters long');
    }

    if (subdomain && !this.isValidSubdomain(subdomain)) {
      errors.push('Subdomain can only contain letters, numbers, and hyphens');
    }

    return errors;
  }

  /**
   * Validate signin data
   * @param {Object} data - Signin data
   * @returns {Array} Array of validation errors (empty if valid)
   */
  static validateSignIn(data) {
    const errors = [];
    const { email, password } = data;

    if (!email || !this.isValidEmail(email)) {
      errors.push('Valid email is required');
    }

    if (!password) {
      errors.push('Password is required');
    }

    return errors;
  }

  /**
   * Validate OTP verification data
   * @param {Object} data - OTP verification data
   * @returns {Array} Array of validation errors (empty if valid)
   */
  static validateOTPVerification(data) {
    const errors = [];
    const { mobile, otp } = data;

    if (!mobile || !this.isValidMobile(mobile)) {
      errors.push('Valid mobile number is required');
    }

    if (!otp || !/^\d{6}$/.test(otp)) {
      errors.push('Valid 6-digit OTP is required');
    }

    return errors;
  }

  /**
   * Validate admin login data
   * @param {Object} data - Admin login data
   * @returns {Array} Array of validation errors (empty if valid)
   */
  static validateAdminLogin(data) {
    const errors = [];
    const { email, password } = data;

    if (!email || !this.isValidEmail(email)) {
      errors.push('Valid email is required');
    }

    if (!password) {
      errors.push('Password is required');
    }

    return errors;
  }

  /**
   * Validate email format
   * @param {string} email - Email to validate
   * @returns {boolean} True if valid
   */
  static isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  /**
   * Validate mobile number format
   * @param {string} mobile - Mobile number to validate
   * @returns {boolean} True if valid
   */
  static isValidMobile(mobile) {
    // Basic mobile validation - adjust regex based on your requirements
    const mobileRegex = /^[+]?[\d\s\-()]{10,15}$/;
    return mobileRegex.test(mobile);
  }

  /**
   * Validate subdomain format
   * @param {string} subdomain - Subdomain to validate
   * @returns {boolean} True if valid
   */
  static isValidSubdomain(subdomain) {
    const subdomainRegex = /^[a-zA-Z0-9][a-zA-Z0-9-]{1,61}[a-zA-Z0-9]$/;
    return subdomainRegex.test(subdomain);
  }
}

module.exports = AuthValidator;