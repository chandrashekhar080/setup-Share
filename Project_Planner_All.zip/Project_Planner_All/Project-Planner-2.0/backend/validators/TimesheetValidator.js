/**
 * TimesheetValidator - Validates timesheet data
 * Following Single Responsibility Principle
 */

class TimesheetValidator {
  /**
   * Validate timesheet data
   * @param {Object} data - Timesheet data to validate
   * @returns {Array} Array of validation errors
   */
  static validateTimesheet(data) {
    const errors = [];
    const {
      project,
      task,
      member,
      startDate,
      endDate,
      hoursWorked,
      billableHours,
      hourlyRate,
      description,
      status
    } = data;

    // Required fields validation
    if (!project || typeof project !== 'string' || project.trim().length === 0) {
      errors.push('Project is required and must be a non-empty string');
    } else if (!/^(\d{7}|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/i.test(project)) {
      errors.push('Project UID must be a 7-digit number string or valid UUID');
    }

    // Task is optional, but if provided, must be valid
    if (task && (typeof task !== 'string' || task.trim().length === 0)) {
      errors.push('Task must be a non-empty string if provided');
    } else if (task && !/^(\d{7}|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/i.test(task)) {
      errors.push('Task UID must be a 7-digit number string or valid UUID');
    }

    if (!member || typeof member !== 'string' || member.trim().length === 0) {
      errors.push('Member is required and must be a non-empty string');
    } else {
      if (member.trim().length < 2) {
        errors.push('Member name must be at least 2 characters long');
      }
      if (member.trim().length > 100) {
        errors.push('Member name cannot exceed 100 characters');
      }
    }

    if (!startDate) {
      errors.push('Start date is required');
    } else {
      const startDateObj = new Date(startDate);
      if (isNaN(startDateObj.getTime())) {
        errors.push('Start date must be a valid date');
      }
    }

    // Optional fields validation
    if (endDate) {
      const endDateObj = new Date(endDate);
      if (isNaN(endDateObj.getTime())) {
        errors.push('End date must be a valid date');
      } else if (startDate) {
        const startDateObj = new Date(startDate);
        if (endDateObj <= startDateObj) {
          errors.push('End date must be after start date');
        }
      }
    }

    if (hoursWorked !== undefined && hoursWorked !== null) {
      const hours = parseFloat(hoursWorked);
      if (isNaN(hours) || hours < 0) {
        errors.push('Hours worked must be a non-negative number');
      } else if (hours > 24) {
        errors.push('Hours worked cannot exceed 24 hours per day');
      }
    }

    if (billableHours !== undefined && billableHours !== null) {
      const hours = parseFloat(billableHours);
      if (isNaN(hours) || hours < 0) {
        errors.push('Billable hours must be a non-negative number');
      } else if (hours > 24) {
        errors.push('Billable hours cannot exceed 24 hours per day');
      }
    }

    if (hourlyRate !== undefined && hourlyRate !== null) {
      const rate = parseFloat(hourlyRate);
      if (isNaN(rate) || rate < 0) {
        errors.push('Hourly rate must be a non-negative number');
      }
    }

    if (description && typeof description === 'string' && description.length > 1000) {
      errors.push('Description cannot exceed 1000 characters');
    }

    if (status && !['draft', 'submitted', 'approved', 'rejected', 'paid'].includes(status)) {
      errors.push('Status must be one of: draft, submitted, approved, rejected, paid');
    }

    return errors;
  }

  /**
   * Validate UID format
   * @param {string} uid - UID to validate
   * @returns {Array} Array of validation errors
   */
  static validateUID(uid) {
    const errors = [];

    if (!uid || typeof uid !== 'string' || uid.trim().length === 0) {
      errors.push('UID is required and must be a non-empty string');
    } else if (!/^\d{7}$/.test(uid)) {
      errors.push('UID must be a 7-digit number string');
    }

    return errors;
  }

  /**
   * Validate search parameters
   * @param {Object} params - Search parameters
   * @returns {Array} Array of validation errors
   */
  static validateSearchParams(params) {
    const errors = [];
    const { status, member, project, task, startDate, endDate } = params;

    if (status && !['draft', 'submitted', 'approved', 'rejected', 'paid'].includes(status)) {
      errors.push('Status must be one of: draft, submitted, approved, rejected, paid');
    }

    if (member && (typeof member !== 'string' || member.trim().length < 2)) {
      errors.push('Member name must be at least 2 characters long');
    }

    if (project && !/^(\d{7}|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/i.test(project)) {
      errors.push('Project UID must be a 7-digit number string or valid UUID');
    }

    if (task && !/^(\d{7}|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/i.test(task)) {
      errors.push('Task UID must be a 7-digit number string or valid UUID');
    }

    if (startDate) {
      const startDateObj = new Date(startDate);
      if (isNaN(startDateObj.getTime())) {
        errors.push('Start date must be a valid date');
      }
    }

    if (endDate) {
      const endDateObj = new Date(endDate);
      if (isNaN(endDateObj.getTime())) {
        errors.push('End date must be a valid date');
      } else if (startDate) {
        const startDateObj = new Date(startDate);
        if (endDateObj <= startDateObj) {
          errors.push('End date must be after start date');
        }
      }
    }

    return errors;
  }

  /**
   * Validate approval data
   * @param {Object} data - Approval data
   * @returns {Array} Array of validation errors
   */
  static validateApproval(data) {
    const errors = [];
    const { uid, approvedBy, action, rejectionReason } = data;

    // Validate UID
    const uidErrors = this.validateUID(uid);
    errors.push(...uidErrors);

    if (!approvedBy || typeof approvedBy !== 'string' || approvedBy.trim().length === 0) {
      errors.push('Approver name is required');
    } else if (approvedBy.trim().length < 2) {
      errors.push('Approver name must be at least 2 characters long');
    }

    if (!action || !['approve', 'reject'].includes(action)) {
      errors.push('Action must be either "approve" or "reject"');
    }

    if (action === 'reject') {
      if (!rejectionReason || typeof rejectionReason !== 'string' || rejectionReason.trim().length === 0) {
        errors.push('Rejection reason is required when rejecting a timesheet');
      } else if (rejectionReason.trim().length > 500) {
        errors.push('Rejection reason cannot exceed 500 characters');
      }
    }

    return errors;
  }

  /**
   * Validate date range for reports
   * @param {Object} data - Date range data
   * @returns {Array} Array of validation errors
   */
  static validateDateRange(data) {
    const errors = [];
    const { startDate, endDate } = data;

    if (!startDate) {
      errors.push('Start date is required');
    } else {
      const startDateObj = new Date(startDate);
      if (isNaN(startDateObj.getTime())) {
        errors.push('Start date must be a valid date');
      }
    }

    if (!endDate) {
      errors.push('End date is required');
    } else {
      const endDateObj = new Date(endDate);
      if (isNaN(endDateObj.getTime())) {
        errors.push('End date must be a valid date');
      } else if (startDate) {
        const startDateObj = new Date(startDate);
        if (endDateObj <= startDateObj) {
          errors.push('End date must be after start date');
        }
        
        // Check if date range is not too large (e.g., more than 1 year)
        const daysDiff = (endDateObj - startDateObj) / (1000 * 60 * 60 * 24);
        if (daysDiff > 365) {
          errors.push('Date range cannot exceed 365 days');
        }
      }
    }

    return errors;
  }
}

module.exports = TimesheetValidator;