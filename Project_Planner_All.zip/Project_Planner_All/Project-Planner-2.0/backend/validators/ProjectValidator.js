/**
 * ProjectValidator - Handles project-related validation
 * Following Single Responsibility Principle
 */
class ProjectValidator {
  /**
   * Validate project data
   * @param {Object} data - Project data
   * @returns {Array} Array of validation errors (empty if valid)
   */
  static validateProject(data) {
    const errors = [];
    const {
      projectName,
      customer,
      startDate,
      endDate,
      totalBudget,
      allocatedFunds,
      priority,
      status
    } = data;

    // Required fields validation
    if (!projectName || projectName.trim().length < 3) {
      errors.push('Project name is required and must be at least 3 characters long');
    }

    if (!customer || customer.trim().length < 2) {
      errors.push('Customer is required and must be at least 2 characters long');
    }

    // Date validation
    if (startDate && endDate) {
      const start = new Date(startDate);
      const end = new Date(endDate);
      
      if (isNaN(start.getTime())) {
        errors.push('Start date must be a valid date');
      }
      
      if (isNaN(end.getTime())) {
        errors.push('End date must be a valid date');
      }
      
      if (start.getTime() >= end.getTime()) {
        errors.push('End date must be after start date');
      }
    }

    // Budget validation
    if (totalBudget !== undefined && totalBudget !== null && totalBudget !== '') {
      const budget = parseFloat(totalBudget);
      if (isNaN(budget) || budget < 0) {
        errors.push('Total budget must be a valid positive number');
      }
    }

    if (allocatedFunds !== undefined && allocatedFunds !== null && allocatedFunds !== '') {
      const allocated = parseFloat(allocatedFunds);
      if (isNaN(allocated) || allocated < 0) {
        errors.push('Allocated funds must be a valid positive number');
      }

      // Check if allocated funds exceed total budget
      if (totalBudget && !isNaN(parseFloat(totalBudget)) && allocated > parseFloat(totalBudget)) {
        errors.push('Allocated funds cannot exceed total budget');
      }
    }

    // Priority validation
    if (priority && !this.isValidPriority(priority)) {
      errors.push('Priority must be one of: low, medium, high, urgent');
    }

    // Status validation
    if (status && !this.isValidStatus(status)) {
      errors.push('Status must be one of: planning, in_progress, completed, on_hold');
    }

    return errors;
  }

  /**
   * Validate project UID
   * @param {string} uid - Project UID
   * @returns {Array} Array of validation errors (empty if valid)
   */
  static validateUID(uid) {
    const errors = [];

    if (!uid || uid.trim() === '') {
      errors.push('UID is required');
    }

    return errors;
  }

  /**
   * Validate priority value
   * @param {string} priority - Priority value
   * @returns {boolean} True if valid
   */
  static isValidPriority(priority) {
    const validPriorities = ['low', 'medium', 'high', 'urgent'];
    return validPriorities.includes(priority.toLowerCase());
  }

  /**
   * Validate status value
   * @param {string} status - Status value
   * @returns {boolean} True if valid
   */
  static isValidStatus(status) {
    const validStatuses = ['planning', 'in_progress', 'completed', 'on_hold'];
    return validStatuses.includes(status);
  }

  /**
   * Validate project name format
   * @param {string} projectName - Project name
   * @returns {boolean} True if valid
   */
  static isValidProjectName(projectName) {
    // Project name should not contain special characters except spaces, hyphens, and underscores
    const nameRegex = /^[a-zA-Z0-9\s\-_]+$/;
    return nameRegex.test(projectName);
  }

  /**
   * Validate project search/filter parameters
   * @param {Object} params - Search parameters
   * @returns {Array} Array of validation errors (empty if valid)
   */
  static validateSearchParams(params) {
    const errors = [];
    const { status, priority, customer } = params;

    if (status && !this.isValidStatus(status)) {
      errors.push('Invalid status filter');
    }

    if (priority && !this.isValidPriority(priority)) {
      errors.push('Invalid priority filter');
    }

    if (customer && customer.trim().length < 2) {
      errors.push('Customer filter must be at least 2 characters long');
    }

    return errors;
  }
}

module.exports = ProjectValidator;