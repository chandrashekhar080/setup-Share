/**
 * TaskValidator - Handles task-related validation
 * Following Single Responsibility Principle
 */
class TaskValidator {
  /**
   * Validate task data
   * @param {Object} data - Task data
   * @returns {Array} Array of validation errors (empty if valid)
   */
  static validateTask(data) {
    const errors = [];
    const {
      taskname,
      project,
      assignee,
      duedate,
      priority,
      progress,
      status
    } = data;

    // Required fields validation
    if (!taskname || taskname.trim().length < 3) {
      errors.push('Task name is required and must be at least 3 characters long');
    }

    if (!project || project.trim() === '') {
      errors.push('Project is required');
    }

    // Optional field validations
    if (assignee && assignee.trim().length < 2) {
      errors.push('Assignee name must be at least 2 characters long');
    }

    // Due date validation
    if (duedate) {
      const dueDate = new Date(duedate);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      if (isNaN(dueDate.getTime())) {
        errors.push('Due date must be a valid date');
      } else if (dueDate < today) {
        errors.push('Due date cannot be in the past');
      }
    }

    // Priority validation
    if (priority && !this.isValidPriority(priority)) {
      errors.push('Priority must be one of: low, medium, high, urgent');
    }

    // Progress validation
    if (progress !== undefined && progress !== null && progress !== '') {
      const progressValue = parseInt(progress);
      if (isNaN(progressValue) || progressValue < 0 || progressValue > 100) {
        errors.push('Progress must be a number between 0 and 100');
      }
    }

    // Status validation
    if (status && !this.isValidStatus(status)) {
      errors.push('Status must be one of: todo, in-progress, completed, cancelled');
    }

    // Task name format validation
    if (taskname && !this.isValidTaskName(taskname)) {
      errors.push('Task name contains invalid characters');
    }

    return errors;
  }

  /**
   * Validate task UID
   * @param {string} uid - Task UID
   * @returns {Array} Array of validation errors (empty if valid)
   */
  static validateUID(uid) {
    const errors = [];

    if (!uid || uid.trim() === '') {
      errors.push('UID is required');
    }

    return errors;
  }

  /**
   * Validate priority value
   * @param {string} priority - Priority value
   * @returns {boolean} True if valid
   */
  static isValidPriority(priority) {
    const validPriorities = ['low', 'medium', 'high', 'urgent'];
    return validPriorities.includes(priority.toLowerCase());
  }

  /**
   * Validate status value
   * @param {string} status - Status value
   * @returns {boolean} True if valid
   */
  static isValidStatus(status) {
    const validStatuses = ['todo', 'in-progress', 'completed', 'cancelled'];
    return validStatuses.includes(status);
  }

  /**
   * Validate task name format
   * @param {string} taskname - Task name
   * @returns {boolean} True if valid
   */
  static isValidTaskName(taskname) {
    // Task name should not contain special characters except spaces, hyphens, and underscores
    const nameRegex = /^[a-zA-Z0-9\s\-_().]+$/;
    return nameRegex.test(taskname);
  }

  /**
   * Validate task search/filter parameters
   * @param {Object} params - Search parameters
   * @returns {Array} Array of validation errors (empty if valid)
   */
  static validateSearchParams(params) {
    const errors = [];
    const { status, priority, project, assignee } = params;

    if (status && !this.isValidStatus(status)) {
      errors.push('Invalid status filter');
    }

    if (priority && !this.isValidPriority(priority)) {
      errors.push('Invalid priority filter');
    }

    if (project && project.trim() === '') {
      errors.push('Project filter cannot be empty');
    }

    if (assignee && assignee.trim().length < 2) {
      errors.push('Assignee filter must be at least 2 characters long');
    }

    return errors;
  }

  /**
   * Validate bulk task operations
   * @param {Array} taskIds - Array of task IDs
   * @returns {Array} Array of validation errors (empty if valid)
   */
  static validateBulkOperation(taskIds) {
    const errors = [];

    if (!Array.isArray(taskIds)) {
      errors.push('Task IDs must be an array');
      return errors;
    }

    if (taskIds.length === 0) {
      errors.push('At least one task ID is required');
      return errors;
    }

    // Validate each task ID
    taskIds.forEach((id, index) => {
      if (!id || id.trim() === '') {
        errors.push(`Task ID at index ${index} is invalid`);
      }
    });

    return errors;
  }
}

module.exports = TaskValidator;