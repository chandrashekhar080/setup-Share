require("dotenv").config();
const { connectDB } = require("../config/mysql");
const UserModel = require("../models/mysql/userModel");
const ProjectModel = require("../models/mysql/projectModel");

/**
 * Create All Tables Script
 * Manually creates all required tables
 */
async function createAllTables() {
  let connection;

  try {
    console.log("🏗️  Creating MySQL Tables...\n");

    // Connect to main database
    console.log("1. Connecting to MySQL...");
    connection = await connectDB();
    console.log("✅ Connected successfully!");

    // Create Users table
    console.log("\n2. Creating Users table...");
    const userModel = new UserModel(connection);
    await userModel.createTable();
    console.log("✅ Users table created!");

    // Create Projects table
    console.log("\n3. Creating Projects table...");
    const projectModel = new ProjectModel(connection);
    await projectModel.createTable();
    console.log("✅ Projects table created!");

    // Verify tables were created
    console.log("\n4. Verifying tables...");
    const [tables] = await connection.execute("SHOW TABLES");

    console.log("\n📋 Created Tables:");
    tables.forEach((table, index) => {
      const tableName =
        table[`Tables_in_${process.env.MYSQL_DATABASE || "projectplanner"}`];
      console.log(`${index + 1}. ${tableName}`);
    });

    // Show table structures
    for (const table of tables) {
      const tableName =
        table[`Tables_in_${process.env.MYSQL_DATABASE || "projectplanner"}`];
      console.log(`\n📊 Structure of ${tableName}:`);

      const [columns] = await connection.execute(`DESCRIBE \`${tableName}\``);
      columns.forEach((col) => {
        console.log(
          `   - ${col.Field} (${col.Type}) ${
            col.Null === "NO" ? "NOT NULL" : "NULL"
          } ${col.Key ? col.Key : ""}`
        );
      });
    }

    console.log("\n🎉 All tables created successfully!");
    console.log("\n✨ You can now check phpMyAdmin to see the tables!");
  } catch (error) {
    console.error("\n❌ Error creating tables:", error.message);
    console.error("🔍 Full error:", error);
    process.exit(1);
  } finally {
    if (connection) {
      await connection.end();
      console.log("\n📴 Connection closed");
    }
  }
}

// Run if called directly
if (require.main === module) {
  createAllTables()
    .then(() => {
      console.log("\n✨ Table creation completed successfully!");
      process.exit(0);
    })
    .catch((error) => {
      console.error("\n💥 Table creation failed:", error);
      process.exit(1);
    });
}

module.exports = createAllTables;
