require("dotenv").config();
const mysql = require("mysql2/promise");
const AppConfig = require("../config/AppConfig");

/**
 * Check MySQL Tables Script
 * Shows all databases, tables, and their structure
 */
async function checkTables() {
  let connection;

  try {
    console.log("🔍 Checking MySQL Tables...\n");

    // Connect to MySQL
    connection = await mysql.createConnection({
      host: AppConfig.database.mysql.host,
      port: AppConfig.database.mysql.port,
      user: AppConfig.database.mysql.user,
      password: AppConfig.database.mysql.password,
      charset: "utf8mb4",
    });

    console.log("✅ Connected to MySQL server!\n");

    // Show all databases
    console.log("📊 Available Databases:");
    const [databases] = await connection.execute("SHOW DATABASES");
    databases.forEach((db, index) => {
      console.log(`${index + 1}. ${db.Database}`);
    });

    // Check main database
    const mainDb = AppConfig.database.mysql.database;
    console.log(`\n🔍 Checking database: ${mainDb}`);

    try {
      await connection.execute(`USE \`${mainDb}\``);

      // Show tables
      const [tables] = await connection.execute("SHOW TABLES");

      if (tables.length === 0) {
        console.log("📭 No tables found in this database");
      } else {
        console.log(`\n📋 Tables in ${mainDb}:`);

        for (let i = 0; i < tables.length; i++) {
          const tableName = tables[i][`Tables_in_${mainDb}`];
          console.log(`\n${i + 1}. Table: ${tableName}`);

          // Show table structure
          const [columns] = await connection.execute(
            `DESCRIBE \`${tableName}\``
          );
          console.log("   Columns:");
          columns.forEach((col) => {
            console.log(
              `   - ${col.Field} (${col.Type}) ${
                col.Null === "NO" ? "NOT NULL" : "NULL"
              } ${col.Key ? col.Key : ""}`
            );
          });

          // Show record count
          const [count] = await connection.execute(
            `SELECT COUNT(*) as count FROM \`${tableName}\``
          );
          console.log(`   Records: ${count[0].count}`);

          // Show sample data (first 3 records)
          if (count[0].count > 0) {
            const [sampleData] = await connection.execute(
              `SELECT * FROM \`${tableName}\` LIMIT 3`
            );
            console.log("   Sample Data:");
            sampleData.forEach((row, index) => {
              console.log(
                `   ${index + 1}. ${JSON.stringify(row, null, 2).replace(
                  /\n/g,
                  "\n      "
                )}`
              );
            });
          }
        }
      }
    } catch (error) {
      if (error.code === "ER_BAD_DB_ERROR") {
        console.log(`❌ Database '${mainDb}' does not exist`);
      } else {
        throw error;
      }
    }

    // Check tenant databases
    console.log("\n🏢 Checking Tenant Databases:");
    const tenantDbs = ["demo", "test", "sample"];

    for (const tenantDb of tenantDbs) {
      try {
        await connection.execute(`USE \`${tenantDb}\``);
        const [tables] = await connection.execute("SHOW TABLES");
        console.log(`✅ ${tenantDb}: ${tables.length} tables`);

        if (tables.length > 0) {
          tables.forEach((table) => {
            const tableName = table[`Tables_in_${tenantDb}`];
            console.log(`   - ${tableName}`);
          });
        }
      } catch (error) {
        if (error.code === "ER_BAD_DB_ERROR") {
          console.log(`❌ ${tenantDb}: Database does not exist`);
        } else {
          console.log(`❌ ${tenantDb}: Error - ${error.message}`);
        }
      }
    }

    console.log("\n🎉 Table check completed!");
  } catch (error) {
    console.error("\n❌ Error checking tables:", error.message);
    process.exit(1);
  } finally {
    if (connection) {
      await connection.end();
      console.log("\n📴 Connection closed");
    }
  }
}

// Run if called directly
if (require.main === module) {
  checkTables()
    .then(() => {
      console.log("\n✨ Check completed successfully!");
      process.exit(0);
    })
    .catch((error) => {
      console.error("\n💥 Check failed:", error);
      process.exit(1);
    });
}

module.exports = checkTables;
