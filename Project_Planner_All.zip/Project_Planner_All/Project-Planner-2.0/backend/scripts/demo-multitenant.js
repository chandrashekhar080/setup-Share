require("dotenv").config();
const { connectdyDB } = require("../config/dynamicmysql");
const UserModel = require("../models/mysql/userModel");
const ProjectModel = require("../models/mysql/projectModel");
const mysql = require("mysql2/promise");
const AppConfig = require("../config/AppConfig");

/**
 * Multi-Tenant Database Demo
 * Shows how databases are created dynamically per subdomain
 */
async function demoMultiTenant() {
  console.log("🏢 Multi-Tenant Database Demo\n");

  // Sample companies/subdomains
  const companies = [
    { subdomain: "acmecorp", name: "ACME Corporation" },
    { subdomain: "techstart", name: "Tech Startup Inc" },
    { subdomain: "consulting", name: "Business Consulting LLC" },
  ];

  let mainConnection;

  try {
    // Connect to MySQL server to check databases
    console.log("1. Connecting to MySQL server...");
    mainConnection = await mysql.createConnection({
      host: AppConfig.database.mysql.host,
      port: AppConfig.database.mysql.port,
      user: AppConfig.database.mysql.user,
      password: AppConfig.database.mysql.password,
      charset: "utf8mb4",
    });
    console.log("✅ Connected to MySQL server!");

    // Show databases before
    console.log("\n2. Current databases:");
    const [beforeDbs] = await mainConnection.execute("SHOW DATABASES");
    beforeDbs.forEach((db, index) => {
      console.log(`   ${index + 1}. ${db.Database}`);
    });

    console.log("\n3. Creating tenant databases and tables...\n");

    // Create databases and tables for each company
    for (const company of companies) {
      console.log(`🏢 Setting up: ${company.name} (${company.subdomain})`);

      try {
        // This will create the database if it doesn't exist
        const tenantConnection = await connectdyDB(company.subdomain);
        console.log(`   ✅ Database '${company.subdomain}' created/connected`);

        // Create tables in tenant database
        const userModel = new UserModel(tenantConnection);
        const projectModel = new ProjectModel(tenantConnection);

        await userModel.createTable();
        console.log(`   ✅ Users table created in '${company.subdomain}'`);

        await projectModel.createTable();
        console.log(`   ✅ Projects table created in '${company.subdomain}'`);

        // Create sample user for this tenant
        const sampleUser = {
          uid: Math.random().toString().substr(2, 7),
          email: `admin@${company.subdomain}.com`,
          name: `${company.name} Admin`,
          password: "hashedpassword123",
          subdomain: company.subdomain,
          role: "admin",
        };

        try {
          await userModel.create(sampleUser);
          console.log(`   ✅ Sample user created for '${company.subdomain}'`);
        } catch (error) {
          if (error.code === "ER_DUP_ENTRY") {
            console.log(
              `   ⚠️  Sample user already exists for '${company.subdomain}'`
            );
          } else {
            throw error;
          }
        }

        // Create sample project
        const sampleProject = {
          uid: Math.random().toString().substr(2, 7),
          projectName: `${company.name} Main Project`,
          customer: "Internal",
          description: `Main project for ${company.name}`,
          status: "active",
          priority: "high",
          startDate: new Date(),
          endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
          budget: 50000,
          team: JSON.stringify(["admin"]),
          tags: JSON.stringify(["main", "priority"]),
        };

        try {
          await projectModel.create(sampleProject);
          console.log(
            `   ✅ Sample project created for '${company.subdomain}'`
          );
        } catch (error) {
          if (error.code === "ER_DUP_ENTRY") {
            console.log(
              `   ⚠️  Sample project already exists for '${company.subdomain}'`
            );
          } else {
            throw error;
          }
        }

        // Show table counts
        const [userCount] = await tenantConnection.execute(
          "SELECT COUNT(*) as count FROM users"
        );
        const [projectCount] = await tenantConnection.execute(
          "SELECT COUNT(*) as count FROM projects"
        );

        console.log(
          `   📊 Users: ${userCount[0].count}, Projects: ${projectCount[0].count}`
        );

        await tenantConnection.end();
        console.log(`   📴 Connection to '${company.subdomain}' closed\n`);
      } catch (error) {
        console.error(
          `   ❌ Error setting up '${company.subdomain}':`,
          error.message
        );
      }
    }

    // Show databases after
    console.log("4. Databases after setup:");
    const [afterDbs] = await mainConnection.execute("SHOW DATABASES");
    afterDbs.forEach((db, index) => {
      const isNew = !beforeDbs.find(
        (beforeDb) => beforeDb.Database === db.Database
      );
      console.log(`   ${index + 1}. ${db.Database} ${isNew ? "🆕" : ""}`);
    });

    // Show detailed info for each tenant database
    console.log("\n5. Tenant Database Details:");
    for (const company of companies) {
      try {
        await mainConnection.execute(`USE \`${company.subdomain}\``);
        const [tables] = await mainConnection.execute("SHOW TABLES");

        console.log(`\n📊 Database: ${company.subdomain}`);
        console.log(`   Company: ${company.name}`);
        console.log(`   Tables: ${tables.length}`);

        tables.forEach((table) => {
          const tableName = table[`Tables_in_${company.subdomain}`];
          console.log(`   - ${tableName}`);
        });

        // Show record counts
        if (tables.length > 0) {
          for (const table of tables) {
            const tableName = table[`Tables_in_${company.subdomain}`];
            const [count] = await mainConnection.execute(
              `SELECT COUNT(*) as count FROM \`${tableName}\``
            );
            console.log(`     ${tableName}: ${count[0].count} records`);
          }
        }
      } catch (error) {
        console.log(
          `   ❌ Error checking '${company.subdomain}': ${error.message}`
        );
      }
    }

    console.log("\n🎉 Multi-tenant demo completed!");
    console.log("\n📋 Summary:");
    console.log(`✅ Created ${companies.length} tenant databases`);
    console.log("✅ Each database has its own users and projects tables");
    console.log("✅ Each tenant is completely isolated");
    console.log("✅ Sample data created for each tenant");
    console.log("\n🌐 Check phpMyAdmin to see all the new databases!");
  } catch (error) {
    console.error("\n❌ Demo failed:", error.message);
    console.error("🔍 Full error:", error);
    process.exit(1);
  } finally {
    if (mainConnection) {
      await mainConnection.end();
      console.log("\n📴 Main connection closed");
    }
  }
}

// Run if called directly
if (require.main === module) {
  demoMultiTenant()
    .then(() => {
      console.log("\n✨ Multi-tenant demo completed successfully!");
      process.exit(0);
    })
    .catch((error) => {
      console.error("\n💥 Demo failed:", error);
      process.exit(1);
    });
}

module.exports = demoMultiTenant;
