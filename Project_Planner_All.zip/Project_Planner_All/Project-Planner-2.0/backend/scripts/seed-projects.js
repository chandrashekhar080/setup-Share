require("dotenv").config();
const { connectDB } = require("../config/mysql");

/**
 * Seed Sample Projects Data
 */
async function seedProjects() {
  let db;

  try {
    console.log("🌱 Seeding sample projects data...\n");

    // Connect to database
    console.log("1. Connecting to database...");
    db = await connectDB();
    console.log("✅ Connected to database!");

    // Sample projects data
    const sampleProjects = [
      {
        uid: "1000001",
        projectName: "E-commerce Website Redesign",
        customer: "TechCorp Solutions",
        supervisor: "Sarah Johnson",
        startDate: "2024-01-15",
        endDate: "2024-04-15",
        duration: 90,
        projectDetails: "Complete redesign of the e-commerce platform with modern UI/UX, improved performance, and mobile responsiveness.",
        projectManager: "John Smith",
        totalBudget: 75000.00,
        allocatedFunds: 25000.00,
        budgetNotes: "Initial budget allocation for design phase",
        progress: 35,
        milestone: "UI/UX Design Phase Completed",
        followedByName: "Mike Davis",
        priority: "high",
        statusNotes: "On track, design phase completed successfully",
        status: "in_progress",
        team: JSON.stringify([
          { name: "Alice Cooper", role: "UI/UX Designer", email: "alice@techcorp.com" },
          { name: "Bob Wilson", role: "Frontend Developer", email: "bob@techcorp.com" },
          { name: "Carol Brown", role: "Backend Developer", email: "carol@techcorp.com" }
        ]),
        tags: JSON.stringify(["web", "ecommerce", "redesign", "responsive"]),
        lastUpdatedBy: "John Smith"
      },
      {
        uid: "1000002",
        projectName: "Mobile App Development",
        customer: "StartupXYZ",
        supervisor: "David Lee",
        startDate: "2024-02-01",
        endDate: "2024-06-30",
        duration: 150,
        projectDetails: "Development of a cross-platform mobile application for iOS and Android with real-time features.",
        projectManager: "Emma Wilson",
        totalBudget: 120000.00,
        allocatedFunds: 40000.00,
        budgetNotes: "Budget allocated for development tools and initial development phase",
        progress: 20,
        milestone: "Requirements Analysis Completed",
        followedByName: "Tom Anderson",
        priority: "urgent",
        statusNotes: "Project started, requirements gathering phase completed",
        status: "in_progress",
        team: JSON.stringify([
          { name: "Frank Miller", role: "Mobile Developer", email: "frank@startupxyz.com" },
          { name: "Grace Taylor", role: "QA Engineer", email: "grace@startupxyz.com" },
          { name: "Henry Clark", role: "DevOps Engineer", email: "henry@startupxyz.com" }
        ]),
        tags: JSON.stringify(["mobile", "ios", "android", "react-native"]),
        lastUpdatedBy: "Emma Wilson"
      },
      {
        uid: "1000003",
        projectName: "Data Analytics Dashboard",
        customer: "DataCorp Inc",
        supervisor: "Lisa Martinez",
        startDate: "2023-11-01",
        endDate: "2024-02-28",
        duration: 120,
        projectDetails: "Development of a comprehensive data analytics dashboard with real-time reporting and visualization capabilities.",
        projectManager: "Robert Johnson",
        totalBudget: 95000.00,
        allocatedFunds: 95000.00,
        budgetNotes: "Full budget allocated, project completed successfully",
        progress: 100,
        milestone: "Project Completed and Delivered",
        followedByName: "Jennifer White",
        priority: "medium",
        statusNotes: "Project completed successfully, client satisfied",
        status: "completed",
        team: JSON.stringify([
          { name: "Ivan Petrov", role: "Data Engineer", email: "ivan@datacorp.com" },
          { name: "Julia Roberts", role: "Frontend Developer", email: "julia@datacorp.com" },
          { name: "Kevin Brown", role: "Backend Developer", email: "kevin@datacorp.com" }
        ]),
        tags: JSON.stringify(["analytics", "dashboard", "data-visualization", "reporting"]),
        lastUpdatedBy: "Robert Johnson"
      },
      {
        uid: "1000004",
        projectName: "Cloud Migration Project",
        customer: "Enterprise Solutions Ltd",
        supervisor: "Michael Chen",
        startDate: "2024-03-01",
        endDate: "2024-08-31",
        duration: 180,
        projectDetails: "Migration of legacy systems to cloud infrastructure with improved scalability and security.",
        projectManager: "Amanda Davis",
        totalBudget: 200000.00,
        allocatedFunds: 50000.00,
        budgetNotes: "Initial phase budget allocation",
        progress: 15,
        milestone: "Infrastructure Assessment Completed",
        followedByName: "Steve Wilson",
        priority: "high",
        statusNotes: "Assessment phase completed, migration planning in progress",
        status: "planning",
        team: JSON.stringify([
          { name: "Luke Skywalker", role: "Cloud Architect", email: "luke@enterprise.com" },
          { name: "Mary Johnson", role: "DevOps Engineer", email: "mary@enterprise.com" },
          { name: "Nick Thompson", role: "Security Specialist", email: "nick@enterprise.com" }
        ]),
        tags: JSON.stringify(["cloud", "migration", "aws", "infrastructure"]),
        lastUpdatedBy: "Amanda Davis"
      },
      {
        uid: "1000005",
        projectName: "Marketing Website",
        customer: "Creative Agency Pro",
        supervisor: "Rachel Green",
        startDate: "2024-01-10",
        endDate: "2024-03-10",
        duration: 60,
        projectDetails: "Development of a modern marketing website with CMS integration and SEO optimization.",
        projectManager: "Chris Evans",
        totalBudget: 35000.00,
        allocatedFunds: 35000.00,
        budgetNotes: "Budget on hold due to scope changes",
        progress: 75,
        milestone: "Content Management System Integration",
        followedByName: "Monica Geller",
        priority: "low",
        statusNotes: "Project on hold pending client feedback on design changes",
        status: "on_hold",
        team: JSON.stringify([
          { name: "Oliver Queen", role: "Web Developer", email: "oliver@creative.com" },
          { name: "Penny Lane", role: "Content Writer", email: "penny@creative.com" }
        ]),
        tags: JSON.stringify(["website", "marketing", "cms", "seo"]),
        lastUpdatedBy: "Chris Evans"
      }
    ];

    // Insert sample projects
    console.log("\n2. Inserting sample projects...");
    
    for (const project of sampleProjects) {
      const query = `
        INSERT INTO projects (
          uid, projectName, customer, supervisor, startDate, endDate, duration,
          projectDetails, projectManager, totalBudget, allocatedFunds, budgetNotes,
          progress, milestone, followedByName, priority, statusNotes, status,
          team, tags, lastUpdatedBy, createdAt, updatedAt
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
        ON DUPLICATE KEY UPDATE
          projectName = VALUES(projectName),
          customer = VALUES(customer),
          updatedAt = NOW()
      `;

      const values = [
        project.uid,
        project.projectName,
        project.customer,
        project.supervisor,
        project.startDate,
        project.endDate,
        project.duration,
        project.projectDetails,
        project.projectManager,
        project.totalBudget,
        project.allocatedFunds,
        project.budgetNotes,
        project.progress,
        project.milestone,
        project.followedByName,
        project.priority,
        project.statusNotes,
        project.status,
        project.team,
        project.tags,
        project.lastUpdatedBy
      ];

      await db.execute(query, values);
      console.log(`✅ Inserted project: ${project.projectName}`);
    }

    console.log("\n3. Verifying inserted data...");
    const [rows] = await db.execute("SELECT COUNT(*) as count FROM projects");
    console.log(`✅ Total projects in database: ${rows[0].count}`);

    console.log("\n🎉 Sample projects seeded successfully!");
    console.log("\n📋 Seeded Projects:");
    sampleProjects.forEach((project, index) => {
      console.log(`${index + 1}. ${project.projectName} (${project.customer}) - ${project.status}`);
    });

  } catch (error) {
    console.error("\n❌ Seeding failed:", error.message);
    console.error(error);
    process.exit(1);
  } finally {
    if (db) {
      await db.end();
      console.log("\n📴 Database connection closed");
    }
  }
}

// Run seeding if called directly
if (require.main === module) {
  seedProjects()
    .then(() => {
      console.log("\n✨ Seeding completed successfully!");
      process.exit(0);
    })
    .catch((error) => {
      console.error("\n💥 Seeding failed:", error);
      process.exit(1);
    });
}

module.exports = seedProjects;