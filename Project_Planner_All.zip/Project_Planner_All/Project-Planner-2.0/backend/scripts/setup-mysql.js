require("dotenv").config();
const mysql = require("mysql2/promise");
const AppConfig = require("../config/AppConfig");

/**
 * MySQL Setup Script
 * Creates databases and basic structure for multi-tenant architecture
 */
async function setupMySQL() {
  let connection;

  try {
    console.log("🚀 Setting up MySQL for Project Planner...\n");

    // Connect to MySQL server (without specific database)
    console.log("1. Connecting to MySQL server...");
    connection = await mysql.createConnection({
      host: AppConfig.database.mysql.host,
      port: AppConfig.database.mysql.port,
      user: AppConfig.database.mysql.user,
      password: AppConfig.database.mysql.password,
      charset: "utf8mb4",
    });
    console.log("✅ Connected to MySQL server!");

    // Create main database
    console.log("\n2. Creating main database...");
    const mainDbName = AppConfig.database.mysql.database;
    await connection.execute(
      `CREATE DATABASE IF NOT EXISTS \`${mainDbName}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`
    );
    console.log(`✅ Database '${mainDbName}' created/verified!`);

    // Create sample tenant databases
    console.log("\n3. Creating sample tenant databases...");
    const sampleTenants = ["demo", "test", "sample"];

    for (const tenant of sampleTenants) {
      await connection.execute(
        `CREATE DATABASE IF NOT EXISTS \`${tenant}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`
      );
      console.log(`✅ Tenant database '${tenant}' created!`);
    }

    console.log("\n4. Setting up database permissions...");
    const user = AppConfig.database.mysql.user;

    // Grant permissions (if not root)
    if (user !== "root") {
      await connection.execute(
        `GRANT ALL PRIVILEGES ON \`${mainDbName}\`.* TO '${user}'@'%'`
      );
      for (const tenant of sampleTenants) {
        await connection.execute(
          `GRANT ALL PRIVILEGES ON \`${tenant}\`.* TO '${user}'@'%'`
        );
      }
      await connection.execute("FLUSH PRIVILEGES");
      console.log(`✅ Permissions granted to user '${user}'!`);
    } else {
      console.log("✅ Using root user - permissions already available!");
    }

    console.log("\n🎉 MySQL setup completed successfully!");
    console.log("\n📋 Summary:");
    console.log(`✅ Main database: ${mainDbName}`);
    console.log(`✅ Sample tenant databases: ${sampleTenants.join(", ")}`);
    console.log("✅ Permissions configured");
    console.log("\n🚀 You can now start the server with: npm run dev");
  } catch (error) {
    console.error("\n❌ MySQL setup failed:", error.message);

    if (error.code === "ER_ACCESS_DENIED_ERROR") {
      console.error("\n🔑 Access denied. Please check:");
      console.error("   - MySQL username and password in .env file");
      console.error("   - MySQL server is running");
      console.error("   - User has permission to create databases");
    } else if (error.code === "ECONNREFUSED") {
      console.error("\n🔌 Connection refused. Please check:");
      console.error("   - MySQL server is running");
      console.error("   - Host and port are correct in .env file");
      console.error("   - Firewall settings");
    }

    process.exit(1);
  } finally {
    if (connection) {
      await connection.end();
      console.log("\n📴 Connection closed");
    }
  }
}

// Run setup if called directly
if (require.main === module) {
  setupMySQL()
    .then(() => {
      console.log("\n✨ Setup completed successfully!");
      process.exit(0);
    })
    .catch((error) => {
      console.error("\n💥 Setup failed:", error);
      process.exit(1);
    });
}

module.exports = setupMySQL;
