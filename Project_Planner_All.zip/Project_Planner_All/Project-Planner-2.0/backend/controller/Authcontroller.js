const UserService = require("../services/UserService");
const AdminService = require("../services/AdminService");
const OTPService = require("../services/OTPService");
const EmailService = require("../services/EmailService");
const TenantService = require("../services/TenantService");
const AuthValidator = require("../validators/AuthValidator");
const ApiResponse = require("../utils/ApiResponse");
const ErrorHandler = require("../utils/ErrorHandler");
const auth = require("../config/auth");

/**
 * Clean Auth Controller - Following SOLID principles
 * Single Responsibility: Only handles HTTP requests/responses
 * Dependencies are injected through services
 */

/**
 * Verify OTP and create user account
 */
const verifyOtp = ErrorHandler.asyncWrapper(async (req, res) => {
  const { mobile, otp } = req.body;

  // Validate input
  const validationErrors = AuthValidator.validateOTPVerification({
    mobile,
    otp,
  });
  if (validationErrors.length > 0) {
    return ApiResponse.validationError(res, validationErrors);
  }

  // Verify OTP
  const otpResult = await OTPService.verifyOTP(mobile, otp);

  // Create user account
  await UserService.createFromMobile(mobile);

  return ApiResponse.success(res, null, "OTP verified successfully");
});

/**
 * User signup with email verification
 */
const signUp = ErrorHandler.asyncWrapper(async (req, res) => {
  const { name, email, password, subdomain } = req.body;
  const logoPath = req.file ? req.file.path : null;

  // Validate input
  const validationErrors = AuthValidator.validateSignUp({
    name,
    email,
    password,
    subdomain,
  });
  if (validationErrors.length > 0) {
    return ApiResponse.validationError(res, validationErrors);
  }

  // Check if user already exists
  const existenceCheck = await UserService.checkUserExistence(email, subdomain);
  if (existenceCheck.exists) {
    const message = existenceCheck.emailExists
      ? "This email is already in use"
      : "This domain is already in use";
    return ApiResponse.error(res, message, 409);
  }

  // Create user
  const userData = { name, email, password, subdomain, logo: logoPath };
  await UserService.createUser(userData);

  // Send welcome email
  await EmailService.sendWelcomeEmail(email);

  return ApiResponse.success(res, null, "You are registered successfully!");
});

/**
 * User signin
 */
const signIn = ErrorHandler.asyncWrapper(async (req, res) => {
  const { email, password } = req.body;

  // Validate input
  const validationErrors = AuthValidator.validateSignIn({ email, password });
  if (validationErrors.length > 0) {
    return ApiResponse.validationError(res, validationErrors);
  }

  // Authenticate user
  const user = await UserService.authenticateUser(email, password);
  if (!user) {
    return ApiResponse.unauthorized(res, "Invalid username or password");
  }

  // Generate token
  const token = auth.signInToken(user);

  return ApiResponse.success(
    res,
    {
      token,
      user: {
        _id: user._id || user.id,
        email: user.email,
      },
    },
    "You are signed in successfully!"
  );
});

/**
 * Admin login
 */
const adminLogin = ErrorHandler.asyncWrapper(async (req, res) => {
  const { email, password } = req.body;

  // Validate input
  const validationErrors = AuthValidator.validateAdminLogin({
    email,
    password,
  });
  if (validationErrors.length > 0) {
    return ApiResponse.validationError(res, validationErrors);
  }

  // Authenticate admin
  const admin = await AdminService.authenticateAdmin(email, password);
  if (!admin) {
    return ApiResponse.unauthorized(res, "Invalid username or password");
  }

  // Generate token
  const token = auth.signInToken(admin);

  return ApiResponse.success(res, { token }, "You are signed in successfully!");
});

/**
 * Check domain availability and setup tenant
 */
const checkDomain = ErrorHandler.asyncWrapper(async (req, res) => {
  const { subdomain } = req.query;

  if (!subdomain) {
    return ApiResponse.error(res, "Subdomain is required", 400);
  }

  const domainResult = await TenantService.checkAndSetupDomain(subdomain);

  return ApiResponse.success(
    res,
    {
      available: domainResult.available,
    },
    "This subdomain is available"
  );
});

/**
 * Send OTP to mobile (development endpoint)
 */
const sendOTP = ErrorHandler.asyncWrapper(async (req, res) => {
  const { mobile } = req.body;

  if (!mobile) {
    return ApiResponse.error(res, "Mobile number is required", 400);
  }

  const otp = await OTPService.sendOtpToMobile(mobile);

  return ApiResponse.success(res, { otp }, "OTP sent successfully");
});

// Development/Testing endpoints (should be removed in production)
const deleteusers = ErrorHandler.asyncWrapper(async (req, res) => {
  if (process.env.NODE_ENV === "production") {
    return ApiResponse.forbidden(res, "Not allowed in production");
  }

  const result = await UserService.deleteAll();
  return ApiResponse.success(res, result, "All users cleared");
});

const deleteadmins = ErrorHandler.asyncWrapper(async (req, res) => {
  if (process.env.NODE_ENV === "production") {
    return ApiResponse.forbidden(res, "Not allowed in production");
  }

  const result = await AdminService.deleteAll();
  return ApiResponse.success(res, result, "All admins cleared");
});

module.exports = {
  verifyOtp,
  signUp,
  signIn,
  deleteusers,
  adminLogin,
  deleteadmins,
  checkDomain,
  sendOTP,
};
