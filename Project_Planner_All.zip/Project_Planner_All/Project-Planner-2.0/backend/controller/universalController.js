const mongoose = require("mongoose");
const ApiResponse = require("../utils/ApiResponse");

const findByUid = async (req, res) => {
  try {
    const { modelName, uid } = req.body;
    if (!modelName || !uid) {
      return ApiResponse.error(res, "Model name and uid are required", 400);
    }
    const Model = mongoose.model(modelName);
    const data = await Model.findOne({ uid });
    if (!data) {
      return ApiResponse.notFound(res, "Document not found");
    }
    return ApiResponse.success(res, data, "Document found successfully");
  } catch (error) {
    console.error("Error in findByUid:", error);
    return ApiResponse.serverError(res, "Something went wrong");
  }
};

module.exports = {
  findByUid,
};
