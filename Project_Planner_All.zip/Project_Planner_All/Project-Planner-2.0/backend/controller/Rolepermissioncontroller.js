// const Roles = require("../models/permissionModel");
const ApiResponse = require("../utils/ApiResponse");

const setpermission = async (req, res) => {
  const Roles = req.db.model(
    "rolepermission",
    require("../models/permissionModel").schema
  );
  try {
    const { rolename, roledescription, rolestatus, rolepermission, edit } =
      req.body;

    if (!rolename || !rolepermission) {
      return ApiResponse.error(
        res,
        "Rolename and rolepermission are required",
        400
      );
    }
    if (edit) {
      const uid = edit;
      const result = await Roles.updateOne(
        { uid },
        {
          $set: {
            rolename,
            roledescription,
            status: rolestatus,
            rolepermission: rolepermission,
          },
        }
      );
    } else {
      const role = await Roles.findOne({ rolename });
      if (role) {
        return ApiResponse.error(res, "This role name is already in use!", 400);
      }
      const uid = Math.floor(1000000 + Math.random() * 9000000);
      const newRole = new Roles({
        uid,
        rolename,
        roledescription,
        status: rolestatus,
        rolepermission: rolepermission,
      });
      await newRole.save();
    }

    return ApiResponse.success(res, null, "Role saved successfully");
  } catch (error) {
    console.error("Error in setpermission:", error);
    return ApiResponse.serverError(res, "Something went wrong!!");
  }
};

const getpermission = async (req, res) => {
  const Roles = req.db.model(
    "rolepermission",
    require("../models/permissionModel").schema
  );
  try {
    const data = await Roles.find();
    return ApiResponse.success(res, data, "Roles fetched successfully");
  } catch (error) {
    console.error("Error in getpermission:", error);
    return ApiResponse.serverError(res, "Something went wrong!!");
  }
};

const editpermission = async (req, res) => {
  const Roles = req.db.model(
    "rolepermission",
    require("../models/permissionModel").schema
  );
  try {
    const { uid } = req.body;
    if (!uid) {
      return ApiResponse.error(res, "UID is required!", 400);
    }
    const role = await Roles.findOne({ uid });
    if (!role) {
      return ApiResponse.notFound(res, "This role is not available!");
    }
    return ApiResponse.success(res, role, "Data fetched successfully");
  } catch (error) {
    console.error("Error in editpermission:", error);
    return ApiResponse.serverError(res, "Something went wrong!!");
  }
};

const deletepermission = async (req, res) => {
  const Roles = req.db.model(
    "rolepermission",
    require("../models/permissionModel").schema
  );
  try {
    const { uid } = req.body;
    if (!uid) {
      return ApiResponse.error(res, "UID is required!", 400);
    }
    const deleted = await Roles.findOneAndDelete({ uid });
    if (!deleted) {
      return ApiResponse.notFound(res, "Role not found or already deleted.");
    }
    return ApiResponse.success(res, deleted, "Role deleted successfully");
  } catch (error) {
    console.error("Error in deletepermission:", error);
    return ApiResponse.serverError(res, "Something went wrong!!");
  }
};

module.exports = {
  setpermission,
  getpermission,
  editpermission,
  deletepermission,
};
