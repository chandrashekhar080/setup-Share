const TaskService = require("../services/TaskServiceMySQL");
const TaskValidator = require("../validators/TaskValidator");
const ApiResponse = require("../utils/ApiResponse");
const ErrorHandler = require("../utils/ErrorHandler");

/**
 * Clean Task Controller - Following SOLID principles
 * Single Responsibility: Only handles HTTP requests/responses
 * Dependencies are injected through services
 */

/**
 * Create or update task
 */
const settask = ErrorHandler.asyncWrapper(async (req, res) => {
  const {
    taskname,
    project,
    assignee,
    duedate,
    priority,
    progress,
    comments,
    status,
    edit,
  } = req.body;

  const taskData = {
    taskname,
    project,
    assignee,
    duedate,
    priority,
    progress,
    comments,
    status,
    createdBy: req.user?.id || 'system', // Add default createdBy
  };

  // Validate input
  const validationErrors = TaskValidator.validateTask(taskData);
  if (validationErrors.length > 0) {
    return ApiResponse.validationError(res, validationErrors);
  }

  // Create task service instance
  const taskService = new TaskService();

  // Create or update task
  const result = await taskService.createOrUpdateTask(taskData, edit);

  return ApiResponse.success(res, result.data, result.message);
});

/**
 * Get tasks (optionally filtered by project)
 */
const gettask = ErrorHandler.asyncWrapper(async (req, res) => {
  const { uid, status, priority, assignee } = req.query;

  // Validate filter parameters
  const validationErrors = TaskValidator.validateSearchParams({
    status,
    priority,
    assignee,
  });
  if (validationErrors.length > 0) {
    return ApiResponse.validationError(res, validationErrors);
  }

  // Create task service instance
  const taskService = new TaskService();

  // Build filters
  const filters = {};
  if (uid) filters.project = uid;
  if (status) filters.status = status;
  if (priority) filters.priority = priority;
  if (assignee) filters.assignee = assignee;

  // Get tasks with filters
  const result = await taskService.getAllTasks(filters);

  return ApiResponse.success(res, result.data, "Tasks fetched successfully");
});

/**
 * Get task for editing
 */
const edittask = ErrorHandler.asyncWrapper(async (req, res) => {
  const { uid } = req.body;

  // Validate UID
  const validationErrors = TaskValidator.validateUID(uid);
  if (validationErrors.length > 0) {
    return ApiResponse.validationError(res, validationErrors);
  }

  // Create task service instance
  const taskService = new TaskService();

  // Get task
  const result = await taskService.getTaskByUID(uid);

  return ApiResponse.success(res, result.data, "Task data fetched successfully");
});

/**
 * Delete task
 */
const deletetask = ErrorHandler.asyncWrapper(async (req, res) => {
  const { uid } = req.body;

  // Validate UID
  const validationErrors = TaskValidator.validateUID(uid);
  if (validationErrors.length > 0) {
    return ApiResponse.validationError(res, validationErrors);
  }

  // Create task service instance
  const taskService = new TaskService();

  // Delete task
  const result = await taskService.deleteTask(uid);

  return ApiResponse.success(res, result.data, result.message);
});

/**
 * Get task statistics
 */
const getTaskStats = ErrorHandler.asyncWrapper(async (req, res) => {
  const { projectUID } = req.query;

  // Create task service instance
  const taskService = new TaskService();

  // Get task statistics
  const result = await taskService.getTaskStats();

  return ApiResponse.success(res, result.data, "Task statistics fetched successfully");
});

/**
 * Update task progress
 */
const updateTaskProgress = ErrorHandler.asyncWrapper(async (req, res) => {
  const { uid, progress } = req.body;

  // Validate input
  if (!uid) {
    return ApiResponse.error(res, "Task UID is required", 400);
  }

  if (progress === undefined || progress === null) {
    return ApiResponse.error(res, "Progress value is required", 400);
  }

  const progressValue = parseInt(progress);
  if (isNaN(progressValue) || progressValue < 0 || progressValue > 100) {
    return ApiResponse.error(
      res,
      "Progress must be a number between 0 and 100",
      400
    );
  }

  // Create task service instance
  const taskService = new TaskService();

  // Update progress
  const result = await taskService.updateTaskProgress(uid, progressValue);

  return ApiResponse.success(res, result.data, result.message);
});

/**
 * Search tasks
 */
const searchTasks = ErrorHandler.asyncWrapper(async (req, res) => {
  const { q, status, priority, project } = req.query;

  if (!q || q.trim().length < 2) {
    return ApiResponse.error(
      res,
      "Search query must be at least 2 characters long",
      400
    );
  }

  // Create task service instance
  const taskService = new TaskService();

  // Build filters
  const filters = { q };
  if (status) filters.status = status;
  if (priority) filters.priority = priority;
  if (project) filters.project = project;

  // Search tasks
  const result = await taskService.searchTasks(q, filters);

  return ApiResponse.success(res, result.data, "Search completed successfully");
});

module.exports = {
  settask,
  gettask,
  edittask,
  deletetask,
  getTaskStats,
  updateTaskProgress,
  searchTasks,
};
