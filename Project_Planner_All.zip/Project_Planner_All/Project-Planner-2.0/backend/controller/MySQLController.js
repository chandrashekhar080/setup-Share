const MySQLService = require("../services/MySQLService");
const ApiResponse = require("../utils/ApiResponse");
const ErrorHandler = require("../utils/ErrorHandler");

/**
 * MySQL Controller - Following SOLID principles
 * Single Responsibility: Handle HTTP requests/responses for MySQL operations
 * Dependencies injected through MySQLService
 */

/**
 * Create tables in database
 */
const createTables = ErrorHandler.asyncWrapper(async (req, res) => {
  const { database } = req.query;

  try {
    const result = await MySQLService.createTables(database);
    return ApiResponse.success(res, result, "Tables created successfully");
  } catch (error) {
    return ApiResponse.error(res, error.message, 500);
  }
});

/**
 * Check tables in database
 */
const checkTables = ErrorHandler.asyncWrapper(async (req, res) => {
  const { database } = req.query;

  try {
    const result = await MySQLService.checkTables(database);
    return ApiResponse.success(res, result, "Tables checked successfully");
  } catch (error) {
    return ApiResponse.error(res, error.message, 500);
  }
});

/**
 * Get table structure
 */
const getTableStructure = ErrorHandler.asyncWrapper(async (req, res) => {
  const { tableName } = req.params;
  const { database } = req.query;

  if (!tableName) {
    return ApiResponse.error(res, "Table name is required", 400);
  }

  try {
    const result = await MySQLService.getTableStructure(tableName, database);
    return ApiResponse.success(
      res,
      result,
      "Table structure retrieved successfully"
    );
  } catch (error) {
    return ApiResponse.error(res, error.message, 500);
  }
});

/**
 * Get record count for table
 */
const getRecordCount = ErrorHandler.asyncWrapper(async (req, res) => {
  const { tableName } = req.params;
  const { database } = req.query;

  if (!tableName) {
    return ApiResponse.error(res, "Table name is required", 400);
  }

  try {
    const result = await MySQLService.getRecordCount(tableName, database);
    return ApiResponse.success(
      res,
      result,
      "Record count retrieved successfully"
    );
  } catch (error) {
    return ApiResponse.error(res, error.message, 500);
  }
});

/**
 * List all databases
 */
const listDatabases = ErrorHandler.asyncWrapper(async (req, res) => {
  try {
    const result = await MySQLService.listDatabases();
    return ApiResponse.success(res, result, "Databases listed successfully");
  } catch (error) {
    return ApiResponse.error(res, error.message, 500);
  }
});

/**
 * Create sample data
 */
const createSampleData = ErrorHandler.asyncWrapper(async (req, res) => {
  const { database } = req.query;

  try {
    const result = await MySQLService.createSampleData(database);
    return ApiResponse.success(res, result, "Sample data created successfully");
  } catch (error) {
    return ApiResponse.error(res, error.message, 500);
  }
});

/**
 * Setup multi-tenant demo
 */
const setupMultiTenantDemo = ErrorHandler.asyncWrapper(async (req, res) => {
  // Default tenants if none provided
  const defaultTenants = [
    { subdomain: "acmecorp", name: "ACME Corporation" },
    { subdomain: "techstart", name: "Tech Startup Inc" },
    { subdomain: "consulting", name: "Business Consulting LLC" },
  ];

  const { tenants = defaultTenants } = req.body;

  // Validate tenants array
  if (!Array.isArray(tenants) || tenants.length === 0) {
    return ApiResponse.error(res, "Tenants array is required", 400);
  }

  // Validate tenant structure
  for (const tenant of tenants) {
    if (!tenant.subdomain || !tenant.name) {
      return ApiResponse.error(
        res,
        "Each tenant must have subdomain and name",
        400
      );
    }
  }

  try {
    const result = await MySQLService.setupMultiTenantDemo(tenants);
    return ApiResponse.success(
      res,
      result,
      "Multi-tenant demo setup completed"
    );
  } catch (error) {
    return ApiResponse.error(res, error.message, 500);
  }
});

/**
 * Get database overview
 */
const getDatabaseOverview = ErrorHandler.asyncWrapper(async (req, res) => {
  try {
    const result = await MySQLService.getDatabaseOverview();
    return ApiResponse.success(
      res,
      result,
      "Database overview retrieved successfully"
    );
  } catch (error) {
    return ApiResponse.error(res, error.message, 500);
  }
});

/**
 * Health check for MySQL connection
 */
const healthCheck = ErrorHandler.asyncWrapper(async (req, res) => {
  try {
    // Try to get a connection to test MySQL health
    const result = await MySQLService.listDatabases();

    return ApiResponse.success(
      res,
      {
        status: "healthy",
        mysql: "connected",
        databases: result.count,
        timestamp: new Date().toISOString(),
      },
      "MySQL connection is healthy"
    );
  } catch (error) {
    return ApiResponse.error(
      res,
      `MySQL connection failed: ${error.message}`,
      503
    );
  }
});

/**
 * Development endpoint - Reset all data (only in development)
 */
const resetAllData = ErrorHandler.asyncWrapper(async (req, res) => {
  if (process.env.NODE_ENV === "production") {
    return ApiResponse.forbidden(res, "Not allowed in production");
  }

  const { confirm } = req.body;

  if (confirm !== "RESET_ALL_DATA") {
    return ApiResponse.error(
      res,
      'Confirmation required: send {"confirm": "RESET_ALL_DATA"}',
      400
    );
  }

  try {
    // This is a dangerous operation - only for development
    const databases = await MySQLService.listDatabases();
    const results = [];

    for (const dbName of databases.databases) {
      try {
        // Skip system databases
        if (["projectplanner"].includes(dbName)) continue;

        // Drop tenant databases (be very careful!)
        const connection = await MySQLService.getConnection();
        await connection.execute(`DROP DATABASE IF EXISTS \`${dbName}\``);
        results.push({ database: dbName, status: "dropped" });
      } catch (error) {
        results.push({
          database: dbName,
          status: "error",
          error: error.message,
        });
      }
    }

    return ApiResponse.success(
      res,
      { results },
      "Development data reset completed"
    );
  } catch (error) {
    return ApiResponse.error(res, error.message, 500);
  }
});

module.exports = {
  createTables,
  checkTables,
  getTableStructure,
  getRecordCount,
  listDatabases,
  createSampleData,
  setupMultiTenantDemo,
  getDatabaseOverview,
  healthCheck,
  resetAllData,
};
