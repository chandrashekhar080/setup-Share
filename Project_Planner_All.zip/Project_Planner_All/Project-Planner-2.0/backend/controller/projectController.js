const { getProjectService } = require("../services/MySQLProjectService");
const ApiResponse = require("../utils/ApiResponse");
const ErrorHandler = require("../utils/ErrorHandler");

/**
 * Clean Project Controller - Following SOLID principles
 * Single Responsibility: Only handles HTTP requests/responses
 * Dependencies are injected through services
 */

/**
 * Create or update project
 */
const setproject = ErrorHandler.asyncWrapper(async (req, res) => {

  const {
    projectName,
    customer,
    supervisor,
    startDate,
    endDate,
    duration,
    projectDetails,
    projectManager,
    totalBudget,
    allocatedFunds,
    budgetNotes,
    progress,
    milestone,
    followedByName,
    priority,
    statusNotes,
    status,
    team,
    tags,
    attachments,
    lastUpdatedBy,
    edit,
  } = req.body;

  // Get uid from params (for PUT requests) or body (for POST requests)
  const uid = req.params.uid || req.body.uid;



  // Basic validation - only for create operations (not updates)
  const isUpdate = edit || uid;
  if (!isUpdate && (!projectName || !customer || !projectManager)) {
    return ApiResponse.error(res, "Project name, customer, and project manager are required", 400);
  }

  const projectData = {
    uid,
    projectName,
    customer,
    supervisor,
    startDate,
    endDate,
    duration,
    projectDetails,
    projectManager,
    totalBudget: parseFloat(totalBudget) || 0,
    allocatedFunds: parseFloat(allocatedFunds) || 0,
    budgetNotes,
    progress: parseInt(progress) || 0,
    milestone,
    followedByName,
    priority: priority || 'medium',
    statusNotes,
    status: status || 'planning',
    // Ensure arrays are properly handled
    team: Array.isArray(team) ? team : (team ? [team] : []),
    tags: Array.isArray(tags) ? tags : (tags ? [tags] : []),
    attachments: Array.isArray(attachments) ? attachments : (attachments ? [attachments] : []),
    lastUpdatedBy,
  };

  // Create project service instance
  const projectService = await getProjectService();

  let result;
  if (edit || uid) {
    // Update existing project - use uid from body or URL params
    const projectUid = uid || edit;
    // Update existing project
    
    result = await projectService.updateProject(projectUid, projectData);
    
    // Emit Socket.IO event for real-time updates
    if (global.io) {
      global.io.emit('projectUpdated', result);
    }
    
    return ApiResponse.success(res, result, "Project updated successfully");
  } else {
    // Create new project
    result = await projectService.createProject(projectData);
    
    // Emit Socket.IO event for real-time updates
    if (global.io) {
      global.io.emit('projectCreated', result);
    }
    
    return ApiResponse.success(res, result, "Project created successfully");
  }
});

/**
 * Get all projects
 */
const getproject = ErrorHandler.asyncWrapper(async (req, res) => {
  // Create project service instance
  const projectService = await getProjectService();

  // Get filter parameters from query
  const { status, priority, customer, projectManager } = req.query;
  const filter = {};

  if (status) filter.status = status;
  if (priority) filter.priority = priority;
  if (customer) filter.customer = customer;
  if (projectManager) filter.projectManager = projectManager;

  // Get projects
  const projects = await projectService.getProjects(filter);

  return ApiResponse.success(res, projects, "Projects fetched successfully");
});

/**
 * Get project for editing
 */
const editproject = ErrorHandler.asyncWrapper(async (req, res) => {
  const { uid } = req.body;

  // Validate UID
  if (!uid) {
    return ApiResponse.error(res, "UID is required", 400);
  }

  // Create project service instance
  const projectService = await getProjectService();

  // Get project
  const project = await projectService.getProjectByUID(uid);
  
  if (!project) {
    return ApiResponse.error(res, "Project not found", 404);
  }

  return ApiResponse.success(res, project, "Project data fetched successfully");
});

/**
 * Delete project
 */
const deleteproject = ErrorHandler.asyncWrapper(async (req, res) => {
  const { uid } = req.body;

  // Validate UID
  if (!uid) {
    return ApiResponse.error(res, "UID is required", 400);
  }

  // Create project service instance
  const projectService = await getProjectService();

  // Delete project
  const deletedProject = await projectService.deleteProject(uid);

  // Emit Socket.IO event for real-time updates
  if (global.io) {
    global.io.emit('projectDeleted', { uid });
  }

  return ApiResponse.success(
    res,
    deletedProject,
    "Project deleted successfully"
  );
});

/**
 * Get project statistics
 */
const getProjectStats = ErrorHandler.asyncWrapper(async (req, res) => {
  // Create project service instance
  const projectService = await getProjectService();

  // Get project statistics
  const stats = await projectService.getProjectStats();

  return ApiResponse.success(
    res,
    stats,
    "Project statistics fetched successfully"
  );
});

/**
 * Search projects
 */
const searchProjects = ErrorHandler.asyncWrapper(async (req, res) => {
  const { q, status, priority, customer } = req.query;

  if (!q || q.trim().length < 2) {
    return ApiResponse.error(
      res,
      "Search query must be at least 2 characters long",
      400
    );
  }

  // Create project service instance
  const projectService = await getProjectService();

  // Build additional filters
  const additionalFilters = {};
  if (status) additionalFilters.status = status;
  if (priority) additionalFilters.priority = priority;
  if (customer) additionalFilters.customer = customer;

  // Search projects
  const projects = await projectService.searchProjects(q.trim(), additionalFilters);

  return ApiResponse.success(res, projects, "Search completed successfully");
});

module.exports = {
  setproject,
  getproject,
  editproject,
  deleteproject,
  getProjectStats,
  searchProjects,
};
