const TimesheetService = require("../services/TimesheetServiceMySQL");
const TimesheetValidator = require("../validators/TimesheetValidator");
const ApiResponse = require("../utils/ApiResponse");
const ErrorHandler = require("../utils/ErrorHandler");

/**
 * Enhanced Timesheet Controller - Following SOLID principles
 * Single Responsibility: Only handles HTTP requests/responses
 * Dependencies are injected through services
 */

/**
 * Create or update timesheet
 */
const settimesheet = ErrorHandler.asyncWrapper(async (req, res) => {
  const {
    project,
    task,
    member,
    startDate,
    endDate,
    hoursWorked,
    billableHours,
    hourlyRate,
    description,
    status,
    createdBy,
    edit,
  } = req.body;

  const timesheetData = {
    project,
    task,
    member,
    startDate,
    endDate,
    hoursWorked,
    billableHours,
    hourlyRate,
    description,
    status: status || 'draft',
    createdBy: createdBy || 'system',
  };

  // Validate input
  const validationErrors = TimesheetValidator.validateTimesheet(timesheetData);
  if (validationErrors.length > 0) {
    return ApiResponse.validationError(res, validationErrors);
  }

  // Create timesheet service instance
  const timesheetService = new TimesheetService();

  // Create or update timesheet
  const result = await timesheetService.createOrUpdateTimesheet(timesheetData, edit);

  return ApiResponse.success(res, result.data, result.message);
});

/**
 * Get timesheets (optionally filtered)
 */
const gettimesheet = ErrorHandler.asyncWrapper(async (req, res) => {
  const { uid, project, task, member, status, startDate, endDate } = req.query;

  // Validate filter parameters
  const validationErrors = TimesheetValidator.validateSearchParams({
    status,
    member,
    project,
    task,
    startDate,
    endDate,
  });
  if (validationErrors.length > 0) {
    return ApiResponse.validationError(res, validationErrors);
  }

  // Create timesheet service instance
  const timesheetService = new TimesheetService();

  // Build filter object
  const filters = {};
  if (uid) filters.project = uid; // uid is used as project filter
  if (project) filters.project = project;
  if (task) filters.task = task;
  if (member) filters.member = member;
  if (status) filters.status = status;
  if (startDate) filters.startDate = startDate;
  if (endDate) filters.endDate = endDate;

  // Get timesheets with filters
  const result = await timesheetService.getAllTimesheets(filters);

  return ApiResponse.success(res, result.data, "Timesheets fetched successfully");
});

/**
 * Get timesheet for editing
 */
const edittimesheet = ErrorHandler.asyncWrapper(async (req, res) => {
  const { uid } = req.body;

  // Validate UID
  const validationErrors = TimesheetValidator.validateUID(uid);
  if (validationErrors.length > 0) {
    return ApiResponse.validationError(res, validationErrors);
  }

  // Create timesheet service instance with tenant DB
  const timesheetService = new TimesheetService(req.db);

  // Get timesheet
  const timesheet = await timesheetService.getTimesheetForEdit(uid);

  return ApiResponse.success(res, timesheet, "Timesheet data fetched successfully");
});

/**
 * Delete timesheet (soft delete)
 */
const deletetimesheet = ErrorHandler.asyncWrapper(async (req, res) => {
  const { uid } = req.body;

  // Validate UID
  const validationErrors = TimesheetValidator.validateUID(uid);
  if (validationErrors.length > 0) {
    return ApiResponse.validationError(res, validationErrors);
  }

  // Create timesheet service instance with tenant DB
  const timesheetService = new TimesheetService(req.db);

  // Delete timesheet
  const deletedTimesheet = await timesheetService.deleteTimesheet(uid);

  return ApiResponse.success(res, deletedTimesheet, "Timesheet deleted successfully");
});

/**
 * Get timesheet statistics
 */
const getTimesheetStats = ErrorHandler.asyncWrapper(async (req, res) => {
  const { projectUID, taskUID, member, status } = req.query;

  // Create timesheet service instance with tenant DB
  const timesheetService = new TimesheetService(req.db);

  // Build filters
  const filters = {};
  if (projectUID) filters.project = projectUID;
  if (taskUID) filters.task = taskUID;
  if (member) filters.member = new RegExp(member, 'i');
  if (status) filters.status = status;

  // Get statistics
  const stats = await timesheetService.getTimesheetStats(filters);

  return ApiResponse.success(
    res,
    stats,
    "Timesheet statistics fetched successfully"
  );
});

/**
 * Submit timesheet for approval
 */
const submitTimesheet = ErrorHandler.asyncWrapper(async (req, res) => {
  const { uid } = req.body;

  // Validate UID
  const validationErrors = TimesheetValidator.validateUID(uid);
  if (validationErrors.length > 0) {
    return ApiResponse.validationError(res, validationErrors);
  }

  // Create timesheet service instance with tenant DB
  const timesheetService = new TimesheetService(req.db);

  // Submit timesheet
  await timesheetService.submitTimesheet(uid);

  return ApiResponse.success(res, null, "Timesheet submitted successfully");
});

/**
 * Approve or reject timesheet
 */
const approveTimesheet = ErrorHandler.asyncWrapper(async (req, res) => {
  const { uid, action, approvedBy, rejectionReason } = req.body;

  // Validate approval data
  const validationErrors = TimesheetValidator.validateApproval({
    uid,
    approvedBy,
    action,
    rejectionReason,
  });
  if (validationErrors.length > 0) {
    return ApiResponse.validationError(res, validationErrors);
  }

  // Create timesheet service instance with tenant DB
  const timesheetService = new TimesheetService(req.db);

  let result;
  if (action === 'approve') {
    result = await timesheetService.approveTimesheet(uid, approvedBy);
  } else {
    result = await timesheetService.rejectTimesheet(uid, approvedBy, rejectionReason);
  }

  const message = action === 'approve' 
    ? "Timesheet approved successfully" 
    : "Timesheet rejected successfully";

  return ApiResponse.success(res, result, message);
});

/**
 * Get timesheet summary for date range
 */
const getTimesheetSummary = ErrorHandler.asyncWrapper(async (req, res) => {
  const { startDate, endDate, project, member } = req.query;

  // Validate date range
  const validationErrors = TimesheetValidator.validateDateRange({
    startDate,
    endDate,
  });
  if (validationErrors.length > 0) {
    return ApiResponse.validationError(res, validationErrors);
  }

  // Create timesheet service instance with tenant DB
  const timesheetService = new TimesheetService(req.db);

  // Build additional filters
  const filters = {};
  if (project) filters.project = project;
  if (member) filters.member = new RegExp(member, 'i');

  // Get summary
  const summary = await timesheetService.getTimesheetSummary(
    startDate,
    endDate,
    filters
  );

  return ApiResponse.success(res, summary, "Timesheet summary fetched successfully");
});

/**
 * Get timesheets by project
 */
const getTimesheetsByProject = ErrorHandler.asyncWrapper(async (req, res) => {
  const { projectUID } = req.params;

  // Validate project UID
  const validationErrors = TimesheetValidator.validateUID(projectUID);
  if (validationErrors.length > 0) {
    return ApiResponse.validationError(res, validationErrors);
  }

  // Create timesheet service instance with tenant DB
  const timesheetService = new TimesheetService(req.db);

  // Get timesheets
  const timesheets = await timesheetService.getTimesheetsByProject(projectUID);

  return ApiResponse.success(res, timesheets, "Project timesheets fetched successfully");
});

/**
 * Get timesheets by task
 */
const getTimesheetsByTask = ErrorHandler.asyncWrapper(async (req, res) => {
  const { taskUID } = req.params;

  // Validate task UID
  const validationErrors = TimesheetValidator.validateUID(taskUID);
  if (validationErrors.length > 0) {
    return ApiResponse.validationError(res, validationErrors);
  }

  // Create timesheet service instance with tenant DB
  const timesheetService = new TimesheetService(req.db);

  // Get timesheets
  const timesheets = await timesheetService.getTimesheetsByTask(taskUID);

  return ApiResponse.success(res, timesheets, "Task timesheets fetched successfully");
});

/**
 * Get timesheets by member
 */
const getTimesheetsByMember = ErrorHandler.asyncWrapper(async (req, res) => {
  const { member } = req.params;

  if (!member || member.trim().length < 2) {
    return ApiResponse.error(res, "Member name must be at least 2 characters long", 400);
  }

  // Create timesheet service instance with tenant DB
  const timesheetService = new TimesheetService(req.db);

  // Get timesheets
  const timesheets = await timesheetService.getTimesheetsByMember(member);

  return ApiResponse.success(res, timesheets, "Member timesheets fetched successfully");
});

module.exports = {
  settimesheet,
  gettimesheet,
  edittimesheet,
  deletetimesheet,
  getTimesheetStats,
  submitTimesheet,
  approveTimesheet,
  getTimesheetSummary,
  getTimesheetsByProject,
  getTimesheetsByTask,
  getTimesheetsByMember,
};
