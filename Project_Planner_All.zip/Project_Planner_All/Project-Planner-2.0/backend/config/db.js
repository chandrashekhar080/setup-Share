const mongoose = require("mongoose");
const AppConfig = require("./AppConfig");

/**
 * Database Service - Following SOLID principles
 * Single Responsibility: Handles database connections and monitoring
 */
class DatabaseService {
  constructor() {
    this.config = AppConfig;
    this.mongoStatus = {
      connected: false,
      message: "MongoDB not connected",
      lastConnected: null,
      connectionAttempts: 0
    };
    
    this.setupEventHandlers();
  }

  /**
   * Setup mongoose event handlers
   */
  setupEventHandlers() {
    // Connection successful
    mongoose.connection.on('connected', () => {
      this.mongoStatus.connected = true;
      this.mongoStatus.message = "MongoDB Connected: Connection successful!";
      this.mongoStatus.lastConnected = new Date();
      console.log("✅ MongoDB connection successful!");
    });

    // Connection error
    mongoose.connection.on('error', (err) => {
      this.mongoStatus.connected = false;
      this.mongoStatus.message = `MongoDB Error: ${err.message}`;
      console.error("❌ MongoDB connection error:", err.message);
    });

    // Connection disconnected
    mongoose.connection.on('disconnected', () => {
      this.mongoStatus.connected = false;
      this.mongoStatus.message = "MongoDB Disconnected";
      console.warn("⚠️ MongoDB disconnected");
    });

    // Application terminating
    process.on('SIGINT', () => {
      this.closeConnection()
        .then(() => {
          console.log('👋 MongoDB connection closed through app termination');
          process.exit(0);
        })
        .catch((err) => {
          console.error('❌ Error closing MongoDB connection:', err);
          process.exit(1);
        });
    });
  }

  /**
   * Connect to MongoDB
   * @param {string} mongoUri - MongoDB connection string (optional)
   * @returns {Promise<void>}
   */
  async connectDB(mongoUri = null) {
    try {
      const uri = mongoUri || this.config.database.uri;
      this.mongoStatus.connectionAttempts++;

      console.log("🔌 Connecting to MongoDB...");
      console.log(`📍 URI: ${uri.replace(/\/\/.*@/, '//***:***@')}`); // Hide credentials in logs

      const options = {
        ...this.config.database.options,
        serverSelectionTimeoutMS: 10000, // 10 seconds
        socketTimeoutMS: 45000, // 45 seconds
        maxPoolSize: 10, // Maintain up to 10 socket connections
        minPoolSize: 2, // Maintain a minimum of 2 socket connections
        maxIdleTimeMS: 30000, // Close connections after 30 seconds of inactivity
        bufferCommands: false, // Disable mongoose buffering
      };

      await mongoose.connect(uri, options);
      
      this.mongoStatus.connected = true;
      this.mongoStatus.message = "MongoDB Connected: Connection successful!";
      
      return mongoose.connection;
    } catch (err) {
      this.mongoStatus.connected = false;
      this.mongoStatus.message = `MongoDB Connection Failed: ${err.message}`;
      
      console.error("❌ MongoDB connection failed:", err.message);
      
      // Don't exit in development, but do in production
      if (this.config.isProduction()) {
        process.exit(1);
      }
      
      throw err;
    }
  }

  /**
   * Close database connection
   * @returns {Promise<void>}
   */
  async closeConnection() {
    try {
      await mongoose.connection.close();
      this.mongoStatus.connected = false;
      this.mongoStatus.message = "MongoDB connection closed";
      console.log("📴 MongoDB connection closed successfully");
    } catch (error) {
      console.error("❌ Error closing MongoDB connection:", error);
      throw error;
    }
  }

  /**
   * Check database connection health
   * @returns {Object} Connection health status
   */
  getConnectionHealth() {
    return {
      connected: this.mongoStatus.connected,
      readyState: mongoose.connection.readyState,
      readyStateText: this.getReadyStateText(mongoose.connection.readyState),
      host: mongoose.connection.host,
      port: mongoose.connection.port,
      name: mongoose.connection.name,
      lastConnected: this.mongoStatus.lastConnected,
      connectionAttempts: this.mongoStatus.connectionAttempts
    };
  }

  /**
   * Get human-readable ready state text
   * @param {number} readyState - Mongoose ready state number
   * @returns {string} Ready state description
   */
  getReadyStateText(readyState) {
    const states = {
      0: 'disconnected',
      1: 'connected',
      2: 'connecting',
      3: 'disconnecting'
    };
    return states[readyState] || 'unknown';
  }

  /**
   * Ping database to check connectivity
   * @returns {Promise<Object>} Ping result
   */
  async pingDatabase() {
    try {
      const startTime = Date.now();
      await mongoose.connection.db.admin().ping();
      const responseTime = Date.now() - startTime;
      
      return {
        success: true,
        responseTime,
        timestamp: new Date()
      };
    } catch (error) {
      return {
        success: false,
        error: error.message,
        timestamp: new Date()
      };
    }
  }

  /**
   * Get database statistics
   * @returns {Promise<Object>} Database statistics
   */
  async getDatabaseStats() {
    try {
      if (!this.mongoStatus.connected) {
        throw new Error('Database not connected');
      }

      const stats = await mongoose.connection.db.stats();
      return {
        success: true,
        data: {
          collections: stats.collections,
          dataSize: stats.dataSize,
          storageSize: stats.storageSize,
          indexes: stats.indexes,
          indexSize: stats.indexSize,
          objects: stats.objects
        },
        timestamp: new Date()
      };
    } catch (error) {
      return {
        success: false,
        error: error.message,
        timestamp: new Date()
      };
    }
  }
}

// Create singleton instance
const dbService = new DatabaseService();

// Export functions for backward compatibility
module.exports = {
  connectDB: (uri) => dbService.connectDB(uri),
  closeConnection: () => dbService.closeConnection(),
  mongoStatus: dbService.mongoStatus,
  getDatabaseHealth: () => dbService.getConnectionHealth(),
  pingDatabase: () => dbService.pingDatabase(),
  getDatabaseStats: () => dbService.getDatabaseStats(),
  DatabaseService: dbService
};
