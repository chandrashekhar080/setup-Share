require("dotenv").config();
const mongoose = require("mongoose");

const connections = {}; // Cache for existing DB connections

const connectdyDB = (mongoUri) => {
  if (connections[mongoUri]) {
    return connections[mongoUri]; // return existing connection
  }

  try {
    const newConnection = mongoose.createConnection(mongoUri);

    newConnection.on("connected", () => {
      console.log(`MongoDB connected to: ${mongoUri}`);
    });

    newConnection.on("error", (err) => {
      console.error(`MongoDB connection error (${mongoUri}):`, err.message);
    });

    connections[mongoUri] = newConnection;
    return newConnection;
  } catch (err) {
    console.error("MongoDB dynamic connection failed!", err.message);
    return null;
  }
};

module.exports = {
  connectdyDB,
};
