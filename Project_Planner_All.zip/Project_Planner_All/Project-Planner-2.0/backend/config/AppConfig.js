require("dotenv").config();

/**
 * Application Configuration - Centralized config management
 * Following Single Responsibility Principle
 */
class AppConfig {
  constructor() {
    this.validateRequiredEnvVars();
  }

  // Database Configuration
  get database() {
    return {
      // MongoDB configuration (legacy - keeping for reference)
      uri: process.env.MONGO_URI || "mongodb://127.0.0.1:27017/projectplanner",
      options: {
        // Modern MongoDB driver doesn't need these deprecated options
        // useNewUrlParser and useUnifiedTopology are default in v6+
      },
      // MySQL configuration
      mysql: {
        host: process.env.MYSQL_HOST || "localhost",
        port: parseInt(process.env.MYSQL_PORT) || 3306,
        user: process.env.MYSQL_USER || "root",
        password: process.env.MYSQL_PASSWORD || "",
        database: process.env.MYSQL_DATABASE || "projectplanner",
        charset: "utf8mb4",
        timezone: "+00:00",
      },
    };
  }

  // JWT Configuration
  get jwt() {
    return {
      secret: process.env.JWT_SECRET,
      verifySecret: process.env.JWT_SECRET_FOR_VERIFY,
      expiresIn: process.env.JWT_EXPIRES_IN || "2d",
      verifyExpiresIn: process.env.JWT_VERIFY_EXPIRES_IN || "15m",
    };
  }

  // Email Configuration
  get email() {
    return {
      host: process.env.EMAIL_HOST,
      port: parseInt(process.env.EMAIL_PORT) || 587,
      secure: process.env.EMAIL_SECURE === "true",
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASSWORD,
      },
      from: process.env.EMAIL_FROM,
      tls: {
        rejectUnauthorized: false,
      },
    };
  }

  // CORS Configuration
  get cors() {
    const allowedOrigins = process.env.ALLOWED_ORIGINS
      ? process.env.ALLOWED_ORIGINS.split(",")
      : ["http://localhost:3000", "http://localhost:5173"];

    return {
      origin:
        process.env.NODE_ENV === "development"
          ? allowedOrigins
          : allowedOrigins,
      methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
      credentials: true,
      optionsSuccessStatus: 200,
    };
  }

  // Server Configuration
  get server() {
    return {
      port: process.env.PORT || 5000,
      env: process.env.NODE_ENV || "development",
      requestLimit: process.env.REQUEST_LIMIT || "4mb",
    };
  }

  // File Upload Configuration
  get upload() {
    return {
      maxFileSize: parseInt(process.env.MAX_FILE_SIZE) || 5 * 1024 * 1024, // 5MB
      allowedTypes: process.env.ALLOWED_FILE_TYPES
        ? process.env.ALLOWED_FILE_TYPES.split(",")
        : ["image/jpeg", "image/png", "image/gif"],
      uploadDir: process.env.UPLOAD_DIR || "uploads/",
    };
  }

  // Security Configuration
  get security() {
    return {
      rateLimitWindowMs:
        parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000, // 15 minutes
      rateLimitMax: parseInt(process.env.RATE_LIMIT_MAX) || 100, // limit each IP to 100 requests per windowMs
      bcryptRounds: parseInt(process.env.BCRYPT_ROUNDS) || 10,
    };
  }

  // OTP Configuration
  get otp() {
    return {
      length: parseInt(process.env.OTP_LENGTH) || 6,
      expiryMinutes: parseInt(process.env.OTP_EXPIRY_MINUTES) || 15,
      maxAttempts: parseInt(process.env.OTP_MAX_ATTEMPTS) || 3,
    };
  }

  // Logging Configuration
  get logging() {
    return {
      level: process.env.LOG_LEVEL || "info",
      file: process.env.LOG_FILE || "app.log",
      maxFileSize: process.env.LOG_MAX_FILE_SIZE || "10MB",
      maxFiles: parseInt(process.env.LOG_MAX_FILES) || 5,
    };
  }

  /**
   * Validate required environment variables
   */
  validateRequiredEnvVars() {
    const required = [
      "JWT_SECRET",
      "JWT_SECRET_FOR_VERIFY",
      "EMAIL_HOST",
      "EMAIL_USER",
      "EMAIL_PASSWORD",
      "EMAIL_FROM",
    ];

    const missing = required.filter((key) => !process.env[key]);

    if (missing.length > 0) {
      throw new Error(
        `Missing required environment variables: ${missing.join(", ")}`
      );
    }
  }

  /**
   * Get environment-specific configuration
   */
  getEnvironmentConfig() {
    const env = this.server.env;

    const configs = {
      development: {
        enableDetailedErrors: true,
        enableLogging: true,
        enableDebug: true,
      },
      production: {
        enableDetailedErrors: false,
        enableLogging: true,
        enableDebug: false,
      },
      test: {
        enableDetailedErrors: true,
        enableLogging: false,
        enableDebug: false,
      },
    };

    return configs[env] || configs.development;
  }

  /**
   * Check if we're in development mode
   */
  isDevelopment() {
    return this.server.env === "development";
  }

  /**
   * Check if we're in production mode
   */
  isProduction() {
    return this.server.env === "production";
  }

  /**
   * Check if we're in test mode
   */
  isTest() {
    return this.server.env === "test";
  }
}

module.exports = new AppConfig();
