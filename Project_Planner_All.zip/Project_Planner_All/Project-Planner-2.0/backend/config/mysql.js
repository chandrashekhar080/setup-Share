const mysql = require("mysql2/promise");
const AppConfig = require("./AppConfig");

/**
 * MySQL Database Service - Following SOLID principles
 * Single Responsibility: Handles MySQL connections and monitoring
 */
class MySQLService {
  constructor() {
    this.config = AppConfig;
    this.mysqlStatus = {
      connected: false,
      message: "MySQL not connected",
      lastConnected: null,
      connectionAttempts: 0,
    };

    this.mainConnection = null;
  }

  /**
   * Connect to MySQL main database using connection pool
   * @param {Object} config - MySQL connection config
   * @returns {Promise<Object>} MySQL connection pool
   */
  async connectDB(config = null) {
    try {
      // Return existing pool if available
      if (this.mainConnection) {
        return this.mainConnection;
      }

      const connectionConfig = config || this.config.database.mysql;
      this.mysqlStatus.connectionAttempts++;

      console.log("🔌 Creating MySQL connection pool...");
      console.log(`📍 Host: ${connectionConfig.host}:${connectionConfig.port}`);

      // Create connection pool instead of single connection
      this.mainConnection = mysql.createPool({
        host: connectionConfig.host,
        port: connectionConfig.port,
        user: connectionConfig.user,
        password: connectionConfig.password,
        database: connectionConfig.database,
        charset: "utf8mb4",
        timezone: "+00:00",
        acquireTimeout: 60000,
        timeout: 60000,
        reconnect: true,
        // Pool configuration
        connectionLimit: 10, // Maximum number of connections
        queueLimit: 0, // No limit on queued connection requests
        idleTimeout: 300000, // 5 minutes
        acquireTimeout: 60000, // 1 minute
        createDatabaseTable: true,
        multipleStatements: false,
      });

      // Test the pool connection
      const testConnection = await this.mainConnection.getConnection();
      await testConnection.ping();
      testConnection.release(); // Important: release the test connection back to pool

      this.mysqlStatus.connected = true;
      this.mysqlStatus.message = "MySQL Pool Connected: Connection pool created successfully!";
      this.mysqlStatus.lastConnected = new Date();

      console.log("✅ MySQL connection pool created successfully!");

      return this.mainConnection;
    } catch (err) {
      this.mysqlStatus.connected = false;
      this.mysqlStatus.message = `MySQL Connection Failed: ${err.message}`;

      console.error("❌ MySQL connection pool creation failed:", err.message);

      // Don't exit in development, but do in production
      if (this.config.isProduction()) {
        process.exit(1);
      }

      throw err;
    }
  }

  /**
   * Close database connection pool
   * @returns {Promise<void>}
   */
  async closeConnection() {
    try {
      if (this.mainConnection) {
        await this.mainConnection.end();
        this.mainConnection = null;
        this.mysqlStatus.connected = false;
        this.mysqlStatus.message = "MySQL connection pool closed";
        console.log("📴 MySQL connection pool closed successfully");
      }
    } catch (error) {
      console.error("❌ Error closing MySQL connection pool:", error);
      throw error;
    }
  }

  /**
   * Check database connection health
   * @returns {Object} Connection health status
   */
  getConnectionHealth() {
    return {
      connected: this.mysqlStatus.connected,
      message: this.mysqlStatus.message,
      lastConnected: this.mysqlStatus.lastConnected,
      connectionAttempts: this.mysqlStatus.connectionAttempts,
    };
  }

  /**
   * Ping database to check connectivity
   * @returns {Promise<Object>} Ping result
   */
  async pingDatabase() {
    try {
      if (!this.mainConnection) {
        throw new Error("No active connection pool");
      }

      const startTime = Date.now();
      const connection = await this.mainConnection.getConnection();
      await connection.ping();
      connection.release(); // Release connection back to pool
      const responseTime = Date.now() - startTime;

      return {
        success: true,
        responseTime,
        timestamp: new Date(),
      };
    } catch (error) {
      return {
        success: false,
        error: error.message,
        timestamp: new Date(),
      };
    }
  }
}

// Create singleton instance
const mysqlService = new MySQLService();

// Export functions for backward compatibility
module.exports = {
  connectDB: (config) => mysqlService.connectDB(config),
  closeConnection: () => mysqlService.closeConnection(),
  getConnection: () => mysqlService.mainConnection,
  mysqlStatus: mysqlService.mysqlStatus,
  getDatabaseHealth: () => mysqlService.getConnectionHealth(),
  pingDatabase: () => mysqlService.pingDatabase(),
  MySQLService: mysqlService,
};
