const mysql = require("mysql2/promise");
const AppConfig = require("./AppConfig");

const connections = {}; // Cache for existing DB connections

/**
 * Create dynamic MySQL connection for multi-tenant architecture
 * @param {string} dbName - Database name (tenant-specific)
 * @returns {Promise<Object>} MySQL connection
 */
const connectdyDB = async (dbName) => {
  // Use dbName as cache key
  const cacheKey = dbName;

  if (connections[cacheKey]) {
    try {
      // Test if connection is still alive
      await connections[cacheKey].ping();
      return connections[cacheKey]; // return existing connection
    } catch (error) {
      // Connection is dead, remove from cache
      console.warn(`MySQL connection for ${dbName} is dead, creating new one`);
      delete connections[cacheKey];
    }
  }

  try {
    const connectionConfig = {
      host: AppConfig.database.mysql.host,
      port: AppConfig.database.mysql.port,
      user: AppConfig.database.mysql.user,
      password: AppConfig.database.mysql.password,
      database: dbName, // Dynamic database name
      charset: "utf8mb4",
      timezone: "+00:00",
      acquireTimeout: 60000,
      timeout: 60000,
      reconnect: true,
      multipleStatements: true,
    };

    const newConnection = await mysql.createConnection(connectionConfig);

    // Test connection
    await newConnection.ping();

    console.log(`✅ MySQL connected to database: ${dbName}`);

    // Add connection event handlers
    newConnection.on("error", (err) => {
      console.error(`❌ MySQL connection error (${dbName}):`, err.message);
      // Remove from cache if connection fails
      if (connections[cacheKey]) {
        delete connections[cacheKey];
      }
    });

    connections[cacheKey] = newConnection;
    return newConnection;
  } catch (err) {
    console.error(
      `❌ MySQL dynamic connection failed for ${dbName}:`,
      err.message
    );
    throw new Error(`Failed to connect to database: ${dbName}`);
  }
};

/**
 * Close all dynamic connections
 * @returns {Promise<void>}
 */
const closeAllConnections = async () => {
  const closePromises = Object.keys(connections).map(async (key) => {
    try {
      await connections[key].end();
      console.log(`📴 Closed MySQL connection for: ${key}`);
    } catch (error) {
      console.error(`❌ Error closing connection for ${key}:`, error.message);
    }
  });

  await Promise.all(closePromises);

  // Clear connections cache
  Object.keys(connections).forEach((key) => delete connections[key]);
};

/**
 * Get connection statistics
 * @returns {Object} Connection statistics
 */
const getConnectionStats = () => {
  return {
    totalConnections: Object.keys(connections).length,
    databases: Object.keys(connections),
    timestamp: new Date(),
  };
};

// Graceful shutdown handler
process.on("SIGINT", async () => {
  console.log("\n🔄 Closing all MySQL connections...");
  await closeAllConnections();
});

process.on("SIGTERM", async () => {
  console.log("\n🔄 Closing all MySQL connections...");
  await closeAllConnections();
});

module.exports = {
  connectdyDB,
  closeAllConnections,
  getConnectionStats,
};
