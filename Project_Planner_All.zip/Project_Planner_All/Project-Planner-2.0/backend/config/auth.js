const jwt = require("jsonwebtoken");
const { connectdyDB } = require("../config/dynamicmysql");
const AppConfig = require("./AppConfig");
const ApiResponse = require("../utils/ApiResponse");

/**
 * Authentication Service - Following SOLID principles
 * Single Responsibility: Handles JWT operations and authentication middleware
 */
class AuthService {
  constructor() {
    this.config = AppConfig;
  }

  /**
   * Generate JWT token for user signin
   * @param {Object} user - User object
   * @param {string} tokenType - Type of token ('access' or 'refresh')
   * @returns {string} JWT token
   */
  signInToken(user, tokenType = "access") {
    const payload = {
      _id: user._id,
      uid: user.uid,
      name: user.name,
      email: user.email,
      subdomain: user.subdomain,
      role: user.role || "user",
      type: tokenType,
    };

    const secret =
      tokenType === "refresh"
        ? this.config.jwt.verifySecret
        : this.config.jwt.secret;

    const expiresIn =
      tokenType === "refresh" ? "7d" : this.config.jwt.expiresIn;

    return jwt.sign(payload, secret, { expiresIn });
  }

  /**
   * Generate verification token (for email verification, password reset)
   * @param {Object} user - User object
   * @param {string} purpose - Purpose of the token
   * @returns {string} JWT token
   */
  tokenForVerify(user, purpose = "email_verification") {
    const payload = {
      uid: user.uid,
      name: user.name,
      email: user.email,
      subdomain: user.subdomain,
      purpose,
    };

    return jwt.sign(payload, this.config.jwt.verifySecret, {
      expiresIn: this.config.jwt.verifyExpiresIn,
    });
  }

  /**
   * Verify JWT token
   * @param {string} token - JWT token to verify
   * @param {string} tokenType - Type of token ('access' or 'refresh')
   * @returns {Object} Decoded token payload
   */
  verifyToken(token, tokenType = "access") {
    const secret =
      tokenType === "refresh"
        ? this.config.jwt.verifySecret
        : this.config.jwt.secret;

    return jwt.verify(token, secret);
  }

  /**
   * Extract token from authorization header
   * @param {string} authorization - Authorization header value
   * @returns {string|null} Extracted token
   */
  extractToken(authorization) {
    if (!authorization || !authorization.startsWith("Bearer ")) {
      return null;
    }
    return authorization.split(" ")[1];
  }

  /**
   * Check if user has required role
   * @param {Object} user - User object from token
   * @param {string|Array} requiredRoles - Required role(s)
   * @returns {boolean} True if user has required role
   */
  hasRole(user, requiredRoles) {
    if (!user.role) return false;

    const roles = Array.isArray(requiredRoles)
      ? requiredRoles
      : [requiredRoles];
    return roles.includes(user.role);
  }

  /**
   * Get tenant database connection from user context
   * @param {Object} user - User object from token
   * @returns {Promise<Object>} Database connection
   */
  async getTenantDB(user) {
    const dbName = user.subdomain || "projectplanner";
    return await connectdyDB(dbName);
  }

  /**
   * Authentication middleware
   */
  isAuth = async (req, res, next) => {
    try {
      const { authorization } = req.headers;
      const token = this.extractToken(authorization);

      if (!token) {
        return ApiResponse.unauthorized(res, "No token provided");
      }

      // Verify token
      const decoded = this.verifyToken(token);

      // Check if token is expired
      if (decoded.exp * 1000 < Date.now()) {
        return ApiResponse.unauthorized(res, "Token has expired");
      }

      // Attach user info to request
      req.user = decoded;

      // Get and attach tenant database connection
      try {
        const dbConnection = await this.getTenantDB(decoded);
        req.db = dbConnection;
      } catch (dbError) {
        console.error("Database connection error:", dbError);
        return ApiResponse.serverError(res, "Database connection failed");
      }

      next();
    } catch (err) {
      console.error("Authentication error:", err);

      let message = "Invalid token";
      if (err.name === "TokenExpiredError") {
        message = "Token has expired";
      } else if (err.name === "JsonWebTokenError") {
        message = "Invalid token format";
      }

      return ApiResponse.unauthorized(res, message);
    }
  };

  /**
   * Admin authentication middleware
   */
  isAdmin = async (req, res, next) => {
    try {
      // First check if user is authenticated
      await new Promise((resolve, reject) => {
        this.isAuth(req, res, (err) => {
          if (err) reject(err);
          else resolve();
        });
      });

      // Check if user has admin role
      if (!this.hasRole(req.user, ["admin", "superadmin"])) {
        return ApiResponse.forbidden(res, "Admin access required");
      }

      next();
    } catch (error) {
      // Error already handled by isAuth middleware
      return;
    }
  };

  /**
   * Optional authentication middleware (sets user if token is provided)
   */
  optionalAuth = async (req, res, next) => {
    try {
      const { authorization } = req.headers;
      const token = this.extractToken(authorization);

      if (token) {
        try {
          const decoded = this.verifyToken(token);

          if (decoded.exp * 1000 > Date.now()) {
            req.user = decoded;

            // Try to get tenant DB connection
            try {
              const dbConnection = await this.getTenantDB(decoded);
              req.db = dbConnection;
            } catch (dbError) {
              console.warn(
                "Optional auth DB connection failed:",
                dbError.message
              );
            }
          }
        } catch (tokenError) {
          console.warn(
            "Optional auth token verification failed:",
            tokenError.message
          );
        }
      }

      next();
    } catch (error) {
      console.error("Optional auth error:", error);
      next(); // Continue even if optional auth fails
    }
  };
}

// Export singleton instance
const authService = new AuthService();

module.exports = {
  signInToken: (user, tokenType) => authService.signInToken(user, tokenType),
  tokenForVerify: (user, purpose) => authService.tokenForVerify(user, purpose),
  isAuth: authService.isAuth,
  isAdmin: authService.isAdmin,
  optionalAuth: authService.optionalAuth,
  verifyToken: (token, tokenType) => authService.verifyToken(token, tokenType),
  hasRole: (user, roles) => authService.hasRole(user, roles),
  AuthService: authService,
};
