const BaseService = require('./BaseService');
const Admin = require('../models/AdminModel');
const bcrypt = require('bcrypt');

/**
 * AdminService - Handles all admin-related business logic
 * Following Single Responsibility Principle
 */
class AdminService extends BaseService {
  constructor() {
    super(Admin);
  }

  /**
   * Create admin with hashed password
   * @param {Object} adminData - Admin data
   * @returns {Promise<Object>} Created admin
   */
  async createAdmin(adminData) {
    const { password, ...otherData } = adminData;
    const hashedPassword = await bcrypt.hash(password, 10);
    return await this.create({ ...otherData, password: hashedPassword });
  }

  /**
   * Authenticate admin by email and password
   * @param {string} email - Admin email
   * @param {string} password - Admin password
   * @returns {Promise<Object|null>} Admin if authenticated, null otherwise
   */
  async authenticateAdmin(email, password) {
    const admin = await Admin.findOne({ email });
    if (!admin) return null;

    const isValidPassword = await bcrypt.compare(password, admin.password);
    return isValidPassword ? admin : null;
  }

  /**
   * Find admin by email
   * @param {string} email - Admin email
   * @returns {Promise<Object|null>} Admin if found
   */
  async findByEmail(email) {
    return await Admin.findOne({ email });
  }

  /**
   * Delete all admins (for development/testing)
   * @returns {Promise<Object>} Delete result
   */
  async deleteAll() {
    return await Admin.deleteMany({});
  }

  /**
   * Check if admin exists
   * @param {string} email - Admin email
   * @returns {Promise<boolean>} True if exists
   */
  async adminExists(email) {
    return await this.exists({ email });
  }

  /**
   * Update admin password
   * @param {string} email - Admin email
   * @param {string} newPassword - New password
   * @returns {Promise<Object>} Update result
   */
  async updatePassword(email, newPassword) {
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    return await Admin.updateOne(
      { email }, 
      { $set: { password: hashedPassword } }
    );
  }
}

module.exports = new AdminService();