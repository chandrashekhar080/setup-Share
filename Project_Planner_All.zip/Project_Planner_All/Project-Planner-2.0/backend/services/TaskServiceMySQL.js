const { getConnection } = require('../config/mysql');
const TaskModel = require('../models/taskModelMySQL');

/**
 * Task Service - Business logic for task operations
 * Uses MySQL instead of MongoDB for better compatibility
 */
class TaskService {
  constructor() {
    this.connection = null;
    this.model = null;
  }

  async initialize() {
    if (!this.connection) {
      this.connection = await getConnection();
      this.model = new TaskModel(this.connection);
      await this.model.createTable();
    }
  }

  /**
   * Create or update task
   * @param {Object} taskData - Task data
   * @param {string} editUID - UID for editing (optional)
   * @returns {Promise<Object>} Operation result
   */
  async createOrUpdateTask(taskData, editUID = null) {
    await this.initialize();
    
    const { taskname, project } = taskData;

    // Validation
    if (!taskname || !project) {
      throw new Error('Task name and project are required');
    }

    if (editUID) {
      return await this.updateTask(editUID, taskData);
    } else {
      return await this.createTask(taskData);
    }
  }

  /**
   * Create new task
   * @param {Object} taskData - Task data
   * @returns {Promise<Object>} Created task
   */
  async createTask(taskData) {
    await this.initialize();
    
    try {
      const task = await this.model.create(taskData);
      return {
        success: true,
        data: task,
        message: 'Task created successfully'
      };
    } catch (error) {
      throw new Error(`Failed to create task: ${error.message}`);
    }
  }

  /**
   * Update existing task
   * @param {string} uid - Task UID
   * @param {Object} updateData - Update data
   * @returns {Promise<Object>} Updated task
   */
  async updateTask(uid, updateData) {
    await this.initialize();
    
    try {
      const task = await this.model.findOneAndUpdate({ uid }, updateData);
      return {
        success: true,
        data: task,
        message: 'Task updated successfully'
      };
    } catch (error) {
      throw new Error(`Failed to update task: ${error.message}`);
    }
  }

  /**
   * Get all tasks with optional filters
   * @param {Object} filters - Search filters
   * @returns {Promise<Array>} Tasks array
   */
  async getAllTasks(filters = {}) {
    await this.initialize();
    
    try {
      const tasks = await this.model.find(filters);
      return {
        success: true,
        data: tasks,
        count: tasks.length
      };
    } catch (error) {
      throw new Error(`Failed to get tasks: ${error.message}`);
    }
  }

  /**
   * Get task by UID
   * @param {string} uid - Task UID
   * @returns {Promise<Object>} Task object
   */
  async getTaskByUID(uid) {
    await this.initialize();
    
    try {
      const task = await this.model.findOne({ uid });
      if (!task) {
        throw new Error('Task not found');
      }
      return {
        success: true,
        data: task
      };
    } catch (error) {
      throw new Error(`Failed to get task: ${error.message}`);
    }
  }

  /**
   * Delete task (soft delete)
   * @param {string} uid - Task UID
   * @returns {Promise<Object>} Delete result
   */
  async deleteTask(uid) {
    await this.initialize();
    
    try {
      const result = await this.model.findOneAndDelete({ uid });
      return {
        success: true,
        data: result,
        message: 'Task deleted successfully'
      };
    } catch (error) {
      throw new Error(`Failed to delete task: ${error.message}`);
    }
  }

  /**
   * Get task statistics
   * @returns {Promise<Object>} Task statistics
   */
  async getTaskStats() {
    await this.initialize();
    
    try {
      const stats = await this.model.getStats();
      return {
        success: true,
        data: stats
      };
    } catch (error) {
      throw new Error(`Failed to get task stats: ${error.message}`);
    }
  }

  /**
   * Update task progress
   * @param {string} uid - Task UID
   * @param {number} progress - Progress percentage (0-100)
   * @returns {Promise<Object>} Updated task
   */
  async updateTaskProgress(uid, progress) {
    await this.initialize();
    
    if (progress < 0 || progress > 100) {
      throw new Error('Progress must be between 0 and 100');
    }

    try {
      const task = await this.model.findOneAndUpdate({ uid }, { progress });
      return {
        success: true,
        data: task,
        message: 'Task progress updated successfully'
      };
    } catch (error) {
      throw new Error(`Failed to update task progress: ${error.message}`);
    }
  }

  /**
   * Search tasks
   * @param {string} query - Search query
   * @param {Object} filters - Additional filters
   * @returns {Promise<Array>} Search results
   */
  async searchTasks(query, filters = {}) {
    await this.initialize();
    
    try {
      const searchFilters = { ...filters, q: query };
      const tasks = await this.model.find(searchFilters);
      return {
        success: true,
        data: tasks,
        count: tasks.length
      };
    } catch (error) {
      throw new Error(`Failed to search tasks: ${error.message}`);
    }
  }
}

module.exports = TaskService;