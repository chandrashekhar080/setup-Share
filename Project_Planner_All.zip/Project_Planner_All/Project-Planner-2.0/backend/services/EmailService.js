const nodemailer = require('nodemailer');
require('dotenv').config();

/**
 * EmailService - Handles all email-related operations
 * Following Single Responsibility Principle
 */
class EmailService {
  constructor() {
    this.transporter = this.createTransporter();
  }

  /**
   * Create email transporter
   * @returns {Object} Nodemailer transporter
   */
  createTransporter() {
    // Check if email configuration is available
    if (!process.env.EMAIL_HOST || !process.env.EMAIL_USER) {
      console.warn('⚠️ Email configuration missing. Email functionality will be disabled.');
      return null;
    }

    try {
      return nodemailer.createTransport({
        host: process.env.EMAIL_HOST, 
        port: parseInt(process.env.EMAIL_PORT) || 587, 
        secure: process.env.EMAIL_SECURE === 'true',
        auth: {
          user: process.env.EMAIL_USER, 
          pass: process.env.EMAIL_PASSWORD
        },
        tls: {
          rejectUnauthorized: false 
        }
      });
    } catch (error) {
      console.error('❌ Failed to create email transporter:', error.message);
      return null;
    }
  }

  /**
   * Send welcome email to new user
   * @param {string} email - Recipient email
   * @returns {Promise<Object>} Send result
   */
  async sendWelcomeEmail(email) {
    if (!this.transporter) {
      console.warn('⚠️ Email not configured. Skipping welcome email.');
      return { success: false, message: 'Email service not configured' };
    }

    if (!this.isValidEmail(email)) {
      throw new Error('Invalid email address');
    }

    const mailOptions = {
      from: process.env.EMAIL_FROM || 'noreply@projectplanner.com',
      to: email,
      subject: 'Welcome to Our App!',
      html: this.getWelcomeEmailTemplate(email)
    };

    try {
      const result = await this.transporter.sendMail(mailOptions);
      console.log('✅ Welcome email sent successfully to:', email);
      return { success: true, messageId: result.messageId };
    } catch (error) {
      console.error('❌ Failed to send welcome email:', error.message);
      throw error;
    }
  }

  /**
   * Send OTP email
   * @param {string} email - Recipient email
   * @param {string} otp - OTP code
   * @returns {Promise<Object>} Send result
   */
  async sendOTPEmail(email, otp) {
    if (!this.transporter) {
      console.warn('⚠️ Email not configured. Skipping OTP email.');
      return { success: false, message: 'Email service not configured' };
    }

    if (!this.isValidEmail(email)) {
      throw new Error('Invalid email address');
    }

    const mailOptions = {
      from: process.env.EMAIL_FROM || 'noreply@projectplanner.com',
      to: email,
      subject: 'Your OTP Code',
      html: this.getOTPEmailTemplate(otp)
    };

    try {
      const result = await this.transporter.sendMail(mailOptions);
      console.log('✅ OTP email sent successfully to:', email);
      return { success: true, messageId: result.messageId };
    } catch (error) {
      console.error('❌ Failed to send OTP email:', error.message);
      throw error;
    }
  }

  /**
   * Validate email format
   * @param {string} email - Email to validate
   * @returns {boolean} True if valid
   */
  isValidEmail(email) {
    return email && /^\S+@\S+\.\S+$/.test(email);
  }

  /**
   * Get welcome email HTML template
   * @param {string} email - User email
   * @returns {string} HTML template
   */
  getWelcomeEmailTemplate(email) {
    return `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #333;">Welcome to Our Project Planner!</h2>
        <p>Hello!</p>
        <p>Your email <strong>${email}</strong> was successfully registered.</p>
        <p>You can now start using our project planning platform to manage your projects efficiently.</p>
        <br>
        <p>Best regards,<br>The Project Planner Team</p>
      </div>
    `;
  }

  /**
   * Get OTP email HTML template
   * @param {string} otp - OTP code
   * @returns {string} HTML template
   */
  getOTPEmailTemplate(otp) {
    return `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #333;">Your OTP Code</h2>
        <p>Your One-Time Password is:</p>
        <div style="font-size: 24px; font-weight: bold; color: #007bff; text-align: center; padding: 20px; background-color: #f8f9fa; border-radius: 5px;">
          ${otp}
        </div>
        <p><strong>Note:</strong> This OTP will expire in 15 minutes for security reasons.</p>
        <br>
        <p>Best regards,<br>The Project Planner Team</p>
      </div>
    `;
  }
}

module.exports = new EmailService();