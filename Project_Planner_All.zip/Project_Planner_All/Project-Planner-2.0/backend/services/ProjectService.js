const BaseService = require('./BaseService');

/**
 * ProjectService - Handles all project-related business logic
 * Following Single Responsibility Principle
 */
class ProjectService extends BaseService {
  constructor(tenantDB) {
    // For multi-tenant applications, we need to pass the tenant-specific model
    const projectModel = tenantDB 
      ? tenantDB.model("projects", require("../models/projectModel").schema)
      : require("../models/projectModel");
    
    super(projectModel);
  }

  /**
   * Create or update project
   * @param {Object} projectData - Project data
   * @param {string} editUID - UID for editing (optional)
   * @returns {Promise<Object>} Operation result
   */
  async createOrUpdateProject(projectData, editUID = null) {
    const { projectName, customer, ...otherData } = projectData;

    // Validation
    if (!projectName || !customer) {
      throw new Error('Project name and customer are required');
    }

    if (editUID) {
      return await this.updateProject(editUID, projectData);
    } else {
      return await this.createProject(projectData);
    }
  }

  /**
   * Create new project
   * @param {Object} projectData - Project data
   * @returns {Promise<Object>} Created project
   */
  async createProject(projectData) {
    const { projectName } = projectData;

    // Check if project name already exists
    const existingProject = await this.model.findOne({ projectName });
    if (existingProject) {
      throw new Error('This project name is already in use!');
    }

    return await this.create(projectData);
  }

  /**
   * Update existing project
   * @param {string} uid - Project UID
   * @param {Object} projectData - Updated project data
   * @returns {Promise<Object>} Update result
   */
  async updateProject(uid, projectData) {
    const existingProject = await this.findByUID(uid);
    if (!existingProject) {
      throw new Error('Project not found for editing');
    }

    return await this.updateByUID(uid, projectData);
  }

  /**
   * Get projects with optional filtering
   * @param {Object} filter - Filter criteria
   * @returns {Promise<Array>} Array of projects
   */
  async getProjects(filter = {}) {
    return await this.findAll(filter);
  }

  /**
   * Delete project by UID
   * @param {string} uid - Project UID
   * @returns {Promise<Object>} Deleted project
   */
  async deleteProject(uid) {
    if (!uid) {
      throw new Error('UID is required!');
    }

    const deleted = await this.deleteByUID(uid);
    if (!deleted) {
      throw new Error('Project not found or already deleted');
    }

    return deleted;
  }

  /**
   * Get project for editing
   * @param {string} uid - Project UID
   * @returns {Promise<Object>} Project data
   */
  async getProjectForEdit(uid) {
    if (!uid) {
      throw new Error('UID is required!');
    }

    const project = await this.findByUID(uid);
    if (!project) {
      throw new Error('This project is not available!');
    }

    return project;
  }
}

module.exports = ProjectService;