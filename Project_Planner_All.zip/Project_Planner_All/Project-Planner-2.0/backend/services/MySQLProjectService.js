const { MySQLService } = require("../config/mysql");

/**
 * MySQL Project Service - Handles all project-related database operations
 * Following Single Responsibility Principle
 */
class MySQLProjectService {
  constructor(db = null) {
    this.db = db;
  }

  /**
   * Get database connection from pool
   * @returns {Promise<Object>} Database connection from pool
   */
  async getConnection() {
    if (this.db) {
      return this.db;
    }
    const pool = await MySQLService.connectDB();
    return pool;
  }

  /**
   * Safely parse JSON string
   * @param {string} jsonString - JSON string to parse
   * @param {*} defaultValue - Default value if parsing fails
   * @returns {*} Parsed value or default
   */
  safeJSONParse(jsonString, defaultValue = null) {
    try {
      if (!jsonString || jsonString === 'null' || jsonString === 'undefined') {
        return defaultValue;
      }
      return JSON.parse(jsonString);
    } catch (error) {
      console.warn('JSON parse error:', error.message, 'for string:', jsonString);
      return defaultValue;
    }
  }

  /**
   * Generate unique UID
   * @returns {Promise<string>} Unique UID
   */
  async generateUID() {
    const db = await this.getConnection();
    let uid;
    let isUnique = false;
    
    while (!isUnique) {
      uid = Math.floor(1000000 + Math.random() * 9000000).toString();
      const [rows] = await db.execute('SELECT uid FROM projects WHERE uid = ?', [uid]);
      if (rows.length === 0) isUnique = true;
    }
    return uid;
  }

  /**
   * Create new project
   * @param {Object} projectData - Project data
   * @returns {Promise<Object>} Created project
   */
  async createProject(projectData) {
    const db = await this.getConnection();
    
    // Check if project name already exists
    const [existing] = await db.execute(
      'SELECT uid FROM projects WHERE projectName = ?',
      [projectData.projectName]
    );
    
    if (existing.length > 0) {
      throw new Error('This project name is already in use!');
    }

    // Generate UID
    const uid = projectData.uid || await this.generateUID();

    // Calculate duration if not provided
    let duration = projectData.duration;
    if (!duration && projectData.startDate && projectData.endDate) {
      const start = new Date(projectData.startDate);
      const end = new Date(projectData.endDate);
      duration = Math.ceil((end - start) / (1000 * 60 * 60 * 24));
    }

    // Prepare data for insertion
    const insertData = {
      uid,
      projectName: projectData.projectName,
      customer: projectData.customer,
      supervisor: projectData.supervisor || null,
      startDate: projectData.startDate,
      endDate: projectData.endDate,
      duration: duration || null,
      projectDetails: projectData.projectDetails || null,
      projectManager: projectData.projectManager,
      totalBudget: projectData.totalBudget || 0,
      allocatedFunds: projectData.allocatedFunds || 0,
      budgetNotes: projectData.budgetNotes || null,
      progress: projectData.progress || 0,
      milestone: projectData.milestone || null,
      followedByName: projectData.followedByName || null,
      priority: projectData.priority || 'medium',
      statusNotes: projectData.statusNotes || null,
      status: projectData.status || 'planning',
      team: projectData.team ? JSON.stringify(projectData.team) : null,
      tags: projectData.tags ? JSON.stringify(projectData.tags) : null,
      attachments: projectData.attachments ? JSON.stringify(projectData.attachments) : null,
      lastUpdatedBy: projectData.lastUpdatedBy || null
    };

    const query = `
      INSERT INTO projects (
        uid, projectName, customer, supervisor, startDate, endDate, duration,
        projectDetails, projectManager, totalBudget, allocatedFunds, budgetNotes,
        progress, milestone, followedByName, priority, statusNotes, status,
        team, tags, attachments, lastUpdatedBy, createdAt, updatedAt
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
    `;

    const values = [
      insertData.uid, insertData.projectName, insertData.customer, insertData.supervisor,
      insertData.startDate, insertData.endDate, insertData.duration, insertData.projectDetails,
      insertData.projectManager, insertData.totalBudget, insertData.allocatedFunds,
      insertData.budgetNotes, insertData.progress, insertData.milestone, insertData.followedByName,
      insertData.priority, insertData.statusNotes, insertData.status, insertData.team,
      insertData.tags, insertData.attachments, insertData.lastUpdatedBy
    ];

    await db.execute(query, values);

    // Return the created project
    return await this.getProjectByUID(uid);
  }

  /**
   * Get all projects with optional filtering
   * @param {Object} filter - Filter criteria
   * @returns {Promise<Array>} Array of projects
   */
  async getProjects(filter = {}) {
    const db = await this.getConnection();
    
    try {
      // Build query with filters
      let query = 'SELECT * FROM projects WHERE 1=1';
      const values = [];

      // Add filters
      if (filter.status) {
        query += ' AND status = ?';
        values.push(filter.status);
      }
      if (filter.priority) {
        query += ' AND priority = ?';
        values.push(filter.priority);
      }
      if (filter.customer) {
        query += ' AND customer LIKE ?';
        values.push(`%${filter.customer}%`);
      }
      if (filter.projectManager) {
        query += ' AND projectManager LIKE ?';
        values.push(`%${filter.projectManager}%`);
      }
      if (filter.q) {
        query += ' AND (projectName LIKE ? OR customer LIKE ? OR projectManager LIKE ? OR projectDetails LIKE ?)';
        const searchTerm = `%${filter.q}%`;
        values.push(searchTerm, searchTerm, searchTerm, searchTerm);
      }

      query += ' ORDER BY createdAt DESC';
      
      const result = await db.execute(query, values);
      
      if (!result || !Array.isArray(result) || result.length === 0) {
        return [];
      }
      
      const [rows] = result;
      if (!Array.isArray(rows)) {
        return [];
      }
      
      // Process each project
      return rows.map(project => ({
        ...project,
        // Convert string numbers to actual numbers
        totalBudget: parseFloat(project.totalBudget) || 0,
        allocatedFunds: parseFloat(project.allocatedFunds) || 0,
        progress: parseInt(project.progress) || 0,
        duration: parseInt(project.duration) || 0,
        // Parse JSON fields safely
        team: this.safeJSONParse(project.team, []),
        tags: this.safeJSONParse(project.tags, []),
        attachments: this.safeJSONParse(project.attachments, []),
        // Convert boolean
        isOverdue: false, // Simplified for now
        // Ensure null values become empty strings for optional fields
        supervisor: project.supervisor || '',
        projectDetails: project.projectDetails || '',
        budgetNotes: project.budgetNotes || '',
        milestone: project.milestone || '',
        followedByName: project.followedByName || '',
        statusNotes: project.statusNotes || '',
        lastUpdatedBy: project.lastUpdatedBy || '',
      }));
      
    } catch (error) {
      console.error('❌ Error in getProjects:', error.message);
      console.error('📊 Error stack:', error.stack);
      // Return empty array instead of throwing to prevent frontend crashes
      return [];
    }
  }

  /**
   * Get project by UID
   * @param {string} uid - Project UID
   * @returns {Promise<Object|null>} Project data
   */
  async getProjectByUID(uid) {
    console.log('🔍 getProjectByUID called for UID:', uid);
    const db = await this.getConnection();
    
    try {
      // Simple query to get project by UID
      const query = 'SELECT * FROM projects WHERE uid = ?';
      const result = await db.execute(query, [uid]);
      
      if (!result || !Array.isArray(result) || result.length === 0) {
        return null;
      }
      
      const [rows] = result;
      if (!Array.isArray(rows) || rows.length === 0) {
        return null;
      }

      const project = rows[0];
      return {
        ...project,
        // Convert string numbers to actual numbers
        totalBudget: parseFloat(project.totalBudget) || 0,
        allocatedFunds: parseFloat(project.allocatedFunds) || 0,
        progress: parseInt(project.progress) || 0,
        duration: parseInt(project.duration) || 0,
        // Parse JSON fields safely
        team: this.safeJSONParse(project.team, []),
        tags: this.safeJSONParse(project.tags, []),
        attachments: this.safeJSONParse(project.attachments, []),
        // Convert boolean
        isOverdue: false, // Simplified for now
        // Ensure null values become empty strings for optional fields
        supervisor: project.supervisor || '',
        projectDetails: project.projectDetails || '',
        budgetNotes: project.budgetNotes || '',
        milestone: project.milestone || '',
        followedByName: project.followedByName || '',
        statusNotes: project.statusNotes || '',
        lastUpdatedBy: project.lastUpdatedBy || '',
      };
      
    } catch (error) {
      console.error('❌ Error in getProjectByUID:', error.message);
      throw error;
    }
  }

  /**
   * Update project by UID
   * @param {string} uid - Project UID
   * @param {Object} projectData - Updated project data
   * @returns {Promise<Object>} Updated project
   */
  async updateProject(uid, projectData) {
    
    const db = await this.getConnection();
    
    // Simple existence check without using getProjectByUID to avoid potential issues
    const [existingRows] = await db.execute('SELECT uid, projectName FROM projects WHERE uid = ?', [uid]);
    if (existingRows.length === 0) {
      throw new Error('Project not found for editing');
    }

    // Check if project name is being changed and if it conflicts
    if (projectData.projectName && projectData.projectName !== existingRows[0].projectName) {
      console.log('🔍 Checking for project name conflicts...');
      const [existing] = await db.execute(
        'SELECT uid FROM projects WHERE projectName = ? AND uid != ?',
        [projectData.projectName, uid]
      );
      
      console.log('📊 Existing projects with same name:', existing ? existing.length : 'undefined');
      
      if (existing && existing.length > 0) {
        throw new Error('This project name is already in use!');
      }
    }

    // Calculate duration if dates are provided
    let duration = projectData.duration;
    try {
      if (!duration && projectData.startDate && projectData.endDate) {
        const start = new Date(projectData.startDate);
        const end = new Date(projectData.endDate);
        if (isNaN(start.getTime()) || isNaN(end.getTime())) {
          console.error('Invalid date format:', { startDate: projectData.startDate, endDate: projectData.endDate });
        } else {
          duration = Math.ceil((end - start) / (1000 * 60 * 60 * 24));
        }
      }
    } catch (error) {
      console.error('Error calculating duration:', error.message);
    }

    // Build update query dynamically
    const updateFields = [];
    const values = [];

    const fieldsToUpdate = [
      'projectName', 'customer', 'supervisor', 'startDate', 'endDate', 'duration',
      'projectDetails', 'projectManager', 'totalBudget', 'allocatedFunds', 'budgetNotes',
      'progress', 'milestone', 'followedByName', 'priority', 'statusNotes', 'status',
      'lastUpdatedBy'
    ];

    fieldsToUpdate.forEach(field => {
      if (projectData.hasOwnProperty(field)) {
        updateFields.push(`${field} = ?`);
        // Convert undefined to null for SQL compatibility
        const value = projectData[field] === undefined ? null : projectData[field];
        values.push(value);
      }
    });

    // Handle JSON fields
    try {
      if (projectData.team !== undefined) {
        updateFields.push('team = ?');
        values.push(JSON.stringify(projectData.team || []));
      }
      if (projectData.tags !== undefined) {
        updateFields.push('tags = ?');
        values.push(JSON.stringify(projectData.tags || []));
      }
      if (projectData.attachments !== undefined) {
        updateFields.push('attachments = ?');
        values.push(JSON.stringify(projectData.attachments || []));
      }
    } catch (error) {
      console.error('Error serializing JSON fields:', error.message);
      console.error('Team:', projectData.team);
      console.error('Tags:', projectData.tags);
      console.error('Attachments:', projectData.attachments);
      throw new Error('Invalid JSON data in team, tags, or attachments');
    }

    // Add duration if calculated
    if (duration) {
      updateFields.push('duration = ?');
      values.push(duration);
    }

    // Add updatedAt
    updateFields.push('updatedAt = NOW()');

    // Always allow updates even if only updatedAt (for tracking purposes)
    if (updateFields.length === 1) { // Only updatedAt
      console.log('⚠️ No fields to update except updatedAt');
    }

    console.log('📝 Update fields:', updateFields);
    console.log('📊 Values:', values);

    const query = `UPDATE projects SET ${updateFields.join(', ')} WHERE uid = ?`;
    values.push(uid); // Add uid at the end for WHERE clause
    
    try {
      console.log('Executing update query:', query);
      console.log('With values:', values);
      const [result] = await db.execute(query, values);
      console.log('Update successful, affected rows:', result.affectedRows);
    } catch (error) {
      console.error('Database update error:', error.message);
      console.error('Query:', query);
      console.error('Values:', values);
      throw error;
    }

    // Return updated project
    return await this.getProjectByUID(uid);
  }

  /**
   * Delete project by UID
   * @param {string} uid - Project UID
   * @returns {Promise<Object>} Deleted project data
   */
  async deleteProject(uid) {
    const db = await this.getConnection();
    
    // Get project data before deletion
    const project = await this.getProjectByUID(uid);
    if (!project) {
      throw new Error('Project not found or already deleted');
    }

    // Delete the project
    const [result] = await db.execute('DELETE FROM projects WHERE uid = ?', [uid]);
    
    if (result.affectedRows === 0) {
      throw new Error('Project not found or already deleted');
    }

    return project;
  }

  /**
   * Search projects
   * @param {string} searchTerm - Search term
   * @param {Object} additionalFilters - Additional filters
   * @returns {Promise<Array>} Array of matching projects
   */
  async searchProjects(searchTerm, additionalFilters = {}) {
    const db = await this.getConnection();
    
    let query = `
      SELECT *, 
        CASE 
          WHEN endDate < CURDATE() AND status NOT IN ('completed', 'cancelled') THEN 1 
          ELSE 0 
        END as isOverdue
      FROM projects 
      WHERE (
        projectName LIKE ? OR 
        customer LIKE ? OR 
        projectDetails LIKE ? OR 
        projectManager LIKE ?
      )
    `;
    
    const searchPattern = `%${searchTerm}%`;
    const values = [searchPattern, searchPattern, searchPattern, searchPattern];

    // Add additional filters
    if (additionalFilters.status) {
      query += ' AND status = ?';
      values.push(additionalFilters.status);
    }
    if (additionalFilters.priority) {
      query += ' AND priority = ?';
      values.push(additionalFilters.priority);
    }
    if (additionalFilters.customer) {
      query += ' AND customer LIKE ?';
      values.push(`%${additionalFilters.customer}%`);
    }

    query += ' ORDER BY createdAt DESC';

    const [rows] = await db.execute(query, values);
    
    // Parse JSON fields and ensure proper data types
    return rows.map(project => ({
      ...project,
      // Convert string numbers to actual numbers
      totalBudget: parseFloat(project.totalBudget) || 0,
      allocatedFunds: parseFloat(project.allocatedFunds) || 0,
      progress: parseInt(project.progress) || 0,
      duration: parseInt(project.duration) || 0,
      // Parse JSON fields
      team: project.team ? JSON.parse(project.team) : [],
      tags: project.tags ? JSON.parse(project.tags) : [],
      attachments: project.attachments ? JSON.parse(project.attachments) : [],
      // Convert boolean
      isOverdue: Boolean(project.isOverdue),
      // Ensure null values become empty strings for optional fields
      supervisor: project.supervisor || '',
      projectDetails: project.projectDetails || '',
      budgetNotes: project.budgetNotes || '',
      milestone: project.milestone || '',
      followedByName: project.followedByName || '',
      statusNotes: project.statusNotes || '',
      lastUpdatedBy: project.lastUpdatedBy || '',
    }));
  }

  /**
   * Get project statistics
   * @returns {Promise<Object>} Project statistics
   */
  async getProjectStats() {
    const db = await this.getConnection();
    
    const query = `
      SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'planning' THEN 1 ELSE 0 END) as planning,
        SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
        SUM(CASE WHEN status = 'on_hold' THEN 1 ELSE 0 END) as on_hold,
        SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled,
        SUM(totalBudget) as totalBudget,
        SUM(allocatedFunds) as allocatedFunds,
        AVG(progress) as averageProgress,
        SUM(CASE WHEN endDate < CURDATE() AND status NOT IN ('completed', 'cancelled') THEN 1 ELSE 0 END) as overdue
      FROM projects
    `;
    
    const [rows] = await db.execute(query);
    return rows[0];
  }
}

// Create singleton instance with connection pool
let projectServiceInstance = null;

const getProjectService = async () => {
  if (!projectServiceInstance) {
    const pool = await MySQLService.connectDB();
    projectServiceInstance = new MySQLProjectService(pool);
  }
  return projectServiceInstance;
};

module.exports = { MySQLProjectService, getProjectService };