const { connectdyDB } = require("../config/dynamicdb");
const UserService = require('./UserService');

/**
 * TenantService - Handles multi-tenant operations
 * Following Single Responsibility Principle
 */
class TenantService {
  /**
   * Check domain availability and setup tenant
   * @param {string} subdomain - Subdomain to check
   * @returns {Promise<Object>} Domain check result
   */
  async checkAndSetupDomain(subdomain) {
    if (!subdomain || subdomain.trim() === '') {
      throw new Error('Subdomain is required');
    }

    // Find user with this subdomain
    const user = await UserService.findBySubdomain(subdomain);
    
    if (!user) {
      throw new Error('Domain not available!!');
    }

    // Connect to tenant database
    const mongoUri = `mongodb://127.0.0.1:27017/${subdomain}`;
    const tenantDB = await connectdyDB(mongoUri);

    // Setup user in tenant database if not exists
    await this.setupTenantUser(tenantDB, user);

    return {
      available: true,
      user,
      tenantDB
    };
  }

  /**
   * Setup user in tenant database
   * @param {Object} tenantDB - Tenant database connection
   * @param {Object} user - User object
   * @returns {Promise<Object>} Setup result
   */
  async setupTenantUser(tenantDB, user) {
    const TenantUser = tenantDB.model("User", require('../models/userModel').schema);
    
    // Check if user already exists in tenant DB
    const existingTenantUser = await TenantUser.findOne({ uid: user.uid });
    
    if (!existingTenantUser) {
      const tenantUserData = {
        uid: user.uid,
        name: user.name,
        email: user.email,
        password: user.password,
        logo: user.logo,   
        subdomain: user.subdomain
      };
      
      const tenantUser = new TenantUser(tenantUserData);
      await tenantUser.save();
      
      return tenantUser;
    }
    
    return existingTenantUser;
  }

  /**
   * Get tenant database connection
   * @param {string} subdomain - Subdomain/tenant identifier
   * @returns {Promise<Object>} Tenant database connection
   */
  async getTenantDB(subdomain) {
    if (!subdomain) {
      throw new Error('Tenant identifier is required');
    }

    const mongoUri = `mongodb://127.0.0.1:27017/${subdomain}`;
    return await connectdyDB(mongoUri);
  }

  /**
   * Validate subdomain format
   * @param {string} subdomain - Subdomain to validate
   * @returns {boolean} True if valid
   */
  isValidSubdomain(subdomain) {
    // Basic subdomain validation
    const subdomainRegex = /^[a-zA-Z0-9][a-zA-Z0-9-]{1,61}[a-zA-Z0-9]$/;
    return subdomainRegex.test(subdomain);
  }

  /**
   * Setup initial tenant data
   * @param {Object} tenantDB - Tenant database connection
   * @param {Object} userData - User data
   * @returns {Promise<void>}
   */
  async setupInitialTenantData(tenantDB, userData) {
    // You can add initial setup logic here
    // For example: create default roles, permissions, initial projects, etc.
    
    console.log(`Setting up initial data for tenant: ${userData.subdomain}`);
    
    // This is where you could add:
    // - Default roles and permissions
    // - Sample projects or templates
    // - Default settings
    // - Welcome content
  }

  /**
   * Migrate tenant data (for future use)
   * @param {string} subdomain - Subdomain to migrate
   * @returns {Promise<Object>} Migration result
   */
  async migrateTenantData(subdomain) {
    // Placeholder for future migration logic
    throw new Error('Migration functionality not implemented yet');
  }

  /**
   * Delete tenant data (use with caution)
   * @param {string} subdomain - Subdomain to delete
   * @returns {Promise<Object>} Deletion result
   */
  async deleteTenantData(subdomain) {
    if (!subdomain) {
      throw new Error('Subdomain is required for deletion');
    }

    const tenantDB = await this.getTenantDB(subdomain);
    
    // This is a dangerous operation - should have additional safeguards
    const collections = await tenantDB.db.collections();
    const deletePromises = collections.map(collection => collection.drop());
    
    await Promise.all(deletePromises);
    
    return { success: true, message: `Tenant data deleted for ${subdomain}` };
  }
}

module.exports = new TenantService();