const BaseService = require("./BaseService");
const UserModel = require("../models/mysql/userModel");
const bcrypt = require("bcrypt");

/**
 * UserService - Handles all user-related business logic
 * Following Single Responsibility Principle
 */
class UserService extends BaseService {
  constructor() {
    super(null); // No Mongoose model needed
    this.UserModel = UserModel;
  }

  /**
   * Get user model instance with database connection
   * @param {Object} db - Database connection
   * @returns {Object} User model instance
   */
  getUserModel(db) {
    return new this.UserModel(db);
  }

  /**
   * Create user with hashed password
   * @param {Object} userData - User data
   * @param {Object} db - Database connection (optional, uses main DB if not provided)
   * @returns {Promise<Object>} Created user
   */
  async createUser(userData, db = null) {
    // Use main database connection if no specific DB provided
    const { connectDB } = require("../config/mysql");
    const connection = db || (await connectDB());

    const userModel = this.getUserModel(connection);
    const uid = await this.generateUID(userModel);

    return await userModel.create({ uid, ...userData });
  }

  /**
   * Authenticate user by email and password
   * @param {string} email - User email
   * @param {string} password - User password
   * @param {Object} db - Database connection (optional)
   * @returns {Promise<Object|null>} User if authenticated, null otherwise
   */
  async authenticateUser(email, password, db = null) {
    // Use main database connection if no specific DB provided
    const { connectDB } = require("../config/mysql");
    const connection = db || (await connectDB());

    const userModel = this.getUserModel(connection);
    const user = await userModel.findByEmail(email);
    if (!user) return null;

    const isValidPassword = await userModel.comparePassword(
      password,
      user.password
    );
    return isValidPassword ? user : null;
  }

  /**
   * Check if user exists by email or subdomain
   * @param {string} email - User email
   * @param {string} subdomain - User subdomain
   * @param {Object} db - Database connection (optional)
   * @returns {Promise<Object>} Existence check result
   */
  async checkUserExistence(email, subdomain, db = null) {
    // Use main database connection if no specific DB provided
    const { connectDB } = require("../config/mysql");
    const connection = db || (await connectDB());

    const userModel = this.getUserModel(connection);

    const [emailExists, subdomainExists] = await Promise.all([
      email ? userModel.exists({ email }) : false,
      subdomain ? userModel.exists({ subdomain }) : false,
    ]);

    return {
      emailExists,
      subdomainExists,
      exists: emailExists || subdomainExists,
    };
  }

  /**
   * Find user by subdomain
   * @param {string} subdomain - User subdomain
   * @param {Object} db - Database connection (optional)
   * @returns {Promise<Object|null>} User if found
   */
  async findBySubdomain(subdomain, db = null) {
    // Use main database connection if no specific DB provided
    const { connectDB } = require("../config/mysql");
    const connection = db || (await connectDB());

    const userModel = this.getUserModel(connection);
    return await userModel.findBySubdomain(subdomain);
  }

  /**
   * Delete all users (for development/testing)
   * @param {Object} db - Database connection (optional)
   * @returns {Promise<Object>} Delete result
   */
  async deleteAll(db = null) {
    // Use main database connection if no specific DB provided
    const { connectDB } = require("../config/mysql");
    const connection = db || (await connectDB());

    const userModel = this.getUserModel(connection);
    return await userModel.deleteAll();
  }

  /**
   * Create user from mobile verification
   * @param {string} mobile - User mobile number
   * @param {Object} db - Database connection (optional)
   * @returns {Promise<Object>} Created user
   */
  async createFromMobile(mobile, db = null) {
    // Use main database connection if no specific DB provided
    const { connectDB } = require("../config/mysql");
    const connection = db || (await connectDB());

    const userModel = this.getUserModel(connection);
    const uid = await this.generateUID(userModel);

    return await userModel.create({ uid, mobile });
  }

  /**
   * Generate unique UID for MySQL models
   * @param {Object} model - Model instance
   * @returns {Promise<string>} Unique UID
   */
  async generateUID(model) {
    let uid;
    let isUnique = false;
    while (!isUnique) {
      uid = Math.floor(1000000 + Math.random() * 9000000).toString();
      const exists = await model.exists({ uid });
      if (!exists) isUnique = true;
    }
    return uid;
  }
}

module.exports = new UserService();
