/**
 * Base Service Class - Following Single Responsibility Principle
 * Provides common CRUD operations that can be extended by specific services
 */
class BaseService {
  constructor(model) {
    this.model = model;
  }

  /**
   * Generate unique UID
   * @returns {Promise<string>} Unique UID
   */
  async generateUID() {
    let uid;
    let isUnique = false;
    while (!isUnique) {
      uid = Math.floor(1000000 + Math.random() * 9000000).toString();
      const existing = await this.model.findOne({ uid });
      if (!existing) isUnique = true;
    }
    return uid;
  }

  /**
   * Create new entity
   * @param {Object} data - Entity data
   * @returns {Promise<Object>} Created entity
   */
  async create(data) {
    const uid = await this.generateUID();
    const entity = new this.model({ uid, ...data });
    return await entity.save();
  }

  /**
   * Find entity by UID
   * @param {string} uid - Entity UID
   * @returns {Promise<Object|null>} Found entity
   */
  async findByUID(uid) {
    return await this.model.findOne({ uid });
  }

  /**
   * Find all entities with optional filter
   * @param {Object} filter - Optional filter
   * @returns {Promise<Array>} Array of entities
   */
  async findAll(filter = {}) {
    return await this.model.find(filter);
  }

  /**
   * Update entity by UID
   * @param {string} uid - Entity UID
   * @param {Object} data - Update data
   * @returns {Promise<Object>} Update result
   */
  async updateByUID(uid, data) {
    return await this.model.updateOne({ uid }, { $set: data });
  }

  /**
   * Delete entity by UID
   * @param {string} uid - Entity UID
   * @returns {Promise<Object|null>} Deleted entity
   */
  async deleteByUID(uid) {
    return await this.model.findOneAndDelete({ uid });
  }

  /**
   * Check if entity exists by field
   * @param {Object} filter - Filter criteria
   * @returns {Promise<boolean>} True if exists
   */
  async exists(filter) {
    const entity = await this.model.findOne(filter);
    return !!entity;
  }
}

module.exports = BaseService;