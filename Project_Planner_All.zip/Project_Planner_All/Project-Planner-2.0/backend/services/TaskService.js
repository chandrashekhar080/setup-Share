const BaseService = require('./BaseService');

/**
 * TaskService - Handles all task-related business logic
 * Following Single Responsibility Principle
 */
class TaskService extends BaseService {
  constructor(tenantDB) {
    // Use the Task model directly
    const taskModel = require("../models/taskModel");
    super(taskModel);
  }

  /**
   * Create or update task
   * @param {Object} taskData - Task data
   * @param {string} editUID - UID for editing (optional)
   * @returns {Promise<Object>} Operation result
   */
  async createOrUpdateTask(taskData, editUID = null) {
    const { taskname, project, ...otherData } = taskData;

    // Validation
    if (!taskname || !project) {
      throw new Error('Task name and project are required');
    }

    if (editUID) {
      return await this.updateTask(editUID, taskData);
    } else {
      return await this.createTask(taskData);
    }
  }

  /**
   * Create new task
   * @param {Object} taskData - Task data
   * @returns {Promise<Object>} Created task
   */
  async createTask(taskData) {
    const { taskname } = taskData;

    // Check if task name already exists
    const existingTask = await this.model.findOne({ taskname });
    if (existingTask) {
      throw new Error('This Task name is already in use!');
    }

    return await this.create(taskData);
  }

  /**
   * Update existing task
   * @param {string} uid - Task UID
   * @param {Object} taskData - Updated task data
   * @returns {Promise<Object>} Update result
   */
  async updateTask(uid, taskData) {
    const existingTask = await this.findByUID(uid);
    if (!existingTask) {
      throw new Error('Task not found for editing');
    }

    return await this.updateByUID(uid, taskData);
  }

  /**
   * Get tasks with optional filtering by project
   * @param {string} projectUID - Project UID for filtering (optional)
   * @returns {Promise<Array>} Array of tasks
   */
  async getTasks(projectUID = null) {
    const filter = projectUID ? { project: projectUID } : {};
    return await this.findAll(filter);
  }

  /**
   * Delete task by UID
   * @param {string} uid - Task UID
   * @returns {Promise<Object>} Deleted task
   */
  async deleteTask(uid) {
    if (!uid) {
      throw new Error('UID is required!');
    }

    const deleted = await this.deleteByUID(uid);
    if (!deleted) {
      throw new Error('Task not found or already deleted');
    }

    return deleted;
  }

  /**
   * Get task for editing
   * @param {string} uid - Task UID
   * @returns {Promise<Object>} Task data
   */
  async getTaskForEdit(uid) {
    if (!uid) {
      throw new Error('UID is required!');
    }

    const task = await this.findByUID(uid);
    if (!task) {
      throw new Error('This task is not available!');
    }

    return task;
  }

  /**
   * Get tasks by project UID
   * @param {string} projectUID - Project UID
   * @returns {Promise<Array>} Array of tasks for the project
   */
  async getTasksByProject(projectUID) {
    return await this.findAll({ project: projectUID });
  }
}

module.exports = TaskService;