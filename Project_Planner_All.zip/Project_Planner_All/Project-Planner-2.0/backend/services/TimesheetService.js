const BaseService = require('./BaseService');

/**
 * TimesheetService - Handles all timesheet-related business logic
 * Following Single Responsibility Principle
 */
class TimesheetService extends BaseService {
  constructor(tenantDB) {
    // Use the Timesheet model directly
    const timesheetModel = require("../models/timesheetModel");
    super(timesheetModel);
  }

  /**
   * Create or update timesheet
   * @param {Object} timesheetData - Timesheet data
   * @param {string} editUID - UID for editing (optional)
   * @returns {Promise<Object>} Operation result
   */
  async createOrUpdateTimesheet(timesheetData, editUID = null) {
    const { project, task, member, startDate } = timesheetData;

    // Validation
    if (!project || !member || !startDate) {
      throw new Error('Project, member, and start date are required');
    }

    if (editUID) {
      return await this.updateTimesheet(editUID, timesheetData);
    } else {
      return await this.createTimesheet(timesheetData);
    }
  }

  /**
   * Create new timesheet
   * @param {Object} timesheetData - Timesheet data
   * @returns {Promise<Object>} Created timesheet
   */
  async createTimesheet(timesheetData) {
    // Check for overlapping timesheets for the same member
    const { member, startDate, endDate } = timesheetData;
    
    if (endDate) {
      const overlapping = await this.model.findOne({
        member,
        isActive: true,
        $or: [
          {
            startDate: { $lte: new Date(startDate) },
            endDate: { $gte: new Date(startDate) }
          },
          {
            startDate: { $lte: new Date(endDate) },
            endDate: { $gte: new Date(endDate) }
          },
          {
            startDate: { $gte: new Date(startDate) },
            endDate: { $lte: new Date(endDate) }
          }
        ]
      });

      if (overlapping) {
        throw new Error('Overlapping timesheet entry found for this member');
      }
    }

    return await this.create(timesheetData);
  }

  /**
   * Update existing timesheet
   * @param {string} uid - Timesheet UID
   * @param {Object} timesheetData - Updated timesheet data
   * @returns {Promise<Object>} Update result
   */
  async updateTimesheet(uid, timesheetData) {
    const existingTimesheet = await this.findByUID(uid);
    if (!existingTimesheet) {
      throw new Error('Timesheet not found for editing');
    }

    // Check if timesheet is in a state that allows editing
    if (existingTimesheet.status === 'approved' || existingTimesheet.status === 'paid') {
      throw new Error('Cannot edit approved or paid timesheets');
    }

    return await this.updateByUID(uid, timesheetData);
  }

  /**
   * Get timesheets with optional filtering
   * @param {Object} filters - Filter options
   * @returns {Promise<Array>} Array of timesheets
   */
  async getTimesheets(filters = {}) {
    const query = { isActive: true, ...filters };
    return await this.findAll(query);
  }

  /**
   * Delete timesheet by UID (soft delete)
   * @param {string} uid - Timesheet UID
   * @returns {Promise<Object>} Updated timesheet
   */
  async deleteTimesheet(uid) {
    if (!uid) {
      throw new Error('UID is required!');
    }

    const timesheet = await this.findByUID(uid);
    if (!timesheet) {
      throw new Error('Timesheet not found');
    }

    // Check if timesheet can be deleted
    if (timesheet.status === 'approved' || timesheet.status === 'paid') {
      throw new Error('Cannot delete approved or paid timesheets');
    }

    // Soft delete by setting isActive to false
    return await this.updateByUID(uid, { isActive: false });
  }

  /**
   * Get timesheet for editing
   * @param {string} uid - Timesheet UID
   * @returns {Promise<Object>} Timesheet data
   */
  async getTimesheetForEdit(uid) {
    if (!uid) {
      throw new Error('UID is required!');
    }

    const timesheet = await this.findByUID(uid);
    if (!timesheet) {
      throw new Error('This timesheet is not available!');
    }

    if (!timesheet.isActive) {
      throw new Error('This timesheet has been deleted!');
    }

    return timesheet;
  }

  /**
   * Get timesheets by project UID
   * @param {string} projectUID - Project UID
   * @returns {Promise<Array>} Array of timesheets for the project
   */
  async getTimesheetsByProject(projectUID) {
    return await this.model.findByProject(projectUID);
  }

  /**
   * Get timesheets by task UID
   * @param {string} taskUID - Task UID
   * @returns {Promise<Array>} Array of timesheets for the task
   */
  async getTimesheetsByTask(taskUID) {
    return await this.model.findByTask(taskUID);
  }

  /**
   * Get timesheets by member
   * @param {string} member - Member name
   * @returns {Promise<Array>} Array of timesheets for the member
   */
  async getTimesheetsByMember(member) {
    return await this.model.findByMember(member);
  }

  /**
   * Approve timesheet
   * @param {string} uid - Timesheet UID
   * @param {string} approvedBy - Name of approver
   * @returns {Promise<Object>} Updated timesheet
   */
  async approveTimesheet(uid, approvedBy) {
    const timesheet = await this.findByUID(uid);
    if (!timesheet) {
      throw new Error('Timesheet not found');
    }

    if (timesheet.status !== 'submitted') {
      throw new Error('Only submitted timesheets can be approved');
    }

    return await timesheet.approve(approvedBy);
  }

  /**
   * Reject timesheet
   * @param {string} uid - Timesheet UID
   * @param {string} rejectedBy - Name of rejector
   * @param {string} reason - Rejection reason
   * @returns {Promise<Object>} Updated timesheet
   */
  async rejectTimesheet(uid, rejectedBy, reason) {
    const timesheet = await this.findByUID(uid);
    if (!timesheet) {
      throw new Error('Timesheet not found');
    }

    if (timesheet.status !== 'submitted') {
      throw new Error('Only submitted timesheets can be rejected');
    }

    return await timesheet.reject(rejectedBy, reason);
  }

  /**
   * Submit timesheet for approval
   * @param {string} uid - Timesheet UID
   * @returns {Promise<Object>} Updated timesheet
   */
  async submitTimesheet(uid) {
    const timesheet = await this.findByUID(uid);
    if (!timesheet) {
      throw new Error('Timesheet not found');
    }

    if (timesheet.status !== 'draft') {
      throw new Error('Only draft timesheets can be submitted');
    }

    // Validate required fields for submission
    if (!timesheet.hoursWorked || timesheet.hoursWorked <= 0) {
      throw new Error('Hours worked must be greater than 0 to submit');
    }

    return await this.updateByUID(uid, { status: 'submitted' });
  }

  /**
   * Get timesheet statistics
   * @param {Object} filters - Filter options
   * @returns {Promise<Object>} Statistics object
   */
  async getTimesheetStats(filters = {}) {
    const stats = await this.model.getTimesheetStats(filters);
    return stats.length > 0 ? stats[0] : {
      total: 0,
      totalHours: 0,
      totalBillableHours: 0,
      totalEarnings: 0,
      statusBreakdown: []
    };
  }

  /**
   * Get timesheet summary for a date range
   * @param {string} startDate - Start date
   * @param {string} endDate - End date
   * @param {Object} filters - Additional filters
   * @returns {Promise<Object>} Summary object
   */
  async getTimesheetSummary(startDate, endDate, filters = {}) {
    const query = {
      isActive: true,
      startDate: { $gte: new Date(startDate) },
      ...filters
    };

    if (endDate) {
      query.startDate.$lte = new Date(endDate);
    }

    const timesheets = await this.findAll(query);
    
    const summary = {
      totalEntries: timesheets.length,
      totalHours: 0,
      totalBillableHours: 0,
      totalEarnings: 0,
      averageHoursPerDay: 0,
      memberSummary: {},
      projectSummary: {},
      taskSummary: {}
    };

    timesheets.forEach(timesheet => {
      summary.totalHours += timesheet.hoursWorked || 0;
      summary.totalBillableHours += timesheet.billableHours || 0;
      summary.totalEarnings += timesheet.totalEarnings || 0;

      // Member summary
      if (!summary.memberSummary[timesheet.member]) {
        summary.memberSummary[timesheet.member] = {
          entries: 0,
          hours: 0,
          billableHours: 0,
          earnings: 0
        };
      }
      summary.memberSummary[timesheet.member].entries++;
      summary.memberSummary[timesheet.member].hours += timesheet.hoursWorked || 0;
      summary.memberSummary[timesheet.member].billableHours += timesheet.billableHours || 0;
      summary.memberSummary[timesheet.member].earnings += timesheet.totalEarnings || 0;

      // Project summary
      if (!summary.projectSummary[timesheet.project]) {
        summary.projectSummary[timesheet.project] = {
          entries: 0,
          hours: 0,
          billableHours: 0,
          earnings: 0
        };
      }
      summary.projectSummary[timesheet.project].entries++;
      summary.projectSummary[timesheet.project].hours += timesheet.hoursWorked || 0;
      summary.projectSummary[timesheet.project].billableHours += timesheet.billableHours || 0;
      summary.projectSummary[timesheet.project].earnings += timesheet.totalEarnings || 0;

      // Task summary
      if (!summary.taskSummary[timesheet.task]) {
        summary.taskSummary[timesheet.task] = {
          entries: 0,
          hours: 0,
          billableHours: 0,
          earnings: 0
        };
      }
      summary.taskSummary[timesheet.task].entries++;
      summary.taskSummary[timesheet.task].hours += timesheet.hoursWorked || 0;
      summary.taskSummary[timesheet.task].billableHours += timesheet.billableHours || 0;
      summary.taskSummary[timesheet.task].earnings += timesheet.totalEarnings || 0;
    });

    // Calculate average hours per day
    if (startDate && endDate) {
      const daysDiff = Math.ceil((new Date(endDate) - new Date(startDate)) / (1000 * 60 * 60 * 24)) + 1;
      summary.averageHoursPerDay = summary.totalHours / daysDiff;
    }

    return summary;
  }
}

module.exports = TimesheetService;