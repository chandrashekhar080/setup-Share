const { connectDB, connectdyDB } = require("../config/mysql");
const UserModel = require("../models/mysql/userModel");
const ProjectModel = require("../models/mysql/projectModel");

/**
 * MySQL Service - Following SOLID principles
 * Single Responsibility: Handle MySQL database operations
 * Dependency Injection: Models are injected as needed
 */
class MySQLService {
  constructor() {
    this.connections = new Map(); // Cache connections
  }

  /**
   * Get or create database connection
   * @param {string} database - Database name (optional, uses main if not provided)
   * @returns {Promise<Object>} Database connection
   */
  async getConnection(database = null) {
    try {
      if (database) {
        // Tenant database connection
        if (!this.connections.has(database)) {
          const connection = await connectdyDB(database);
          this.connections.set(database, connection);
        }
        return this.connections.get(database);
      } else {
        // Main database connection
        if (!this.connections.has("main")) {
          const connection = await connectDB();
          this.connections.set("main", connection);
        }
        return this.connections.get("main");
      }
    } catch (error) {
      throw new Error(`Database connection failed: ${error.message}`);
    }
  }

  /**
   * Create tables for a specific database
   * @param {string} database - Database name (optional)
   * @returns {Promise<Object>} Creation result
   */
  async createTables(database = null) {
    try {
      const connection = await this.getConnection(database);

      // Create User table
      const userModel = new UserModel(connection);
      await userModel.createTable();

      // Create Project table
      const projectModel = new ProjectModel(connection);
      await projectModel.createTable();

      return {
        success: true,
        database: database || "main",
        tables: ["users", "projects"],
        message: "Tables created successfully",
      };
    } catch (error) {
      throw new Error(`Table creation failed: ${error.message}`);
    }
  }

  /**
   * Check if tables exist in database
   * @param {string} database - Database name (optional)
   * @returns {Promise<Object>} Tables info
   */
  async checkTables(database = null) {
    try {
      const connection = await this.getConnection(database);
      const [tables] = await connection.execute("SHOW TABLES");

      const tableNames = tables.map((table) => {
        const dbName =
          database || process.env.MYSQL_DATABASE || "projectplanner";
        return table[`Tables_in_${dbName}`];
      });

      return {
        success: true,
        database: database || "main",
        tables: tableNames,
        count: tableNames.length,
      };
    } catch (error) {
      throw new Error(`Table check failed: ${error.message}`);
    }
  }

  /**
   * Get table structure information
   * @param {string} tableName - Table name
   * @param {string} database - Database name (optional)
   * @returns {Promise<Object>} Table structure
   */
  async getTableStructure(tableName, database = null) {
    try {
      const connection = await this.getConnection(database);
      const [columns] = await connection.execute(`DESCRIBE \`${tableName}\``);

      return {
        success: true,
        database: database || "main",
        table: tableName,
        columns: columns.map((col) => ({
          field: col.Field,
          type: col.Type,
          null: col.Null === "YES",
          key: col.Key,
          default: col.Default,
          extra: col.Extra,
        })),
      };
    } catch (error) {
      throw new Error(`Table structure check failed: ${error.message}`);
    }
  }

  /**
   * Get record count for a table
   * @param {string} tableName - Table name
   * @param {string} database - Database name (optional)
   * @returns {Promise<Object>} Record count
   */
  async getRecordCount(tableName, database = null) {
    try {
      const connection = await this.getConnection(database);
      const [result] = await connection.execute(
        `SELECT COUNT(*) as count FROM \`${tableName}\``
      );

      return {
        success: true,
        database: database || "main",
        table: tableName,
        count: result[0].count,
      };
    } catch (error) {
      throw new Error(`Record count failed: ${error.message}`);
    }
  }

  /**
   * List all databases
   * @returns {Promise<Object>} Database list
   */
  async listDatabases() {
    try {
      const connection = await this.getConnection();
      const [databases] = await connection.execute("SHOW DATABASES");

      const dbNames = databases
        .map((db) => db.Database)
        .filter(
          (name) =>
            ![
              "information_schema",
              "mysql",
              "performance_schema",
              "sys",
            ].includes(name)
        );

      return {
        success: true,
        databases: dbNames,
        count: dbNames.length,
      };
    } catch (error) {
      throw new Error(`Database listing failed: ${error.message}`);
    }
  }

  /**
   * Create sample data for testing
   * @param {string} database - Database name (optional)
   * @returns {Promise<Object>} Sample data creation result
   */
  async createSampleData(database = null) {
    try {
      const connection = await this.getConnection(database);

      // Ensure tables exist
      await this.createTables(database);

      const userModel = new UserModel(connection);
      const projectModel = new ProjectModel(connection);

      // Create sample user
      const sampleUser = {
        uid: Math.random().toString().substr(2, 7),
        email: `admin@${database || "main"}.com`,
        name: `${database || "Main"} Admin`,
        password: "SamplePass123",
        subdomain: database || "main",
        role: "admin",
        status: "active",
      };

      let user;
      try {
        user = await userModel.create(sampleUser);
      } catch (error) {
        if (error.code === "ER_DUP_ENTRY") {
          // User already exists, find existing
          user = await userModel.findByEmail(sampleUser.email);
        } else {
          throw error;
        }
      }

      // Create sample project
      const sampleProject = {
        uid: Math.random().toString().substr(2, 7),
        projectName: `${database || "Main"} Sample Project`,
        customer: "Internal",
        description: `Sample project for ${database || "main"} database`,
        status: "active",
        priority: "high",
        startDate: new Date(),
        endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
        budget: 50000,
        team: JSON.stringify(["admin"]),
        tags: JSON.stringify(["sample", "demo"]),
      };

      let project;
      try {
        project = await projectModel.create(sampleProject);
      } catch (error) {
        if (error.code === "ER_DUP_ENTRY") {
          // Project already exists
          project = { message: "Project already exists" };
        } else {
          throw error;
        }
      }

      return {
        success: true,
        database: database || "main",
        created: {
          user: user ? "Created" : "Already exists",
          project: project ? "Created" : "Already exists",
        },
      };
    } catch (error) {
      throw new Error(`Sample data creation failed: ${error.message}`);
    }
  }

  /**
   * Setup multi-tenant demo
   * @param {Array} tenants - Array of tenant objects {subdomain, name}
   * @returns {Promise<Object>} Setup result
   */
  async setupMultiTenantDemo(tenants = []) {
    try {
      const results = [];

      for (const tenant of tenants) {
        try {
          // Create tenant database and tables
          await this.createTables(tenant.subdomain);

          // Create sample data
          const sampleResult = await this.createSampleData(tenant.subdomain);

          // Get table info
          const tableInfo = await this.checkTables(tenant.subdomain);

          results.push({
            tenant: tenant.subdomain,
            name: tenant.name,
            status: "success",
            tables: tableInfo.tables,
            sampleData: sampleResult.created,
          });
        } catch (error) {
          results.push({
            tenant: tenant.subdomain,
            name: tenant.name,
            status: "error",
            error: error.message,
          });
        }
      }

      return {
        success: true,
        message: "Multi-tenant demo setup completed",
        results,
      };
    } catch (error) {
      throw new Error(`Multi-tenant setup failed: ${error.message}`);
    }
  }

  /**
   * Get database overview
   * @returns {Promise<Object>} Database overview
   */
  async getDatabaseOverview() {
    try {
      const databases = await this.listDatabases();
      const overview = [];

      for (const dbName of databases.databases) {
        try {
          const tables = await this.checkTables(dbName);
          const tableDetails = [];

          for (const tableName of tables.tables) {
            const count = await this.getRecordCount(tableName, dbName);
            tableDetails.push({
              name: tableName,
              records: count.count,
            });
          }

          overview.push({
            database: dbName,
            tables: tableDetails,
            totalTables: tables.count,
          });
        } catch (error) {
          overview.push({
            database: dbName,
            error: error.message,
          });
        }
      }

      return {
        success: true,
        overview,
        totalDatabases: databases.count,
      };
    } catch (error) {
      throw new Error(`Database overview failed: ${error.message}`);
    }
  }

  /**
   * Close all connections
   */
  async closeConnections() {
    try {
      for (const [key, connection] of this.connections) {
        await connection.end();
      }
      this.connections.clear();
    } catch (error) {
      console.error("Error closing connections:", error.message);
    }
  }
}

module.exports = new MySQLService();
