const Otp = require('../models/otpModel');

/**
 * OTPService - Handles all OTP-related operations
 * Following Single Responsibility Principle
 */
class OTPService {
  /**
   * Generate OTP code
   * @returns {string} 6-digit OTP
   */
  generateOTP() {
    return Math.floor(100000 + Math.random() * 900000).toString();
  }

  /**
   * Send OTP to mobile (placeholder implementation)
   * @param {string} mobile - Mobile number
   * @returns {Promise<string>} Generated OTP
   */
  async sendOtpToMobile(mobile) {
    const otp = this.generateOTP();
    
    // In a real implementation, you would integrate with SMS service
    console.log(`Sending OTP ${otp} to mobile ${mobile}`);
    
    // Save OTP to database
    await this.saveOTP(mobile, otp);
    
    return otp;
  }

  /**
   * Save OTP to database
   * @param {string} mobile - Mobile number
   * @param {string} otp - OTP code
   * @returns {Promise<Object>} Saved OTP document
   */
  async saveOTP(mobile, otp) {
    // Remove any existing OTP for this mobile
    await Otp.deleteMany({ mobile });

    // Create new OTP with expiration
    const expiresAt = new Date(Date.now() + 15 * 60 * 1000); // 15 minutes
    
    const otpDoc = new Otp({
      mobile,
      otp,
      expiresAt
    });

    return await otpDoc.save();
  }

  /**
   * Verify OTP
   * @param {string} mobile - Mobile number
   * @param {string} otp - OTP code to verify
   * @returns {Promise<Object>} Verification result
   */
  async verifyOTP(mobile, otp) {
    if (!mobile || !otp) {
      throw new Error('Mobile and OTP required');
    }

    const otpDoc = await Otp.findOne({ mobile, otp });

    if (!otpDoc) {
      throw new Error('Invalid OTP');
    }

    if (otpDoc.expiresAt < new Date()) {
      await Otp.deleteOne({ _id: otpDoc._id });
      throw new Error('OTP expired');
    }

    // Clean up used OTP
    await Otp.deleteOne({ _id: otpDoc._id });

    return {
      verified: true,
      mobile
    };
  }

  /**
   * Clean up expired OTPs
   * @returns {Promise<Object>} Cleanup result
   */
  async cleanupExpiredOTPs() {
    return await Otp.deleteMany({
      expiresAt: { $lt: new Date() }
    });
  }
}

module.exports = new OTPService();