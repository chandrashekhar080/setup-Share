const { getConnection } = require('../config/mysql');
const TimesheetModel = require('../models/timesheetModelMySQL');

/**
 * Timesheet Service - Business logic for timesheet operations
 * Uses MySQL instead of MongoDB for better compatibility
 */
class TimesheetService {
  constructor() {
    this.connection = null;
    this.model = null;
  }

  async initialize() {
    if (!this.connection) {
      this.connection = await getConnection();
      this.model = new TimesheetModel(this.connection);
      await this.model.createTable();
    }
  }

  /**
   * Create or update timesheet
   * @param {Object} timesheetData - Timesheet data
   * @param {string} editUID - UID for editing (optional)
   * @returns {Promise<Object>} Operation result
   */
  async createOrUpdateTimesheet(timesheetData, editUID = null) {
    await this.initialize();
    
    const { project, member, startDate } = timesheetData;

    // Validation
    if (!project || !member || !startDate) {
      throw new Error('Project, member, and start date are required');
    }

    if (editUID) {
      return await this.updateTimesheet(editUID, timesheetData);
    } else {
      return await this.createTimesheet(timesheetData);
    }
  }

  /**
   * Create new timesheet
   * @param {Object} timesheetData - Timesheet data
   * @returns {Promise<Object>} Created timesheet
   */
  async createTimesheet(timesheetData) {
    await this.initialize();
    
    try {
      const timesheet = await this.model.create(timesheetData);
      return {
        success: true,
        data: timesheet,
        message: 'Timesheet created successfully'
      };
    } catch (error) {
      throw new Error(`Failed to create timesheet: ${error.message}`);
    }
  }

  /**
   * Update existing timesheet
   * @param {string} uid - Timesheet UID
   * @param {Object} updateData - Update data
   * @returns {Promise<Object>} Updated timesheet
   */
  async updateTimesheet(uid, updateData) {
    await this.initialize();
    
    try {
      const timesheet = await this.model.findOneAndUpdate({ uid }, updateData);
      return {
        success: true,
        data: timesheet,
        message: 'Timesheet updated successfully'
      };
    } catch (error) {
      throw new Error(`Failed to update timesheet: ${error.message}`);
    }
  }

  /**
   * Get all timesheets with optional filters
   * @param {Object} filters - Search filters
   * @returns {Promise<Array>} Timesheets array
   */
  async getAllTimesheets(filters = {}) {
    await this.initialize();
    
    try {
      const timesheets = await this.model.find(filters);
      return {
        success: true,
        data: timesheets,
        count: timesheets.length
      };
    } catch (error) {
      throw new Error(`Failed to get timesheets: ${error.message}`);
    }
  }

  /**
   * Get timesheet by UID
   * @param {string} uid - Timesheet UID
   * @returns {Promise<Object>} Timesheet object
   */
  async getTimesheetByUID(uid) {
    await this.initialize();
    
    try {
      const timesheet = await this.model.findOne({ uid });
      if (!timesheet) {
        throw new Error('Timesheet not found');
      }
      return {
        success: true,
        data: timesheet
      };
    } catch (error) {
      throw new Error(`Failed to get timesheet: ${error.message}`);
    }
  }

  /**
   * Delete timesheet (soft delete)
   * @param {string} uid - Timesheet UID
   * @returns {Promise<Object>} Delete result
   */
  async deleteTimesheet(uid) {
    await this.initialize();
    
    try {
      const result = await this.model.findOneAndDelete({ uid });
      return {
        success: true,
        data: result,
        message: 'Timesheet deleted successfully'
      };
    } catch (error) {
      throw new Error(`Failed to delete timesheet: ${error.message}`);
    }
  }

  /**
   * Submit timesheet for approval
   * @param {string} uid - Timesheet UID
   * @returns {Promise<Object>} Updated timesheet
   */
  async submitTimesheet(uid) {
    await this.initialize();
    
    try {
      const timesheet = await this.model.findOneAndUpdate(
        { uid }, 
        { status: 'submitted' }
      );
      return {
        success: true,
        data: timesheet,
        message: 'Timesheet submitted for approval'
      };
    } catch (error) {
      throw new Error(`Failed to submit timesheet: ${error.message}`);
    }
  }

  /**
   * Approve or reject timesheet
   * @param {string} uid - Timesheet UID
   * @param {string} action - 'approve' or 'reject'
   * @param {string} approvedBy - Approver name
   * @param {string} reason - Rejection reason (if rejecting)
   * @returns {Promise<Object>} Updated timesheet
   */
  async approveTimesheet(uid, action, approvedBy, reason = null) {
    await this.initialize();
    
    const updateData = {
      status: action === 'approve' ? 'approved' : 'rejected',
      approvedBy,
      approvedAt: new Date()
    };

    if (action === 'reject' && reason) {
      updateData.rejectionReason = reason;
    }

    try {
      const timesheet = await this.model.findOneAndUpdate({ uid }, updateData);
      return {
        success: true,
        data: timesheet,
        message: `Timesheet ${action}d successfully`
      };
    } catch (error) {
      throw new Error(`Failed to ${action} timesheet: ${error.message}`);
    }
  }

  /**
   * Get timesheet statistics
   * @returns {Promise<Object>} Timesheet statistics
   */
  async getTimesheetStats() {
    await this.initialize();
    
    try {
      const stats = await this.model.getStats();
      return {
        success: true,
        data: stats
      };
    } catch (error) {
      throw new Error(`Failed to get timesheet stats: ${error.message}`);
    }
  }

  /**
   * Get timesheets by project
   * @param {string} projectUID - Project UID
   * @returns {Promise<Array>} Timesheets for project
   */
  async getTimesheetsByProject(projectUID) {
    await this.initialize();
    
    try {
      const timesheets = await this.model.find({ project: projectUID });
      return {
        success: true,
        data: timesheets,
        count: timesheets.length
      };
    } catch (error) {
      throw new Error(`Failed to get timesheets by project: ${error.message}`);
    }
  }

  /**
   * Get timesheets by task
   * @param {string} taskUID - Task UID
   * @returns {Promise<Array>} Timesheets for task
   */
  async getTimesheetsByTask(taskUID) {
    await this.initialize();
    
    try {
      const timesheets = await this.model.find({ task: taskUID });
      return {
        success: true,
        data: timesheets,
        count: timesheets.length
      };
    } catch (error) {
      throw new Error(`Failed to get timesheets by task: ${error.message}`);
    }
  }

  /**
   * Get timesheets by member
   * @param {string} member - Member name
   * @returns {Promise<Array>} Timesheets for member
   */
  async getTimesheetsByMember(member) {
    await this.initialize();
    
    try {
      const timesheets = await this.model.find({ member });
      return {
        success: true,
        data: timesheets,
        count: timesheets.length
      };
    } catch (error) {
      throw new Error(`Failed to get timesheets by member: ${error.message}`);
    }
  }
}

module.exports = TimesheetService;