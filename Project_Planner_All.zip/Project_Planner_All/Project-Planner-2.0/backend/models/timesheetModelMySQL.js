const mysql = require('mysql2/promise');
const { v4: uuidv4 } = require('uuid');

/**
 * Timesheet Model for MySQL
 * Handles timesheet-related database operations
 */
class TimesheetModel {
  constructor(connection) {
    this.connection = connection;
    this.tableName = 'timesheets';
  }

  /**
   * Create timesheets table if it doesn't exist
   */
  async createTable() {
    const createTableQuery = `
      CREATE TABLE IF NOT EXISTS ${this.tableName} (
        uid VARCHAR(36) PRIMARY KEY,
        project VARCHAR(36) NOT NULL,
        task VARCHAR(36),
        member VARCHAR(100) NOT NULL,
        startDate DATE NOT NULL,
        endDate DATE,
        hoursWorked DECIMAL(5,2) NOT NULL DEFAULT 0,
        billableHours DECIMAL(5,2) DEFAULT 0,
        hourlyRate DECIMAL(10,2) DEFAULT 0,
        description TEXT,
        status ENUM('draft', 'submitted', 'approved', 'rejected', 'paid') DEFAULT 'draft',
        approvedBy VARCHAR(100),
        approvedAt TIMESTAMP NULL,
        rejectionReason TEXT,
        isActive BOOLEAN DEFAULT TRUE,
        createdBy VARCHAR(100) DEFAULT 'system',
        lastUpdatedBy VARCHAR(100),
        createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_project (project),
        INDEX idx_task (task),
        INDEX idx_member (member),
        INDEX idx_status (status),
        INDEX idx_start_date (startDate),
        INDEX idx_active (isActive)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `;

    try {
      await this.connection.execute(createTableQuery);
      console.log('✅ Timesheets table created/verified successfully');
    } catch (error) {
      console.error('❌ Error creating timesheets table:', error.message);
      throw error;
    }
  }

  /**
   * Create a new timesheet
   */
  async create(timesheetData) {
    const uid = timesheetData.uid || uuidv4();
    const {
      project,
      task,
      member,
      startDate,
      endDate,
      hoursWorked = 0,
      billableHours = 0,
      hourlyRate = 0,
      description,
      status = 'draft',
      createdBy = 'system'
    } = timesheetData;

    const query = `
      INSERT INTO ${this.tableName} 
      (uid, project, task, member, startDate, endDate, hoursWorked, billableHours, hourlyRate, description, status, createdBy)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const values = [
      uid, 
      project, 
      task || null, 
      member, 
      startDate, 
      endDate || null, 
      hoursWorked, 
      billableHours, 
      hourlyRate, 
      description || null, 
      status, 
      createdBy
    ];

    try {
      const [result] = await this.connection.execute(query, values);
      return { uid, ...timesheetData, createdAt: new Date(), updatedAt: new Date() };
    } catch (error) {
      console.error('❌ Error creating timesheet:', error.message);
      throw error;
    }
  }

  /**
   * Find timesheets with filters
   */
  async find(filters = {}) {
    let query = `SELECT * FROM ${this.tableName} WHERE isActive = TRUE`;
    const values = [];

    if (filters.project) {
      query += ' AND project = ?';
      values.push(filters.project);
    }

    if (filters.task) {
      query += ' AND task = ?';
      values.push(filters.task);
    }

    if (filters.member) {
      query += ' AND member LIKE ?';
      values.push(`%${filters.member}%`);
    }

    if (filters.status) {
      query += ' AND status = ?';
      values.push(filters.status);
    }

    if (filters.startDate) {
      query += ' AND startDate >= ?';
      values.push(filters.startDate);
    }

    if (filters.endDate) {
      query += ' AND startDate <= ?';
      values.push(filters.endDate);
    }

    query += ' ORDER BY startDate DESC, createdAt DESC';

    try {
      const [rows] = await this.connection.execute(query, values);
      return rows;
    } catch (error) {
      console.error('❌ Error finding timesheets:', error.message);
      throw error;
    }
  }

  /**
   * Find timesheet by UID
   */
  async findOne(filters) {
    let query = `SELECT * FROM ${this.tableName} WHERE isActive = TRUE`;
    const values = [];

    if (filters.uid) {
      query += ' AND uid = ?';
      values.push(filters.uid);
    }

    query += ' LIMIT 1';

    try {
      const [rows] = await this.connection.execute(query, values);
      return rows[0] || null;
    } catch (error) {
      console.error('❌ Error finding timesheet:', error.message);
      throw error;
    }
  }

  /**
   * Update timesheet
   */
  async findOneAndUpdate(filter, updateData) {
    const { uid } = filter;
    const updateFields = [];
    const values = [];

    // Build dynamic update query
    Object.keys(updateData).forEach(key => {
      if (key !== 'uid' && updateData[key] !== undefined) {
        updateFields.push(`${key} = ?`);
        values.push(updateData[key]);
      }
    });

    if (updateFields.length === 0) {
      throw new Error('No fields to update');
    }

    updateFields.push('updatedAt = CURRENT_TIMESTAMP');
    values.push(uid);

    const query = `
      UPDATE ${this.tableName} 
      SET ${updateFields.join(', ')} 
      WHERE uid = ? AND isActive = TRUE
    `;

    try {
      const [result] = await this.connection.execute(query, values);
      if (result.affectedRows === 0) {
        throw new Error('Timesheet not found or already inactive');
      }
      
      // Return updated timesheet
      return await this.findOne({ uid });
    } catch (error) {
      console.error('❌ Error updating timesheet:', error.message);
      throw error;
    }
  }

  /**
   * Soft delete timesheet
   */
  async findOneAndDelete(filter) {
    const { uid } = filter;
    const query = `
      UPDATE ${this.tableName} 
      SET isActive = FALSE, updatedAt = CURRENT_TIMESTAMP 
      WHERE uid = ? AND isActive = TRUE
    `;

    try {
      const [result] = await this.connection.execute(query, [uid]);
      if (result.affectedRows === 0) {
        throw new Error('Timesheet not found or already inactive');
      }
      return { uid, deleted: true };
    } catch (error) {
      console.error('❌ Error deleting timesheet:', error.message);
      throw error;
    }
  }

  /**
   * Get timesheet statistics
   */
  async getStats() {
    const query = `
      SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'draft' THEN 1 ELSE 0 END) as draft,
        SUM(CASE WHEN status = 'submitted' THEN 1 ELSE 0 END) as submitted,
        SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved,
        SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected,
        SUM(CASE WHEN status = 'paid' THEN 1 ELSE 0 END) as paid,
        SUM(hoursWorked) as totalHours,
        SUM(billableHours) as totalBillableHours,
        AVG(hourlyRate) as avgHourlyRate
      FROM ${this.tableName} 
      WHERE isActive = TRUE
    `;

    try {
      const [rows] = await this.connection.execute(query);
      return rows[0];
    } catch (error) {
      console.error('❌ Error getting timesheet stats:', error.message);
      throw error;
    }
  }
}

module.exports = TimesheetModel;