const mongoose = require('mongoose');

/**
 * Task Model - Following SOLID principles with proper validation and methods
 */
const taskSchema = new mongoose.Schema(
  {
    uid: {
      type: String,
      required: true,
      unique: true,
      index: true,
      validate: {
        validator: function(v) {
          return /^\d{7}$/.test(v);
        },
        message: 'UID must be a 7-digit number string'
      }
    },
    taskname: {
      type: String,
      required: true,
      trim: true,
      minlength: [3, 'Task name must be at least 3 characters long'],
      maxlength: [200, 'Task name cannot exceed 200 characters'],
      index: true
    },
    project: {
      type: String,
      required: true,
      validate: {
        validator: function(v) {
          return /^\d{7}$/.test(v);
        },
        message: 'Project UID must be a 7-digit number string'
      },
      index: true
    },
    assignee: { // Fixed typo from 'assigene'
      type: String,
      required: false,
      trim: true,
      minlength: [2, 'Assignee name must be at least 2 characters long'],
      maxlength: [100, 'Assignee name cannot exceed 100 characters'],
      index: true
    },
    duedate: {
      type: Date,
      required: false,
      validate: {
        validator: function(v) {
          return !v || (v instanceof Date && !isNaN(v));
        },
        message: 'Due date must be a valid date'
      },
      index: true
    },
    priority: {
      type: String,
      enum: ['low', 'medium', 'high', 'urgent'],
      default: 'medium',
      required: false,
      index: true
    },
    progress: {
      type: Number,
      required: false,
      default: 0,
      min: [0, 'Progress cannot be less than 0%'],
      max: [100, 'Progress cannot exceed 100%'],
      validate: {
        validator: function(v) {
          return Number.isInteger(v) && v >= 0 && v <= 100;
        },
        message: 'Progress must be an integer between 0 and 100'
      }
    },
    comments: {
      type: String,
      required: false,
      trim: true,
      maxlength: [2000, 'Comments cannot exceed 2000 characters']
    },
    status: {
      type: String,
      enum: ['todo', 'in-progress', 'completed', 'cancelled'],
      default: 'todo',
      required: true,
      index: true
    },
    estimatedHours: {
      type: Number,
      required: false,
      min: [0.5, 'Estimated hours must be at least 0.5'],
      max: [1000, 'Estimated hours cannot exceed 1000']
    },
    actualHours: {
      type: Number,
      required: false,
      min: [0, 'Actual hours cannot be negative'],
      max: [1000, 'Actual hours cannot exceed 1000']
    },
    tags: [{
      type: String,
      trim: true,
      lowercase: true,
      maxlength: [30, 'Each tag cannot exceed 30 characters']
    }],
    subtasks: [{
      name: {
        type: String,
        required: true,
        trim: true,
        maxlength: [200, 'Subtask name cannot exceed 200 characters']
      },
      completed: {
        type: Boolean,
        default: false
      },
      completedAt: {
        type: Date,
        required: false
      }
    }],
    attachments: [{
      filename: String,
      originalName: String,
      mimeType: String,
      size: Number,
      uploadDate: { type: Date, default: Date.now }
    }],
    dependencies: [{
      type: String,
      validate: {
        validator: function(v) {
          return /^\d{7}$/.test(v);
        },
        message: 'Dependency UID must be a 7-digit number string'
      }
    }],
    createdBy: {
      type: String,
      required: false,
      trim: true,
      default: 'system'
    },
    lastUpdatedBy: {
      type: String,
      required: false,
      trim: true
    },
    completedAt: {
      type: Date,
      required: false
    },
    startedAt: {
      type: Date,
      required: false
    }
  },
  {
    timestamps: true,
    toJSON: {
      virtuals: true,
      transform: function(doc, ret) {
        // Format dates for frontend
        if (ret.duedate) ret.duedate = ret.duedate.toISOString().split('T')[0];
        if (ret.completedAt) ret.completedAt = ret.completedAt.toISOString().split('T')[0];
        if (ret.startedAt) ret.startedAt = ret.startedAt.toISOString().split('T')[0];
        return ret;
      }
    },
    toObject: { virtuals: true }
  }
);

// Indexes for better performance
taskSchema.index({ project: 1, status: 1 });
taskSchema.index({ assignee: 1, status: 1 });
taskSchema.index({ priority: 1, duedate: 1 });
taskSchema.index({ duedate: 1, status: 1 });
taskSchema.index({ createdAt: -1 });
taskSchema.index({ tags: 1 });

// Virtual for overdue status
taskSchema.virtual('isOverdue').get(function() {
  if (this.status === 'completed' || this.status === 'cancelled') return false;
  return this.duedate && new Date() > this.duedate;
});

// Virtual for days remaining
taskSchema.virtual('daysRemaining').get(function() {
  if (!this.duedate) return null;
  const today = new Date();
  const timeDiff = this.duedate.getTime() - today.getTime();
  return Math.ceil(timeDiff / (1000 * 60 * 60 * 24));
});

// Virtual for subtask completion percentage
taskSchema.virtual('subtaskProgress').get(function() {
  if (!this.subtasks || this.subtasks.length === 0) return 0;
  const completed = this.subtasks.filter(st => st.completed).length;
  return Math.round((completed / this.subtasks.length) * 100);
});

// Virtual for time tracking
taskSchema.virtual('timeVariance').get(function() {
  if (!this.estimatedHours || !this.actualHours) return null;
  return this.actualHours - this.estimatedHours;
});

// Virtual for efficiency percentage
taskSchema.virtual('efficiency').get(function() {
  if (!this.estimatedHours || !this.actualHours || this.actualHours === 0) return null;
  return Math.round((this.estimatedHours / this.actualHours) * 100);
});

// Pre-save middleware to update completion timestamps
taskSchema.pre('save', function(next) {
  const wasCompleted = this.isModified('status') && this.status === 'completed';
  const wasStarted = this.isModified('status') && this.status === 'in_progress' && !this.startedAt;
  
  if (wasCompleted && !this.completedAt) {
    this.completedAt = new Date();
    this.progress = 100;
  }
  
  if (wasStarted) {
    this.startedAt = new Date();
  }
  
  // Reset completedAt if status is changed from completed
  if (this.isModified('status') && this.status !== 'completed') {
    this.completedAt = undefined;
  }
  
  next();
});

// Pre-save middleware to update progress based on subtasks
taskSchema.pre('save', function(next) {
  if (this.isModified('subtasks') && this.subtasks && this.subtasks.length > 0) {
    const completedSubtasks = this.subtasks.filter(st => st.completed).length;
    const subtaskProgress = Math.round((completedSubtasks / this.subtasks.length) * 100);
    
    // Update overall progress based on subtasks if not manually set
    if (!this.isModified('progress')) {
      this.progress = subtaskProgress;
    }
  }
  next();
});

// Static method to find tasks by project
taskSchema.statics.findByProject = function(projectUid) {
  return this.find({ project: projectUid }).sort({ priority: -1, duedate: 1 });
};

// Static method to find overdue tasks
taskSchema.statics.findOverdue = function() {
  const today = new Date();
  return this.find({
    duedate: { $lt: today },
    status: { $nin: ['completed', 'cancelled'] }
  }).sort({ duedate: 1 });
};

// Static method to find tasks by assignee
taskSchema.statics.findByAssignee = function(assignee) {
  return this.find({ 
    assignee: new RegExp(assignee, 'i'),
    status: { $ne: 'completed' }
  }).sort({ priority: -1, duedate: 1 });
};

// Static method to get task statistics
taskSchema.statics.getTaskStats = function(projectUid = null) {
  const matchQuery = projectUid ? { project: projectUid } : {};
  
  return this.aggregate([
    { $match: matchQuery },
    {
      $group: {
        _id: '$status',
        count: { $sum: 1 },
        averageProgress: { $avg: '$progress' },
        totalEstimatedHours: { $sum: '$estimatedHours' },
        totalActualHours: { $sum: '$actualHours' }
      }
    },
    {
      $group: {
        _id: null,
        total: { $sum: '$count' },
        totalEstimatedHours: { $sum: '$totalEstimatedHours' },
        totalActualHours: { $sum: '$totalActualHours' },
        statusBreakdown: {
          $push: {
            status: '$_id',
            count: '$count',
            averageProgress: '$averageProgress',
            totalEstimatedHours: '$totalEstimatedHours',
            totalActualHours: '$totalActualHours'
          }
        }
      }
    }
  ]);
};

// Instance method to add subtask
taskSchema.methods.addSubtask = function(subtaskName) {
  this.subtasks.push({ name: subtaskName, completed: false });
  return this.save();
};

// Instance method to complete subtask
taskSchema.methods.completeSubtask = function(subtaskIndex) {
  if (subtaskIndex >= 0 && subtaskIndex < this.subtasks.length) {
    this.subtasks[subtaskIndex].completed = true;
    this.subtasks[subtaskIndex].completedAt = new Date();
    return this.save();
  }
  throw new Error('Invalid subtask index');
};

// Instance method to update progress and auto-update status
taskSchema.methods.updateProgress = function(newProgress) {
  if (newProgress < 0 || newProgress > 100) {
    throw new Error('Progress must be between 0 and 100');
  }
  
  this.progress = newProgress;
  
  // Auto-update status based on progress
  if (newProgress === 100 && this.status !== 'completed') {
    this.status = 'completed';
    this.completedAt = new Date();
  } else if (newProgress > 0 && this.status === 'todo') {
    this.status = 'in_progress';
    this.startedAt = new Date();
  }
  
  return this.save();
};

// Instance method to check if task can be started
taskSchema.methods.canStart = function() {
  // Logic to check dependencies, etc.
  return this.status === 'todo' && this.dependencies.length === 0;
};

const Task = mongoose.model('Task', taskSchema);

module.exports = Task;