const mysql = require('mysql2/promise');
const { v4: uuidv4 } = require('uuid');

/**
 * Task Model for MySQL
 * Handles task-related database operations
 */
class TaskModel {
  constructor(connection) {
    this.connection = connection;
    this.tableName = 'tasks';
  }

  /**
   * Create tasks table if it doesn't exist
   */
  async createTable() {
    const createTableQuery = `
      CREATE TABLE IF NOT EXISTS ${this.tableName} (
        uid VARCHAR(36) PRIMARY KEY,
        taskname VARCHAR(255) NOT NULL,
        project VARCHAR(36) NOT NULL,
        assignee VARCHAR(100),
        duedate DATE,
        priority ENUM('low', 'medium', 'high', 'urgent') DEFAULT 'medium',
        progress INT DEFAULT 0,
        comments TEXT,
        status ENUM('todo', 'in-progress', 'completed', 'cancelled') DEFAULT 'todo',
        isActive BOOLEAN DEFAULT TRUE,
        createdBy VARCHAR(100) DEFAULT 'system',
        lastUpdatedBy VARCHAR(100),
        createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_project (project),
        INDEX idx_assignee (assignee),
        INDEX idx_status (status),
        INDEX idx_priority (priority),
        INDEX idx_duedate (duedate),
        INDEX idx_active (isActive)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `;

    try {
      await this.connection.execute(createTableQuery);
      console.log('✅ Tasks table created/verified successfully');
    } catch (error) {
      console.error('❌ Error creating tasks table:', error.message);
      throw error;
    }
  }

  /**
   * Create a new task
   */
  async create(taskData) {
    const uid = taskData.uid || uuidv4();
    const {
      taskname,
      project,
      assignee,
      duedate,
      priority = 'medium',
      progress = 0,
      comments,
      status = 'todo',
      createdBy = 'system'
    } = taskData;

    const query = `
      INSERT INTO ${this.tableName} 
      (uid, taskname, project, assignee, duedate, priority, progress, comments, status, createdBy)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const values = [
      uid, 
      taskname, 
      project, 
      assignee || null, 
      duedate || null, 
      priority, 
      progress, 
      comments || null, 
      status, 
      createdBy
    ];

    try {
      const [result] = await this.connection.execute(query, values);
      return { uid, ...taskData, createdAt: new Date(), updatedAt: new Date() };
    } catch (error) {
      console.error('❌ Error creating task:', error.message);
      throw error;
    }
  }

  /**
   * Find tasks with filters
   */
  async find(filters = {}) {
    let query = `SELECT * FROM ${this.tableName} WHERE isActive = TRUE`;
    const values = [];

    if (filters.project) {
      query += ' AND project = ?';
      values.push(filters.project);
    }

    if (filters.assignee) {
      query += ' AND assignee LIKE ?';
      values.push(`%${filters.assignee}%`);
    }

    if (filters.status) {
      query += ' AND status = ?';
      values.push(filters.status);
    }

    if (filters.priority) {
      query += ' AND priority = ?';
      values.push(filters.priority);
    }

    if (filters.q) {
      query += ' AND (taskname LIKE ? OR comments LIKE ?)';
      values.push(`%${filters.q}%`, `%${filters.q}%`);
    }

    query += ' ORDER BY createdAt DESC';

    try {
      const [rows] = await this.connection.execute(query, values);
      return rows;
    } catch (error) {
      console.error('❌ Error finding tasks:', error.message);
      throw error;
    }
  }

  /**
   * Find task by UID
   */
  async findOne(filters) {
    let query = `SELECT * FROM ${this.tableName} WHERE isActive = TRUE`;
    const values = [];

    if (filters.uid) {
      query += ' AND uid = ?';
      values.push(filters.uid);
    }

    query += ' LIMIT 1';

    try {
      const [rows] = await this.connection.execute(query, values);
      return rows[0] || null;
    } catch (error) {
      console.error('❌ Error finding task:', error.message);
      throw error;
    }
  }

  /**
   * Update task
   */
  async findOneAndUpdate(filter, updateData) {
    const { uid } = filter;
    const updateFields = [];
    const values = [];

    // Build dynamic update query
    Object.keys(updateData).forEach(key => {
      if (key !== 'uid' && updateData[key] !== undefined) {
        updateFields.push(`${key} = ?`);
        values.push(updateData[key]);
      }
    });

    if (updateFields.length === 0) {
      throw new Error('No fields to update');
    }

    updateFields.push('updatedAt = CURRENT_TIMESTAMP');
    values.push(uid);

    const query = `
      UPDATE ${this.tableName} 
      SET ${updateFields.join(', ')} 
      WHERE uid = ? AND isActive = TRUE
    `;

    try {
      const [result] = await this.connection.execute(query, values);
      if (result.affectedRows === 0) {
        throw new Error('Task not found or already inactive');
      }
      
      // Return updated task
      return await this.findOne({ uid });
    } catch (error) {
      console.error('❌ Error updating task:', error.message);
      throw error;
    }
  }

  /**
   * Soft delete task
   */
  async findOneAndDelete(filter) {
    const { uid } = filter;
    const query = `
      UPDATE ${this.tableName} 
      SET isActive = FALSE, updatedAt = CURRENT_TIMESTAMP 
      WHERE uid = ? AND isActive = TRUE
    `;

    try {
      const [result] = await this.connection.execute(query, [uid]);
      if (result.affectedRows === 0) {
        throw new Error('Task not found or already inactive');
      }
      return { uid, deleted: true };
    } catch (error) {
      console.error('❌ Error deleting task:', error.message);
      throw error;
    }
  }

  /**
   * Get task statistics
   */
  async getStats() {
    const query = `
      SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'todo' THEN 1 ELSE 0 END) as todo,
        SUM(CASE WHEN status = 'in-progress' THEN 1 ELSE 0 END) as inProgress,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
        SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled,
        AVG(progress) as avgProgress
      FROM ${this.tableName} 
      WHERE isActive = TRUE
    `;

    try {
      const [rows] = await this.connection.execute(query);
      return rows[0];
    } catch (error) {
      console.error('❌ Error getting task stats:', error.message);
      throw error;
    }
  }
}

module.exports = TaskModel;