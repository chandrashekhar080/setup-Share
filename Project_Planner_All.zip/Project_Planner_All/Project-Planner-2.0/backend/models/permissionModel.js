const mongoose = require('mongoose');

const roleSchema = new mongoose.Schema(
  {
    uid: {
      type: String,
      required: false,
      unique: true
    },
    rolename: {
      type: String,
      required: false,
      unique: true
    },
    roledescription: {
      type: String,
      required: false,
    },
    rolepermission: {
      type: Array,
      required: true,
    },
    status: {
      type: String,
      enum: ['active', 'inactive'],
      default: 'active',
    }
  },
  {
    timestamps: true,
  }
);

const roles = mongoose.model('rolepermission', roleSchema);
module.exports = roles;
