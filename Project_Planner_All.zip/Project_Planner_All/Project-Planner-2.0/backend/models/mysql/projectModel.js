/**
 * Project Model for MySQL - Following same structure as MongoDB version
 */
class ProjectModel {
  constructor(connection) {
    this.connection = connection;
    this.tableName = "projects";
  }

  /**
   * Create projects table if not exists
   */
  async createTable() {
    const createTableQuery = `
      CREATE TABLE IF NOT EXISTS ${this.tableName} (
        id INT AUTO_INCREMENT PRIMARY KEY,
        uid VARCHAR(7) NOT NULL UNIQUE,
        projectName VARCHAR(100) NOT NULL UNIQUE,
        customer VARCHAR(100) NOT NULL,
        supervisor VARCHAR(100) NULL,
        startDate DATE NOT NULL,
        endDate DATE NOT NULL,
        duration INT NULL,
        projectDetails TEXT NULL,
        projectManager VARCHAR(100) NOT NULL,
        totalBudget DECIMAL(15,2) NOT NULL DEFAULT 0,
        allocatedFunds DECIMAL(15,2) NOT NULL DEFAULT 0,
        budgetNotes TEXT NULL,
        progress INT NOT NULL DEFAULT 0,
        milestone VARCHAR(500) NULL,
        followedByName VARCHAR(100) NULL,
        priority ENUM('low', 'medium', 'high', 'urgent') DEFAULT 'medium',
        statusNotes TEXT NULL,
        status ENUM('planning', 'in_progress', 'completed', 'on_hold', 'cancelled') DEFAULT 'planning',
        team JSON NULL,
        tags JSON NULL,
        attachments JSON NULL,
        lastUpdatedBy VARCHAR(100) NULL,
        createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        
        INDEX idx_customer_status (customer, status),
        INDEX idx_project_manager_status (projectManager, status),
        INDEX idx_priority_status (priority, status),
        INDEX idx_start_end_date (startDate, endDate),
        INDEX idx_uid (uid),
        INDEX idx_status (status),
        INDEX idx_progress (progress),
        INDEX idx_created_at (createdAt)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `;

    await this.connection.execute(createTableQuery);
  }

  /**
   * Create new project
   * @param {Object} projectData - Project data
   * @returns {Promise<Object>} Created project
   */
  async create(projectData) {
    await this.createTable(); // Ensure table exists

    const {
      uid,
      projectName,
      customer,
      supervisor = null,
      startDate,
      endDate,
      projectDetails = null,
      projectManager,
      totalBudget,
      allocatedFunds = 0,
      budgetNotes = null,
      progress = 0,
      milestone = null,
      followedByName = null,
      priority = "medium",
      statusNotes = null,
      status = "planning",
      team = null,
      tags = null,
      attachments = null,
      lastUpdatedBy = null,
    } = projectData;

    // Calculate duration
    const start = new Date(startDate);
    const end = new Date(endDate);
    const duration = Math.ceil((end - start) / (1000 * 60 * 60 * 24));

    const insertQuery = `
      INSERT INTO ${this.tableName} 
      (uid, projectName, customer, supervisor, startDate, endDate, duration, projectDetails, 
       projectManager, totalBudget, allocatedFunds, budgetNotes, progress, milestone, 
       followedByName, priority, statusNotes, status, team, tags, attachments, lastUpdatedBy)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const [result] = await this.connection.execute(insertQuery, [
      uid,
      projectName,
      customer,
      supervisor,
      startDate,
      endDate,
      duration,
      projectDetails,
      projectManager,
      totalBudget,
      allocatedFunds,
      budgetNotes,
      progress,
      milestone,
      followedByName,
      priority,
      statusNotes,
      status,
      team ? JSON.stringify(team) : null,
      tags ? JSON.stringify(tags) : null,
      attachments ? JSON.stringify(attachments) : null,
      lastUpdatedBy,
    ]);

    // Return created project
    return await this.findById(result.insertId);
  }

  /**
   * Find project by ID
   * @param {number} id - Project ID
   * @returns {Promise<Object|null>} Project object
   */
  async findById(id) {
    const query = `SELECT * FROM ${this.tableName} WHERE id = ?`;
    const [rows] = await this.connection.execute(query, [id]);

    if (rows.length === 0) return null;

    const project = rows[0];

    // Parse JSON fields
    if (project.team) project.team = JSON.parse(project.team);
    if (project.tags) project.tags = JSON.parse(project.tags);
    if (project.attachments)
      project.attachments = JSON.parse(project.attachments);

    // Add virtual fields
    project.remainingBudget = project.totalBudget - project.allocatedFunds;
    project.budgetUtilization =
      project.totalBudget > 0
        ? Math.round((project.allocatedFunds / project.totalBudget) * 100)
        : 0;
    project.durationDays = project.duration;

    // Calculate days remaining
    if (project.endDate) {
      const today = new Date();
      const endDate = new Date(project.endDate);
      const timeDiff = endDate.getTime() - today.getTime();
      project.daysRemaining = Math.ceil(timeDiff / (1000 * 60 * 60 * 24));
    }

    // Check if overdue
    project.isOverdue =
      project.status !== "completed" &&
      project.endDate &&
      new Date() > new Date(project.endDate);

    return project;
  }

  /**
   * Find project by UID
   * @param {string} uid - Project UID
   * @returns {Promise<Object|null>} Project object
   */
  async findByUID(uid) {
    const query = `SELECT * FROM ${this.tableName} WHERE uid = ?`;
    const [rows] = await this.connection.execute(query, [uid]);

    if (rows.length === 0) return null;

    return await this.findById(rows[0].id);
  }

  /**
   * Find all projects with optional filter
   * @param {Object} filter - Optional filter
   * @returns {Promise<Array>} Array of projects
   */
  async findAll(filter = {}) {
    let query = `SELECT * FROM ${this.tableName}`;
    const values = [];

    if (Object.keys(filter).length > 0) {
      const conditions = [];
      Object.keys(filter).forEach((key) => {
        conditions.push(`${key} = ?`);
        values.push(filter[key]);
      });
      query += ` WHERE ${conditions.join(" AND ")}`;
    }

    query += ` ORDER BY createdAt DESC`;

    const [rows] = await this.connection.execute(query, values);

    // Parse JSON fields and add virtual fields for each project
    return rows.map((project) => {
      if (project.team) project.team = JSON.parse(project.team);
      if (project.tags) project.tags = JSON.parse(project.tags);
      if (project.attachments)
        project.attachments = JSON.parse(project.attachments);

      // Add virtual fields
      project.remainingBudget = project.totalBudget - project.allocatedFunds;
      project.budgetUtilization =
        project.totalBudget > 0
          ? Math.round((project.allocatedFunds / project.totalBudget) * 100)
          : 0;
      project.durationDays = project.duration;

      // Calculate days remaining
      if (project.endDate) {
        const today = new Date();
        const endDate = new Date(project.endDate);
        const timeDiff = endDate.getTime() - today.getTime();
        project.daysRemaining = Math.ceil(timeDiff / (1000 * 60 * 60 * 24));
      }

      // Check if overdue
      project.isOverdue =
        project.status !== "completed" &&
        project.endDate &&
        new Date() > new Date(project.endDate);

      return project;
    });
  }

  /**
   * Update project by UID
   * @param {string} uid - Project UID
   * @param {Object} updateData - Update data
   * @returns {Promise<Object>} Update result
   */
  async updateByUID(uid, updateData) {
    const fields = [];
    const values = [];

    // Build dynamic update query
    Object.keys(updateData).forEach((key) => {
      if (
        ["team", "tags", "attachments"].includes(key) &&
        typeof updateData[key] === "object"
      ) {
        fields.push(`${key} = ?`);
        values.push(JSON.stringify(updateData[key]));
      } else {
        fields.push(`${key} = ?`);
        values.push(updateData[key]);
      }
    });

    // Recalculate duration if dates are updated
    if (updateData.startDate || updateData.endDate) {
      const project = await this.findByUID(uid);
      if (project) {
        const startDate = new Date(updateData.startDate || project.startDate);
        const endDate = new Date(updateData.endDate || project.endDate);
        const duration = Math.ceil(
          (endDate - startDate) / (1000 * 60 * 60 * 24)
        );
        fields.push("duration = ?");
        values.push(duration);
      }
    }

    // Auto-update progress based on status
    if (updateData.status) {
      if (updateData.status === "completed" && !updateData.progress) {
        fields.push("progress = ?");
        values.push(100);
      } else if (updateData.status === "planning" && !updateData.progress) {
        fields.push("progress = ?");
        values.push(0);
      }
    }

    values.push(uid); // Add UID for WHERE clause

    const updateQuery = `
      UPDATE ${this.tableName} 
      SET ${fields.join(", ")}, updatedAt = CURRENT_TIMESTAMP 
      WHERE uid = ?
    `;

    const [result] = await this.connection.execute(updateQuery, values);
    return result;
  }

  /**
   * Delete project by UID
   * @param {string} uid - Project UID
   * @returns {Promise<Object>} Delete result
   */
  async deleteByUID(uid) {
    const query = `DELETE FROM ${this.tableName} WHERE uid = ?`;
    const [result] = await this.connection.execute(query, [uid]);
    return result;
  }

  /**
   * Check if project exists by field
   * @param {Object} filter - Filter criteria
   * @returns {Promise<boolean>} True if exists
   */
  async exists(filter) {
    const field = Object.keys(filter)[0];
    const value = filter[field];

    const query = `SELECT COUNT(*) as count FROM ${this.tableName} WHERE ${field} = ?`;
    const [rows] = await this.connection.execute(query, [value]);

    return rows[0].count > 0;
  }

  /**
   * Find projects by priority
   * @param {string} priority - Project priority
   * @returns {Promise<Array>} Array of projects
   */
  async findByPriority(priority) {
    const query = `
      SELECT * FROM ${this.tableName} 
      WHERE priority = ? AND status != 'completed' 
      ORDER BY createdAt DESC
    `;
    const [rows] = await this.connection.execute(query, [priority]);

    return rows.map((project) => {
      if (project.team) project.team = JSON.parse(project.team);
      if (project.tags) project.tags = JSON.parse(project.tags);
      if (project.attachments)
        project.attachments = JSON.parse(project.attachments);
      return project;
    });
  }

  /**
   * Find overdue projects
   * @returns {Promise<Array>} Array of overdue projects
   */
  async findOverdue() {
    const today = new Date().toISOString().split("T")[0];
    const query = `
      SELECT * FROM ${this.tableName} 
      WHERE endDate < ? AND status NOT IN ('completed', 'cancelled')
      ORDER BY endDate ASC
    `;
    const [rows] = await this.connection.execute(query, [today]);

    return rows.map((project) => {
      if (project.team) project.team = JSON.parse(project.team);
      if (project.tags) project.tags = JSON.parse(project.tags);
      if (project.attachments)
        project.attachments = JSON.parse(project.attachments);
      return project;
    });
  }

  /**
   * Update project progress
   * @param {string} uid - Project UID
   * @param {number} newProgress - New progress value
   * @returns {Promise<Object>} Update result
   */
  async updateProgress(uid, newProgress) {
    if (newProgress < 0 || newProgress > 100) {
      throw new Error("Progress must be between 0 and 100");
    }

    const updateData = { progress: newProgress };

    // Auto-update status based on progress
    if (newProgress === 100) {
      updateData.status = "completed";
    } else if (newProgress > 0) {
      const project = await this.findByUID(uid);
      if (project && project.status === "planning") {
        updateData.status = "in_progress";
      }
    }

    return await this.updateByUID(uid, updateData);
  }

  /**
   * Get project statistics
   * @returns {Promise<Array>} Project statistics
   */
  async getProjectStats() {
    const query = `
      SELECT 
        status,
        COUNT(*) as count,
        SUM(totalBudget) as totalBudget,
        AVG(progress) as averageProgress
      FROM ${this.tableName}
      GROUP BY status
    `;

    const [rows] = await this.connection.execute(query);

    const total = rows.reduce((sum, row) => sum + row.count, 0);
    const totalBudget = rows.reduce(
      (sum, row) => sum + (row.totalBudget || 0),
      0
    );

    return [
      {
        _id: null,
        total,
        totalBudget,
        statusBreakdown: rows.map((row) => ({
          status: row.status,
          count: row.count,
          totalBudget: row.totalBudget || 0,
          averageProgress: Math.round(row.averageProgress || 0),
        })),
      },
    ];
  }

  /**
   * Add team member to project
   * @param {string} uid - Project UID
   * @param {Object} member - Team member data
   * @returns {Promise<Object>} Update result
   */
  async addTeamMember(uid, member) {
    const project = await this.findByUID(uid);
    if (!project) throw new Error("Project not found");

    const team = project.team || [];
    team.push(member);

    return await this.updateByUID(uid, { team });
  }

  /**
   * Remove team member from project
   * @param {string} uid - Project UID
   * @param {number} memberIndex - Team member index
   * @returns {Promise<Object>} Update result
   */
  async removeTeamMember(uid, memberIndex) {
    const project = await this.findByUID(uid);
    if (!project) throw new Error("Project not found");

    const team = project.team || [];
    if (memberIndex >= 0 && memberIndex < team.length) {
      team.splice(memberIndex, 1);
      return await this.updateByUID(uid, { team });
    }
    throw new Error("Invalid team member index");
  }

  /**
   * Delete all projects (for development/testing)
   * @returns {Promise<Object>} Delete result
   */
  async deleteAll() {
    const query = `DELETE FROM ${this.tableName}`;
    const [result] = await this.connection.execute(query);
    return result;
  }
}

module.exports = ProjectModel;
