const bcrypt = require("bcrypt");

/**
 * User Model for MySQL - Following same structure as MongoDB version
 */
class UserModel {
  constructor(connection) {
    this.connection = connection;
    this.tableName = "users";
  }

  /**
   * Create users table if not exists
   */
  async createTable() {
    const createTableQuery = `
      CREATE TABLE IF NOT EXISTS ${this.tableName} (
        id INT AUTO_INCREMENT PRIMARY KEY,
        uid VARCHAR(7) NOT NULL UNIQUE,
        email VARCHAR(255) NOT NULL UNIQUE,
        name VARCHAR(50) NOT NULL,
        password VARCHAR(255) NOT NULL,
        subdomain VARCHAR(20) NOT NULL UNIQUE,
        logo VARCHAR(255) NULL,
        role ENUM('user', 'admin', 'manager', 'viewer') DEFAULT 'user',
        status ENUM('active', 'inactive', 'pending', 'suspended') DEFAULT 'active',
        emailVerified BOOLEAN DEFAULT FALSE,
        emailVerificationToken VARCHAR(255) NULL,
        passwordResetToken VARCHAR(255) NULL,
        passwordResetExpires DATETIME NULL,
        lastLogin DATETIME NULL,
        loginAttempts INT DEFAULT 0,
        lockUntil DATETIME NULL,
        preferences JSON NULL,
        createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        
        INDEX idx_email_status (email, status),
        INDEX idx_subdomain_status (subdomain, status),
        INDEX idx_uid (uid),
        INDEX idx_status (status),
        INDEX idx_created_at (createdAt)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `;

    await this.connection.execute(createTableQuery);
  }

  /**
   * Create new user
   * @param {Object} userData - User data
   * @returns {Promise<Object>} Created user
   */
  async create(userData) {
    await this.createTable(); // Ensure table exists

    const {
      uid,
      email,
      name,
      password,
      subdomain,
      logo = null,
      role = "user",
      status = "active",
      emailVerified = false,
      preferences = null,
    } = userData;

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 12);

    const insertQuery = `
      INSERT INTO ${this.tableName} 
      (uid, email, name, password, subdomain, logo, role, status, emailVerified, preferences)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const [result] = await this.connection.execute(insertQuery, [
      uid,
      email,
      name,
      hashedPassword,
      subdomain,
      logo,
      role,
      status,
      emailVerified,
      preferences ? JSON.stringify(preferences) : null,
    ]);

    // Return created user (without password)
    return await this.findById(result.insertId);
  }

  /**
   * Find user by ID
   * @param {number} id - User ID
   * @returns {Promise<Object|null>} User object
   */
  async findById(id) {
    const query = `SELECT * FROM ${this.tableName} WHERE id = ?`;
    const [rows] = await this.connection.execute(query, [id]);

    if (rows.length === 0) return null;

    const user = rows[0];
    delete user.password; // Remove password from response

    // Parse JSON fields
    if (user.preferences) {
      user.preferences = JSON.parse(user.preferences);
    }

    return user;
  }

  /**
   * Find user by UID
   * @param {string} uid - User UID
   * @returns {Promise<Object|null>} User object
   */
  async findByUID(uid) {
    const query = `SELECT * FROM ${this.tableName} WHERE uid = ?`;
    const [rows] = await this.connection.execute(query, [uid]);

    if (rows.length === 0) return null;

    const user = rows[0];
    delete user.password; // Remove password from response

    // Parse JSON fields
    if (user.preferences) {
      user.preferences = JSON.parse(user.preferences);
    }

    return user;
  }

  /**
   * Find user by email
   * @param {string} email - User email
   * @returns {Promise<Object|null>} User object
   */
  async findByEmail(email) {
    const query = `SELECT * FROM ${this.tableName} WHERE email = ?`;
    const [rows] = await this.connection.execute(query, [email]);

    if (rows.length === 0) return null;

    const user = rows[0];

    // Parse JSON fields
    if (user.preferences) {
      user.preferences = JSON.parse(user.preferences);
    }

    return user;
  }

  /**
   * Find user by email and active status
   * @param {string} email - User email
   * @returns {Promise<Object|null>} User object
   */
  async findByEmailAndActive(email) {
    const query = `SELECT * FROM ${this.tableName} WHERE email = ? AND status = 'active'`;
    const [rows] = await this.connection.execute(query, [email]);

    if (rows.length === 0) return null;

    const user = rows[0];

    // Parse JSON fields
    if (user.preferences) {
      user.preferences = JSON.parse(user.preferences);
    }

    return user;
  }

  /**
   * Find user by subdomain
   * @param {string} subdomain - User subdomain
   * @returns {Promise<Object|null>} User object
   */
  async findBySubdomain(subdomain) {
    const query = `SELECT * FROM ${this.tableName} WHERE subdomain = ?`;
    const [rows] = await this.connection.execute(query, [subdomain]);

    if (rows.length === 0) return null;

    const user = rows[0];
    delete user.password; // Remove password from response

    // Parse JSON fields
    if (user.preferences) {
      user.preferences = JSON.parse(user.preferences);
    }

    return user;
  }

  /**
   * Find user by subdomain and active status
   * @param {string} subdomain - User subdomain
   * @returns {Promise<Object|null>} User object
   */
  async findBySubdomainAndActive(subdomain) {
    const query = `SELECT * FROM ${this.tableName} WHERE subdomain = ? AND status = 'active'`;
    const [rows] = await this.connection.execute(query, [subdomain]);

    if (rows.length === 0) return null;

    const user = rows[0];
    delete user.password; // Remove password from response

    // Parse JSON fields
    if (user.preferences) {
      user.preferences = JSON.parse(user.preferences);
    }

    return user;
  }

  /**
   * Update user by UID
   * @param {string} uid - User UID
   * @param {Object} updateData - Update data
   * @returns {Promise<Object>} Update result
   */
  async updateByUID(uid, updateData) {
    const fields = [];
    const values = [];

    // Build dynamic update query
    Object.keys(updateData).forEach((key) => {
      if (key === "password") {
        // Hash password if being updated
        fields.push(`${key} = ?`);
        values.push(bcrypt.hashSync(updateData[key], 12));
      } else if (key === "preferences" && typeof updateData[key] === "object") {
        fields.push(`${key} = ?`);
        values.push(JSON.stringify(updateData[key]));
      } else {
        fields.push(`${key} = ?`);
        values.push(updateData[key]);
      }
    });

    values.push(uid); // Add UID for WHERE clause

    const updateQuery = `
      UPDATE ${this.tableName} 
      SET ${fields.join(", ")}, updatedAt = CURRENT_TIMESTAMP 
      WHERE uid = ?
    `;

    const [result] = await this.connection.execute(updateQuery, values);
    return result;
  }

  /**
   * Delete user by UID
   * @param {string} uid - User UID
   * @returns {Promise<Object>} Delete result
   */
  async deleteByUID(uid) {
    const query = `DELETE FROM ${this.tableName} WHERE uid = ?`;
    const [result] = await this.connection.execute(query, [uid]);
    return result;
  }

  /**
   * Check if user exists by field
   * @param {Object} filter - Filter criteria
   * @returns {Promise<boolean>} True if exists
   */
  async exists(filter) {
    const field = Object.keys(filter)[0];
    const value = filter[field];

    const query = `SELECT COUNT(*) as count FROM ${this.tableName} WHERE ${field} = ?`;
    const [rows] = await this.connection.execute(query, [value]);

    return rows[0].count > 0;
  }

  /**
   * Compare password
   * @param {string} candidatePassword - Password to compare
   * @param {string} hashedPassword - Hashed password from database
   * @returns {Promise<boolean>} True if passwords match
   */
  async comparePassword(candidatePassword, hashedPassword) {
    return await bcrypt.compare(candidatePassword, hashedPassword);
  }

  /**
   * Increment login attempts
   * @param {string} uid - User UID
   * @returns {Promise<Object>} Update result
   */
  async incLoginAttempts(uid) {
    // Check current attempts and lock status
    const user = await this.findByUID(uid);
    if (!user) throw new Error("User not found");

    let updateData = {};

    // If lock has expired, reset attempts
    if (user.lockUntil && new Date(user.lockUntil) < new Date()) {
      updateData = {
        loginAttempts: 1,
        lockUntil: null,
      };
    } else {
      const newAttempts = (user.loginAttempts || 0) + 1;
      updateData.loginAttempts = newAttempts;

      // Lock account after 5 failed attempts for 2 hours
      if (newAttempts >= 5 && !user.lockUntil) {
        const lockUntil = new Date();
        lockUntil.setHours(lockUntil.getHours() + 2);
        updateData.lockUntil = lockUntil;
      }
    }

    return await this.updateByUID(uid, updateData);
  }

  /**
   * Reset login attempts
   * @param {string} uid - User UID
   * @returns {Promise<Object>} Update result
   */
  async resetLoginAttempts(uid) {
    const updateData = {
      loginAttempts: 0,
      lockUntil: null,
      lastLogin: new Date(),
    };

    return await this.updateByUID(uid, updateData);
  }

  /**
   * Find all users with optional filter
   * @param {Object} filter - Optional filter
   * @returns {Promise<Array>} Array of users
   */
  async findAll(filter = {}) {
    let query = `SELECT * FROM ${this.tableName}`;
    const values = [];

    if (Object.keys(filter).length > 0) {
      const conditions = [];
      Object.keys(filter).forEach((key) => {
        conditions.push(`${key} = ?`);
        values.push(filter[key]);
      });
      query += ` WHERE ${conditions.join(" AND ")}`;
    }

    query += ` ORDER BY createdAt DESC`;

    const [rows] = await this.connection.execute(query, values);

    // Remove passwords and parse JSON fields
    return rows.map((user) => {
      delete user.password;
      if (user.preferences) {
        user.preferences = JSON.parse(user.preferences);
      }
      return user;
    });
  }

  /**
   * Delete all users (for development/testing)
   * @returns {Promise<Object>} Delete result
   */
  async deleteAll() {
    const query = `DELETE FROM ${this.tableName}`;
    const [result] = await this.connection.execute(query);
    return result;
  }

  /**
   * Get user statistics
   * @returns {Promise<Array>} User statistics
   */
  async getUserStats() {
    const query = `
      SELECT 
        status,
        COUNT(*) as count
      FROM ${this.tableName}
      GROUP BY status
    `;

    const [rows] = await this.connection.execute(query);

    const total = rows.reduce((sum, row) => sum + row.count, 0);

    return [
      {
        _id: null,
        total,
        statusBreakdown: rows.map((row) => ({
          status: row.status,
          count: row.count,
        })),
      },
    ];
  }
}

module.exports = UserModel;
