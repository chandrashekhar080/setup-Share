const mongoose = require('mongoose');

const adminSchema = new mongoose.Schema(
  {
    uid: {
      type: String,
      required: false,
      unique: true
    },
    email: {
      type: String,
      required: false,
      unique: true
    },
    password: {
      type: mongoose.Schema.Types.Mixed,
      required: false,
    }
  },
  {
    timestamps: true,
  }
);

const admin = mongoose.model('admin', adminSchema);
module.exports = admin;
