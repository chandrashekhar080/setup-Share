const mongoose = require('mongoose');

/**
 * Enhanced Timesheet Model - Following SOLID principles with proper validation
 */
const timesheetSchema = new mongoose.Schema(
  {
    uid: {
      type: String,
      required: true,
      unique: true,
      index: true,
      validate: {
        validator: function(v) {
          return /^\d{7}$/.test(v);
        },
        message: 'UID must be a 7-digit number string'
      }
    },
    project: {
      type: String,
      required: true,
      validate: {
        validator: function(v) {
          return /^\d{7}$/.test(v);
        },
        message: 'Project UID must be a 7-digit number string'
      },
      index: true
    },
    task: {
      type: String,
      required: false,
      validate: {
        validator: function(v) {
          return !v || /^\d{7}$/.test(v);
        },
        message: 'Task UID must be a 7-digit number string'
      },
      index: true
    },
    member: {
      type: String,
      required: true,
      trim: true,
      minlength: [2, 'Member name must be at least 2 characters long'],
      maxlength: [100, 'Member name cannot exceed 100 characters'],
      index: true
    },
    startDate: {
      type: Date,
      required: true,
      index: true
    },
    endDate: {
      type: Date,
      required: false,
      validate: {
        validator: function(v) {
          if (!v) return true; // endDate is optional
          return v > this.startDate;
        },
        message: 'End date must be after start date'
      }
    },
    hoursWorked: {
      type: Number,
      required: false,
      min: [0, 'Hours worked cannot be negative'],
      max: [24, 'Hours worked cannot exceed 24 hours per day'],
      default: 0
    },
    description: {
      type: String,
      required: false,
      trim: true,
      maxlength: [1000, 'Description cannot exceed 1000 characters']
    },
    billableHours: {
      type: Number,
      required: false,
      min: [0, 'Billable hours cannot be negative'],
      max: [24, 'Billable hours cannot exceed 24 hours per day'],
      default: 0
    },
    hourlyRate: {
      type: Number,
      required: false,
      min: [0, 'Hourly rate cannot be negative'],
      default: 0
    },
    status: {
      type: String,
      enum: ['draft', 'submitted', 'approved', 'rejected', 'paid'],
      default: 'draft',
      required: true,
      index: true
    },
    approvedBy: {
      type: String,
      required: false,
      trim: true
    },
    approvedAt: {
      type: Date,
      required: false
    },
    rejectionReason: {
      type: String,
      required: false,
      trim: true,
      maxlength: [500, 'Rejection reason cannot exceed 500 characters']
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true
    },
    createdBy: {
      type: String,
      required: false,
      trim: true,
      default: 'system'
    },
    lastUpdatedBy: {
      type: String,
      required: false,
      trim: true
    }
  },
  {
    timestamps: true,
    toJSON: {
      virtuals: true,
      transform: function(doc, ret) {
        // Format dates for frontend
        if (ret.startDate) ret.startDate = ret.startDate.toISOString().split('T')[0];
        if (ret.endDate) ret.endDate = ret.endDate.toISOString().split('T')[0];
        if (ret.approvedAt) ret.approvedAt = ret.approvedAt.toISOString().split('T')[0];
        return ret;
      }
    },
    toObject: { virtuals: true }
  }
);

// Indexes for better performance
timesheetSchema.index({ project: 1, member: 1 });
timesheetSchema.index({ task: 1, member: 1 });
timesheetSchema.index({ startDate: 1, endDate: 1 });
timesheetSchema.index({ status: 1, createdAt: -1 });
timesheetSchema.index({ member: 1, startDate: -1 });

// Virtual for total earnings
timesheetSchema.virtual('totalEarnings').get(function() {
  if (!this.billableHours || !this.hourlyRate) return 0;
  return this.billableHours * this.hourlyRate;
});

// Virtual for duration in hours
timesheetSchema.virtual('durationHours').get(function() {
  if (!this.startDate || !this.endDate) return 0;
  const diffMs = this.endDate.getTime() - this.startDate.getTime();
  return Math.round((diffMs / (1000 * 60 * 60)) * 100) / 100; // Round to 2 decimal places
});

// Virtual for efficiency (billable vs worked hours)
timesheetSchema.virtual('efficiency').get(function() {
  if (!this.hoursWorked || this.hoursWorked === 0) return 0;
  return Math.round((this.billableHours / this.hoursWorked) * 100);
});

// Pre-save middleware to auto-calculate hours if not provided
timesheetSchema.pre('save', function(next) {
  // Auto-calculate hours worked if not provided and we have start/end dates
  if (!this.hoursWorked && this.startDate && this.endDate) {
    const diffMs = this.endDate.getTime() - this.startDate.getTime();
    this.hoursWorked = Math.round((diffMs / (1000 * 60 * 60)) * 100) / 100;
  }
  
  // Set billable hours to worked hours if not specified
  if (!this.billableHours && this.hoursWorked) {
    this.billableHours = this.hoursWorked;
  }
  
  // Set approval timestamp when status changes to approved
  if (this.isModified('status') && this.status === 'approved' && !this.approvedAt) {
    this.approvedAt = new Date();
  }
  
  next();
});

// Static method to find timesheets by project
timesheetSchema.statics.findByProject = function(projectUid) {
  return this.find({ project: projectUid, isActive: true }).sort({ startDate: -1 });
};

// Static method to find timesheets by member
timesheetSchema.statics.findByMember = function(member) {
  return this.find({ 
    member: new RegExp(member, 'i'),
    isActive: true 
  }).sort({ startDate: -1 });
};

// Static method to find timesheets by task
timesheetSchema.statics.findByTask = function(taskUid) {
  return this.find({ task: taskUid, isActive: true }).sort({ startDate: -1 });
};

// Static method to get timesheet statistics
timesheetSchema.statics.getTimesheetStats = function(filters = {}) {
  const matchQuery = { isActive: true, ...filters };
  
  return this.aggregate([
    { $match: matchQuery },
    {
      $group: {
        _id: '$status',
        count: { $sum: 1 },
        totalHours: { $sum: '$hoursWorked' },
        totalBillableHours: { $sum: '$billableHours' },
        totalEarnings: { $sum: { $multiply: ['$billableHours', '$hourlyRate'] } }
      }
    },
    {
      $group: {
        _id: null,
        total: { $sum: '$count' },
        totalHours: { $sum: '$totalHours' },
        totalBillableHours: { $sum: '$totalBillableHours' },
        totalEarnings: { $sum: '$totalEarnings' },
        statusBreakdown: {
          $push: {
            status: '$_id',
            count: '$count',
            totalHours: '$totalHours',
            totalBillableHours: '$totalBillableHours',
            totalEarnings: '$totalEarnings'
          }
        }
      }
    }
  ]);
};

// Instance method to approve timesheet
timesheetSchema.methods.approve = function(approvedBy) {
  this.status = 'approved';
  this.approvedBy = approvedBy;
  this.approvedAt = new Date();
  return this.save();
};

// Instance method to reject timesheet
timesheetSchema.methods.reject = function(rejectedBy, reason) {
  this.status = 'rejected';
  this.approvedBy = rejectedBy;
  this.rejectionReason = reason;
  return this.save();
};

const Timesheet = mongoose.model('timesheet', timesheetSchema);
module.exports = Timesheet;
