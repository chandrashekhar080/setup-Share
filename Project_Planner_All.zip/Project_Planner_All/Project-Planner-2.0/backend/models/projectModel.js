const mongoose = require('mongoose');

/**
 * Project Model - Following SOLID principles with proper validation and methods
 */
const projectSchema = new mongoose.Schema(
  {
    uid: {
      type: String,
      required: true,
      unique: true,
      index: true,
      validate: {
        validator: function(v) {
          return /^\d{7}$/.test(v);
        },
        message: 'UID must be a 7-digit number string'
      }
    },
    projectName: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      minlength: [3, 'Project name must be at least 3 characters long'],
      maxlength: [100, 'Project name cannot exceed 100 characters'],
      index: true
    },
    customer: {
      type: String,
      required: true,
      trim: true,
      minlength: [2, 'Customer name must be at least 2 characters long'],
      maxlength: [100, 'Customer name cannot exceed 100 characters'],
      index: true
    },
    supervisor: {
      type: String,
      required: false,
      trim: true,
      maxlength: [100, 'Supervisor name cannot exceed 100 characters']
    },
    startDate: {
      type: Date,
      required: true,
      validate: {
        validator: function(v) {
          return v instanceof Date && !isNaN(v);
        },
        message: 'Start date must be a valid date'
      }
    },
    endDate: {
      type: Date,
      required: true,
      validate: {
        validator: function(v) {
          return v instanceof Date && !isNaN(v) && v > this.startDate;
        },
        message: 'End date must be after start date'
      }
    },
    duration: {
      type: Number, // Duration in days
      min: [1, 'Duration must be at least 1 day'],
      max: [3650, 'Duration cannot exceed 10 years'] // 10 years max
    },
    projectDetails: {
      type: String,
      required: false,
      trim: true,
      maxlength: [2000, 'Project details cannot exceed 2000 characters']
    },
    projectManager: {
      type: String,
      required: true,
      trim: true,
      maxlength: [100, 'Project manager name cannot exceed 100 characters'],
      index: true
    },
    totalBudget: {
      type: Number,
      required: true,
      min: [0, 'Total budget cannot be negative'],
      validate: {
        validator: function(v) {
          return Number.isFinite(v) && v >= 0;
        },
        message: 'Total budget must be a valid positive number'
      }
    },
    allocatedFunds: {
      type: Number,
      required: false,
      default: 0,
      min: [0, 'Allocated funds cannot be negative'],
      validate: {
        validator: function(v) {
          return Number.isFinite(v) && v >= 0 && v <= this.totalBudget;
        },
        message: 'Allocated funds cannot exceed total budget'
      }
    },
    budgetNotes: {
      type: String,
      required: false,
      trim: true,
      maxlength: [1000, 'Budget notes cannot exceed 1000 characters']
    },
    progress: {
      type: Number,
      required: false,
      default: 0,
      min: [0, 'Progress cannot be less than 0%'],
      max: [100, 'Progress cannot exceed 100%'],
      index: true
    },
    milestone: {
      type: String,
      required: false,
      trim: true,
      maxlength: [500, 'Milestone cannot exceed 500 characters']
    },
    followedByName: {
      type: String,
      required: false,
      trim: true,
      maxlength: [100, 'Followed by name cannot exceed 100 characters']
    },
    priority: {
      type: String,
      enum: ['low', 'medium', 'high', 'urgent'],
      default: 'medium',
      required: true,
      index: true
    },
    statusNotes: {
      type: String,
      required: false,
      trim: true,
      maxlength: [1000, 'Status notes cannot exceed 1000 characters']
    },
    status: {
      type: String,
      enum: ['planning', 'in_progress', 'completed', 'on_hold', 'cancelled'],
      default: 'planning',
      required: true,
      index: true
    },
    team: [{
      name: {
        type: String,
        required: true,
        trim: true
      },
      role: {
        type: String,
        required: true,
        trim: true
      },
      email: {
        type: String,
        required: false,
        validate: {
          validator: function(v) {
            return !v || /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/.test(v);
          },
          message: 'Please enter a valid email address'
        }
      }
    }],
    tags: [{
      type: String,
      trim: true,
      lowercase: true
    }],
    attachments: [{
      filename: String,
      originalName: String,
      mimeType: String,
      size: Number,
      uploadDate: { type: Date, default: Date.now }
    }],
    lastUpdatedBy: {
      type: String,
      required: false
    }
  },
  {
    timestamps: true,
    toJSON: {
      virtuals: true,
      transform: function(doc, ret) {
        // Format dates for frontend
        if (ret.startDate) ret.startDate = ret.startDate.toISOString().split('T')[0];
        if (ret.endDate) ret.endDate = ret.endDate.toISOString().split('T')[0];
        return ret;
      }
    },
    toObject: { virtuals: true }
  }
);

// Indexes for better performance
projectSchema.index({ customer: 1, status: 1 });
projectSchema.index({ projectManager: 1, status: 1 });
projectSchema.index({ priority: 1, status: 1 });
projectSchema.index({ startDate: 1, endDate: 1 });
projectSchema.index({ createdAt: -1 });
projectSchema.index({ tags: 1 });

// Virtual for remaining budget
projectSchema.virtual('remainingBudget').get(function() {
  return this.totalBudget - (this.allocatedFunds || 0);
});

// Virtual for budget utilization percentage
projectSchema.virtual('budgetUtilization').get(function() {
  if (!this.totalBudget) return 0;
  return Math.round(((this.allocatedFunds || 0) / this.totalBudget) * 100);
});

// Virtual for project duration in days
projectSchema.virtual('durationDays').get(function() {
  if (!this.startDate || !this.endDate) return 0;
  return Math.ceil((this.endDate - this.startDate) / (1000 * 60 * 60 * 24));
});

// Virtual for days remaining
projectSchema.virtual('daysRemaining').get(function() {
  if (!this.endDate) return null;
  const today = new Date();
  const timeDiff = this.endDate.getTime() - today.getTime();
  return Math.ceil(timeDiff / (1000 * 60 * 60 * 24));
});

// Virtual for project status summary
projectSchema.virtual('isOverdue').get(function() {
  if (this.status === 'completed') return false;
  return this.endDate && new Date() > this.endDate;
});

// Pre-save middleware to calculate duration
projectSchema.pre('save', function(next) {
  if (this.startDate && this.endDate) {
    const timeDiff = this.endDate.getTime() - this.startDate.getTime();
    this.duration = Math.ceil(timeDiff / (1000 * 60 * 60 * 24));
  }
  next();
});

// Pre-save middleware to update progress based on status
projectSchema.pre('save', function(next) {
  if (this.isModified('status')) {
    switch (this.status) {
      case 'planning':
        if (!this.progress) this.progress = 0;
        break;
      case 'completed':
        this.progress = 100;
        break;
      case 'cancelled':
        // Keep current progress
        break;
    }
  }
  next();
});

// Static method to get project statistics
projectSchema.statics.getProjectStats = function() {
  return this.aggregate([
    {
      $group: {
        _id: '$status',
        count: { $sum: 1 },
        totalBudget: { $sum: '$totalBudget' },
        averageProgress: { $avg: '$progress' }
      }
    },
    {
      $group: {
        _id: null,
        total: { $sum: '$count' },
        totalBudget: { $sum: '$totalBudget' },
        statusBreakdown: {
          $push: {
            status: '$_id',
            count: '$count',
            totalBudget: '$totalBudget',
            averageProgress: '$averageProgress'
          }
        }
      }
    }
  ]);
};

// Static method to find projects by priority
projectSchema.statics.findByPriority = function(priority) {
  return this.find({ priority, status: { $ne: 'completed' } }).sort({ createdAt: -1 });
};

// Static method to find overdue projects
projectSchema.statics.findOverdue = function() {
  const today = new Date();
  return this.find({
    endDate: { $lt: today },
    status: { $nin: ['completed', 'cancelled'] }
  }).sort({ endDate: 1 });
};

// Instance method to add team member
projectSchema.methods.addTeamMember = function(member) {
  this.team.push(member);
  return this.save();
};

// Instance method to remove team member
projectSchema.methods.removeTeamMember = function(memberIndex) {
  if (memberIndex >= 0 && memberIndex < this.team.length) {
    this.team.splice(memberIndex, 1);
    return this.save();
  }
  throw new Error('Invalid team member index');
};

// Instance method to update progress
projectSchema.methods.updateProgress = function(newProgress) {
  if (newProgress < 0 || newProgress > 100) {
    throw new Error('Progress must be between 0 and 100');
  }
  
  this.progress = newProgress;
  
  // Auto-update status based on progress
  if (newProgress === 100 && this.status !== 'completed') {
    this.status = 'completed';
  } else if (newProgress > 0 && this.status === 'planning') {
    this.status = 'in_progress';
  }
  
  return this.save();
};

const Project = mongoose.model('Project', projectSchema);

module.exports = Project;