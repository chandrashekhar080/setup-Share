# MongoDB to MySQL Migration Guide

## 🎯 Migration Summary

This project has been successfully migrated from **MongoDB** to **MySQL** while maintaining:

- ✅ **Exact same API structure**
- ✅ **Same request/response format**
- ✅ **Dynamic multi-tenant database support**
- ✅ **All existing functionality**
- ✅ **Clean ApiResponse hook implementation**

## 🔄 What Changed

### 1. **Database Layer**

- **Before**: MongoDB with Mongoose
- **After**: MySQL with mysql2/promise
- **Dynamic Connections**: Now uses MySQL databases instead of MongoDB

### 2. **Response Format**

- **Before**: ResponseFormatter utility
- **After**: ApiResponse hook (cleaner syntax)

```javascript
// Old way
const formatted = ResponseFormatter.success("Message", data);
return res.status(formatted.statusCode).json(formatted.response);

// New way
return ApiResponse.success(res, data, "Message");
```

### 3. **Models**

- **Before**: Mongoose schemas in `models/`
- **After**: MySQL model classes in `models/mysql/`
- **Same Methods**: All model methods work identically

### 4. **Configuration**

- **Added**: MySQL configuration in AppConfig.js
- **Added**: MySQL connection management
- **Maintained**: Same environment variable structure

## 📁 New Files Created

```
Server/
├── config/
│   ├── mysql.js              # Main MySQL connection
│   └── dynamicmysql.js       # Multi-tenant MySQL connections
├── models/mysql/
│   ├── userModel.js          # MySQL User model
│   └── projectModel.js       # MySQL Project model
├── utils/
│   └── ApiResponse.js        # New response hook
├── test-mysql.js             # MySQL connection test
└── MYSQL_MIGRATION.md        # This documentation
```

## 🔧 Environment Variables

Add these to your `.env` file:

```env
# MySQL Configuration
MYSQL_HOST=localhost
MYSQL_PORT=3306
MYSQL_USER=root
MYSQL_PASSWORD=your-mysql-password
MYSQL_DATABASE=projectplanner
```

## 🚀 How to Run

### 1. **Install Dependencies**

```bash
npm install
```

### 2. **Setup MySQL Database**

```sql
CREATE DATABASE projectplanner;
-- Tables will be created automatically
```

### 3. **Configure Environment**

```bash
cp .env.example .env
# Edit .env with your MySQL credentials
```

### 4. **Test MySQL Connection**

```bash
node test-mysql.js
```

### 5. **Start Server**

```bash
npm run dev
```

## 🔄 Multi-Tenant Architecture

The system maintains the same multi-tenant architecture:

### **Before (MongoDB)**

```javascript
// Different MongoDB databases per tenant
mongodb://localhost:27017/tenant1
mongodb://localhost:27017/tenant2
```

### **After (MySQL)**

```javascript
// Different MySQL databases per tenant
mysql://localhost:3306/tenant1
mysql://localhost:3306/tenant2
```

### **Usage in Code**

```javascript
// Same usage - no changes needed
const dbConnection = await connectdyDB(user.subdomain);
```

## 📊 Database Schema

### **User Table**

```sql
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  uid VARCHAR(7) NOT NULL UNIQUE,
  email VARCHAR(255) NOT NULL UNIQUE,
  name VARCHAR(50) NOT NULL,
  password VARCHAR(255) NOT NULL,
  subdomain VARCHAR(20) NOT NULL UNIQUE,
  logo VARCHAR(255) NULL,
  role ENUM('user', 'admin', 'manager', 'viewer') DEFAULT 'user',
  status ENUM('active', 'inactive', 'pending', 'suspended') DEFAULT 'active',
  -- ... other fields
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### **Project Table**

```sql
CREATE TABLE projects (
  id INT AUTO_INCREMENT PRIMARY KEY,
  uid VARCHAR(7) NOT NULL UNIQUE,
  projectName VARCHAR(100) NOT NULL UNIQUE,
  customer VARCHAR(100) NOT NULL,
  -- ... other fields
  team JSON NULL,
  tags JSON NULL,
  attachments JSON NULL,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

## 🎯 API Endpoints (Unchanged)

All API endpoints work exactly the same:

```javascript
POST /auth/register/signup
POST /auth/login
GET  /project/
POST /project/
PUT  /project/:id
DELETE /project/:id
// ... all other endpoints unchanged
```

## 🔒 Security Features (Maintained)

- ✅ JWT Authentication
- ✅ Password hashing with bcrypt
- ✅ Input validation
- ✅ SQL injection prevention (parameterized queries)
- ✅ Role-based access control
- ✅ Account lockout mechanism

## 🧪 Testing

### **Test MySQL Connection**

```bash
node test-mysql.js
```

### **Test API Endpoints**

```bash
# Start server
npm run dev

# Test health endpoint
curl http://localhost:5000/health

# Test root endpoint
curl http://localhost:5000/
```

## 🔄 Migration Benefits

### **Performance**

- ✅ Better query performance with proper indexing
- ✅ ACID compliance
- ✅ Better concurrent access handling

### **Scalability**

- ✅ Horizontal scaling with read replicas
- ✅ Better connection pooling
- ✅ Optimized for high-traffic applications

### **Reliability**

- ✅ ACID transactions
- ✅ Better data consistency
- ✅ Mature ecosystem

## 🚨 Important Notes

### **Backward Compatibility**

- ✅ All existing API calls work unchanged
- ✅ Same request/response format
- ✅ Same authentication flow
- ✅ Same error handling

### **Data Migration**

If you have existing MongoDB data, you'll need to:

1. Export data from MongoDB
2. Transform to MySQL format
3. Import to MySQL tables

### **Development vs Production**

- **Development**: Tables created automatically
- **Production**: Run proper migrations
- **Backup**: Always backup before migration

## 📞 Support

If you encounter any issues:

1. Check MySQL connection settings
2. Verify database permissions
3. Run the test script: `node test-mysql.js`
4. Check server logs for detailed error messages

## ✨ Success Indicators

You'll know the migration is successful when:

- ✅ `node test-mysql.js` passes all tests
- ✅ Server starts without errors
- ✅ `/health` endpoint shows "Connected"
- ✅ API endpoints respond normally
- ✅ User registration/login works
- ✅ Multi-tenant functionality works

---

**🎉 Migration Complete!** Your application now runs on MySQL with the same functionality and API structure.
