const ApiResponse = require("../utils/ApiResponse");

/**
 * Validation Middleware - Centralized validation logic
 * Following Single Responsibility Principle
 */
class ValidationMiddleware {
  /**
   * Generic validation middleware factory
   * @param {Function} validator - Validator function
   * @param {string} source - Source of data ('body', 'query', 'params')
   * @returns {Function} Express middleware
   */
  static validate(validator, source = "body") {
    return (req, res, next) => {
      try {
        const data = req[source];
        const errors = validator(data);

        if (errors.length > 0) {
          return ApiResponse.validationError(res, errors);
        }

        next();
      } catch (error) {
        console.error("Validation middleware error:", error);
        return ApiResponse.serverError(res, "Validation failed");
      }
    };
  }

  /**
   * Sanitize and trim string fields
   * @param {Array} fields - Fields to sanitize
   * @param {string} source - Source of data
   * @returns {Function} Express middleware
   */
  static sanitize(fields, source = "body") {
    return (req, res, next) => {
      try {
        const data = req[source];

        fields.forEach((field) => {
          if (data[field] && typeof data[field] === "string") {
            // Trim whitespace
            data[field] = data[field].trim();

            // Remove potentially dangerous characters
            data[field] = data[field]
              .replace(
                /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,
                ""
              )
              .replace(/javascript:/gi, "")
              .replace(/on\w+\s*=/gi, "");
          }
        });

        next();
      } catch (error) {
        console.error("Sanitization middleware error:", error);
        next(); // Continue even if sanitization fails
      }
    };
  }

  /**
   * Check required fields middleware
   * @param {Array} requiredFields - Required field names
   * @param {string} source - Source of data
   * @returns {Function} Express middleware
   */
  static requireFields(requiredFields, source = "body") {
    return (req, res, next) => {
      const data = req[source];
      const missing = [];

      requiredFields.forEach((field) => {
        if (
          !data[field] ||
          (typeof data[field] === "string" && data[field].trim() === "")
        ) {
          missing.push(field);
        }
      });

      if (missing.length > 0) {
        return ApiResponse.validationError(
          res,
          `Missing required fields: ${missing.join(", ")}`
        );
      }

      next();
    };
  }

  /**
   * Validate email format middleware
   * @param {string} field - Field name containing email
   * @param {string} source - Source of data
   * @param {boolean} required - Whether email is required
   * @returns {Function} Express middleware
   */
  static validateEmail(field = "email", source = "body", required = true) {
    return (req, res, next) => {
      const data = req[source];
      const email = data[field];

      if (!email) {
        if (required) {
          return ApiResponse.validationError(res, `${field} is required`);
        }
        return next();
      }

      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        return ApiResponse.validationError(res, `Invalid ${field} format`);
      }

      // Normalize email to lowercase
      data[field] = email.toLowerCase().trim();
      next();
    };
  }

  /**
   * Validate password strength middleware
   * @param {string} field - Field name containing password
   * @param {string} source - Source of data
   * @param {Object} options - Password validation options
   * @returns {Function} Express middleware
   */
  static validatePassword(field = "password", source = "body", options = {}) {
    const defaults = {
      minLength: 8,
      requireUppercase: true,
      requireLowercase: true,
      requireNumbers: true,
      requireSpecialChars: false,
    };

    const config = { ...defaults, ...options };

    return (req, res, next) => {
      const data = req[source];
      const password = data[field];

      if (!password) {
        return ApiResponse.validationError(res, `${field} is required`);
      }

      const errors = [];

      if (password.length < config.minLength) {
        errors.push(
          `Password must be at least ${config.minLength} characters long`
        );
      }

      if (config.requireUppercase && !/[A-Z]/.test(password)) {
        errors.push("Password must contain at least one uppercase letter");
      }

      if (config.requireLowercase && !/[a-z]/.test(password)) {
        errors.push("Password must contain at least one lowercase letter");
      }

      if (config.requireNumbers && !/\d/.test(password)) {
        errors.push("Password must contain at least one number");
      }

      if (
        config.requireSpecialChars &&
        !/[!@#$%^&*(),.?":{}|<>]/.test(password)
      ) {
        errors.push("Password must contain at least one special character");
      }

      if (errors.length > 0) {
        return ApiResponse.validationError(res, errors);
      }

      next();
    };
  }

  /**
   * Validate UID format middleware
   * @param {string} field - Field name containing UID
   * @param {string} source - Source of data
   * @returns {Function} Express middleware
   */
  static validateUID(field = "uid", source = "body") {
    return (req, res, next) => {
      const data = req[source];
      const uid = data[field];

      if (!uid) {
        return ApiResponse.validationError(res, `${field} is required`);
      }

      if (!/^\d{7}$/.test(uid)) {
        return ApiResponse.validationError(
          res,
          `${field} must be exactly 7 digits`
        );
      }

      next();
    };
  }

  /**
   * Validate date format and range middleware
   * @param {string} field - Field name containing date
   * @param {string} source - Source of data
   * @param {Object} options - Date validation options
   * @returns {Function} Express middleware
   */
  static validateDate(field, source = "body", options = {}) {
    return (req, res, next) => {
      const data = req[source];
      const dateValue = data[field];

      if (!dateValue) {
        if (options.required) {
          return ApiResponse.validationError(res, `${field} is required`);
        }
        return next();
      }

      const date = new Date(dateValue);

      if (isNaN(date.getTime())) {
        return ApiResponse.validationError(
          res,
          `${field} must be a valid date`
        );
      }

      if (options.minDate && date < new Date(options.minDate)) {
        return ApiResponse.validationError(
          res,
          `${field} cannot be earlier than ${options.minDate}`
        );
      }

      if (options.maxDate && date > new Date(options.maxDate)) {
        return ApiResponse.validationError(
          res,
          `${field} cannot be later than ${options.maxDate}`
        );
      }

      next();
    };
  }

  /**
   * Validate numeric range middleware
   * @param {string} field - Field name containing number
   * @param {string} source - Source of data
   * @param {Object} options - Numeric validation options
   * @returns {Function} Express middleware
   */
  static validateNumeric(field, source = "body", options = {}) {
    return (req, res, next) => {
      const data = req[source];
      const value = data[field];

      if (value === undefined || value === null || value === "") {
        if (options.required) {
          return ApiResponse.validationError(res, `${field} is required`);
        }
        return next();
      }

      const numValue = parseFloat(value);

      if (isNaN(numValue)) {
        return ApiResponse.validationError(
          res,
          `${field} must be a valid number`
        );
      }

      if (options.min !== undefined && numValue < options.min) {
        return ApiResponse.validationError(
          res,
          `${field} must be at least ${options.min}`
        );
      }

      if (options.max !== undefined && numValue > options.max) {
        return ApiResponse.validationError(
          res,
          `${field} must be at most ${options.max}`
        );
      }

      if (options.integer && !Number.isInteger(numValue)) {
        return ApiResponse.validationError(res, `${field} must be an integer`);
      }

      // Convert to proper numeric type
      data[field] = options.integer ? parseInt(value) : numValue;
      next();
    };
  }
}

module.exports = ValidationMiddleware;
