require("dotenv").config();
const express = require("express");
const cors = require("cors");
const http = require("http");
const { Server } = require("socket.io");
const { connectDB, mysqlStatus } = require("../config/mysql");
const { connectDB: connectMongoDB, mongoStatus } = require("../config/db");
const AppConfig = require("../config/AppConfig");
const ErrorHandler = require("../utils/ErrorHandler");
const auth = require("../config/auth");

const app = express();
const server = http.createServer(app);

// Socket.IO setup
const io = new Server(server, {
  cors: {
    origin: AppConfig.cors.origin,
    methods: ["GET", "POST"],
    credentials: true
  }
});

// Make io available globally for other modules
global.io = io;

// Socket.IO connection handling
io.on('connection', (socket) => {
  console.log('🔌 Client connected:', socket.id);
  
  socket.on('disconnect', () => {
    console.log('🔌 Client disconnected:', socket.id);
  });
});

// Trust proxy for secure headers
app.set("trust proxy", 1);

// Body parsing middleware (consolidated - no duplication)
app.use(express.json({ limit: AppConfig.server.requestLimit }));
app.use(express.urlencoded({ extended: true }));

// CORS configuration (secure, no wildcard in production)
app.use(cors(AppConfig.cors));

// Request logging middleware (only in development)
if (AppConfig.isDevelopment()) {
  app.use((req, res, next) => {
    const start = Date.now();
    res.on("finish", () => {
      const duration = Date.now() - start;
      console.log(
        `${req.method} ${req.originalUrl} - ${res.statusCode} (${duration}ms)`
      );
    });
    next();
  });
}

// Connect to databases - Wait for both connections
Promise.all([
  connectDB(AppConfig.database.mysql),
  connectMongoDB()
]).then(() => {
  console.log("✅ All databases connected successfully");
}).catch((error) => {
  console.error("❌ Database connection failed:", error.message);
  if (AppConfig.isProduction()) {
    process.exit(1);
  }
});

// Import routes
const authroutes = require("../routes/AuthRoutes");
const rolepermission = require("../routes/RolepermissionRoutes");
const projects = require("../routes/projectRoutes");
const task = require("../routes/taskRoutes");
const timesheet = require("../routes/timesheetRoutes");
const mysqlRoutes = require("../routes/MySQLRoutes");

// Public routes (no authentication required)
app.use("/auth/", authroutes);
app.use("/mysql/", mysqlRoutes); // MySQL management routes

// Protected routes (authentication required)
app.use("/role/", auth.isAuth, rolepermission);

// Temporarily disable auth for development testing
app.use("/task/", task);
app.use("/timesheet/", timesheet);
app.use("/project/", projects);

// Health check route
app.get("/health", (req, res) => {
  const healthData = {
    status: "OK",
    timestamp: new Date().toISOString(),
    environment: AppConfig.server.env,
    database: mysqlStatus.connected ? "Connected" : "Disconnected",
    uptime: process.uptime(),
    memory: process.memoryUsage(),
  };
  res.status(200).json(healthData);
});

// Root route
app.get("/", (req, res) => {
  res.json({
    message: "Project Planner API is running successfully! 🚀",
    version: "2.0.0",
    environment: AppConfig.server.env,
    database: mysqlStatus.message,
    documentation: "/api/docs",
  });
});

// 404 handler for undefined routes
app.use((req, res) => {
  res.status(404).json({
    status: "error",
    message: `Route ${req.originalUrl} not found`,
    availableRoutes: [
      "GET /",
      "GET /health",
      "POST /auth/register/signup",
      "POST /auth/login",
      "GET /project/",
      "POST /project/",
      "GET /task/",
      "POST /task/",
    ],
  });
});

// Global error handler (must be last middleware)
app.use(ErrorHandler.globalErrorHandler);

// Graceful shutdown handlers
const gracefulShutdown = (signal) => {
  console.log(`\n🔄 Received ${signal}. Starting graceful shutdown...`);
  server.close((err) => {
    if (err) {
      console.error("❌ Error during server shutdown:", err);
      process.exit(1);
    }
    console.log("✅ Server closed successfully");
    console.log("👋 Goodbye!");
    process.exit(0);
  });
};

// Handle termination signals
process.on("SIGTERM", () => gracefulShutdown("SIGTERM"));
process.on("SIGINT", () => gracefulShutdown("SIGINT"));

// Handle uncaught exceptions
process.on("uncaughtException", (error) => {
  console.error("💥 Uncaught Exception:", error);
  process.exit(1);
});

// Handle unhandled promise rejections
process.on("unhandledRejection", (reason, promise) => {
  console.error("💥 Unhandled Rejection at:", promise, "reason:", reason);
  process.exit(1);
});

// Start server
const PORT = AppConfig.server.port;
server.listen(PORT, () => {
  console.log(`\n🚀 Server running successfully!`);
  console.log(`📍 Port: ${PORT}`);
  console.log(`🌍 Environment: ${AppConfig.server.env}`);
  console.log(`📊 Database: ${mysqlStatus.message}`);
  console.log(`⏰ Started at: ${new Date().toISOString()}\n`);

  if (AppConfig.isDevelopment()) {
    console.log(`🔗 Local URL: http://localhost:${PORT}`);
    console.log(`🏥 Health Check: http://localhost:${PORT}/health\n`);
  }
});

// Handle server errors
server.on("error", (error) => {
  if (error.code === "EADDRINUSE") {
    console.error(`❌ Port ${PORT} is already in use`);
  } else {
    console.error("❌ Server error:", error);
  }
  process.exit(1);
});

module.exports = app;
